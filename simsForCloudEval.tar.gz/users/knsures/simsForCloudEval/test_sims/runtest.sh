#Full simulator on multi node
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   256    16   40   4   32 >& applog_sim3_np1x1x4_n256_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   256    16   40   4   32 >& applog_sim3_np1x2x2_n256_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   512    16   40   4   32 >& applog_sim3_np1x1x4_n512_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   512    16   40   4   32 >& applog_sim3_np1x2x2_n512_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   700    16   40   4   32 >& applog_sim3_np1x1x4_n700_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   700    16   40   4   32 >& applog_sim3_np1x2x2_n700_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   1024   16   40   4   32 >& applog_sim3_np1x1x4_n1024_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   1024   16   40   4   32 >& applog_sim3_np1x2x2_n1024_nit40_bpf32.log

mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   256    16   40   4   16 >& applog_sim3_np1x1x4_n256_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   256    16   40   4   16 >& applog_sim3_np1x2x2_n256_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   512    16   40   4   16 >& applog_sim3_np1x1x4_n512_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   512    16   40   4   16 >& applog_sim3_np1x2x2_n512_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   700    16   40   4   16 >& applog_sim3_np1x1x4_n700_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   700    16   40   4   16 >& applog_sim3_np1x2x2_n700_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   1024   16   40   4   16 >& applog_sim3_np1x1x4_n1024_nit40_bpf16.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   1024   16   40   4   16 >& applog_sim3_np1x2x2_n1024_nit40_bpf16.log

mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   256    16   40   4   8 >& applog_sim3_np1x1x4_n256_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   256    16   40   4   8 >& applog_sim3_np1x2x2_n256_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   512    16   40   4   8 >& applog_sim3_np1x1x4_n512_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   512    16   40   4   8 >& applog_sim3_np1x2x2_n512_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   700    16   40   4   8 >& applog_sim3_np1x1x4_n700_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   700    16   40   4   8 >& applog_sim3_np1x2x2_n700_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   1024   16   40   4   8 >& applog_sim3_np1x1x4_n1024_nit40_bpf8.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   1024   16   40   4   8 >& applog_sim3_np1x2x2_n1024_nit40_bpf8.log

mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   256    16   40   4   32 >& applog_sim3_np1x1x8_n256_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   256    16   40   4   32 >& applog_sim3_np1x2x4_n256_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   256    16   40   4   32 >& applog_sim3_np1x4x2_n256_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   512    16   40   4   32 >& applog_sim3_np1x1x8_n512_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   512    16   40   4   32 >& applog_sim3_np1x2x4_n512_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   512    16   40   4   32 >& applog_sim3_np1x4x2_n512_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   700    16   40   4   32 >& applog_sim3_np1x1x8_n700_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   700    16   40   4   32 >& applog_sim3_np1x2x4_n700_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   700    16   40   4   32 >& applog_sim3_np1x4x2_n700_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   1024   16   40   4   32 >& applog_sim3_np1x1x8_n1024_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   1024   16   40   4   32 >& applog_sim3_np1x2x4_n1024_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   1024   16   40   4   32 >& applog_sim3_np1x4x2_n1024_nit40_bpf32.log

mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   256    16   40   4   16 >& applog_sim3_np1x1x8_n256_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   256    16   40   4   16 >& applog_sim3_np1x2x4_n256_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   256    16   40   4   16 >& applog_sim3_np1x4x2_n256_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   512    16   40   4   16 >& applog_sim3_np1x1x8_n512_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   512    16   40   4   16 >& applog_sim3_np1x2x4_n512_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   512    16   40   4   16 >& applog_sim3_np1x4x2_n512_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   700    16   40   4   16 >& applog_sim3_np1x1x8_n700_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   700    16   40   4   16 >& applog_sim3_np1x2x4_n700_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   700    16   40   4   16 >& applog_sim3_np1x4x2_n700_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   1024   16   40   4   16 >& applog_sim3_np1x1x8_n1024_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   1024   16   40   4   16 >& applog_sim3_np1x2x4_n1024_nit40_bpf16.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   1024   16   40   4   16 >& applog_sim3_np1x4x2_n1024_nit40_bpf16.log

mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   256    16   40   4   8 >& applog_sim3_np1x1x8_n256_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   256    16   40   4   8 >& applog_sim3_np1x2x4_n256_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   256    16   40   4   8 >& applog_sim3_np1x4x2_n256_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   512    16   40   4   8 >& applog_sim3_np1x1x8_n512_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   512    16   40   4   8 >& applog_sim3_np1x2x4_n512_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   512    16   40   4   8 >& applog_sim3_np1x4x2_n512_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   700    16   40   4   8 >& applog_sim3_np1x1x8_n700_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   700    16   40   4   8 >& applog_sim3_np1x2x4_n700_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   700    16   40   4   8 >& applog_sim3_np1x4x2_n700_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   1024   16   40   4   8 >& applog_sim3_np1x1x8_n1024_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   1024   16   40   4   8 >& applog_sim3_np1x2x4_n1024_nit40_bpf8.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   1024   16   40   4   8 >& applog_sim3_np1x4x2_n1024_nit40_bpf8.log

#Full simulator on single node
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   256   16   40   4   8  >& applog_sim3_np1x1x1_n256_nit40_bpf8.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   480   16   40   4   8  >& applog_sim3_np1x1x1_n480_nit40_bpf8.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   512   16   40   4   8  >& applog_sim3_np1x1x1_n512_nit40_bpf8.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   650   16   40   4   8  >& applog_sim3_np1x1x1_n650_nit40_bpf8.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   256   16   40   4   16 >& applog_sim3_np1x1x1_n256_nit40_bpf16.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   480   16   40   4   16 >& applog_sim3_np1x1x1_n480_nit40_bpf16.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   512   16   40   4   16 >& applog_sim3_np1x1x1_n512_nit40_bpf16.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   650   16   40   4   16 >& applog_sim3_np1x1x1_n650_nit40_bpf16.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   256   16   40   4   32 >& applog_sim3_np1x1x1_n256_nit40_bpf32.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   480   16   40   4   32 >& applog_sim3_np1x1x1_n480_nit40_bpf32.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   512   16   40   4   32 >& applog_sim3_np1x1x1_n512_nit40_bpf32.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   650   16   40   4   32 >& applog_sim3_np1x1x1_n650_nit40_bpf32.log
 
#Forward only on 4 nodes
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   256    16   40   4   32   1 >& applog_sim3_fwd_np1x1x4_n256_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   256    16   40   4   32   1 >& applog_sim3_fwd_np1x2x2_n256_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   512    16   40   4   32   1 >& applog_sim3_fwd_np1x1x4_n512_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   512    16   40   4   32   1 >& applog_sim3_fwd_np1x2x2_n512_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   700    16   40   4   32   1 >& applog_sim3_fwd_np1x1x4_n700_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   700    16   40   4   32   1 >& applog_sim3_fwd_np1x2x2_n700_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   4   1024   16   40   4   32   1 >& applog_sim3_fwd_np1x1x4_n1024_nit40_bpf32.log
mpiexec   -n   4   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   2   1024   16   40   4   32   1 >& applog_sim3_fwd_np1x2x2_n1024_nit40_bpf32.log
 
#Forward only on 8 nodes
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   256    16   40   4   32   1 >& applog_sim3_fwd_np1x1x8_n256_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   256    16   40   4   32   1 >& applog_sim3_fwd_np1x2x4_n256_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   256    16   40   4   32   1 >& applog_sim3_fwd_np1x4x2_n256_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   512    16   40   4   32   1 >& applog_sim3_fwd_np1x1x8_n512_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   512    16   40   4   32   1 >& applog_sim3_fwd_np1x2x4_n512_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   512    16   40   4   32   1 >& applog_sim3_fwd_np1x4x2_n512_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   700    16   40   4   32   1 >& applog_sim3_fwd_np1x1x8_n700_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   700    16   40   4   32   1 >& applog_sim3_fwd_np1x2x4_n700_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   700    16   40   4   32   1 >& applog_sim3_fwd_np1x4x2_n700_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   8   1024   16   40   4   32   1 >& applog_sim3_fwd_np1x1x8_n1024_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   2   4   1024   16   40   4   32   1 >& applog_sim3_fwd_np1x2x4_n1024_nit40_bpf32.log
mpiexec   -n   8   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   4   2   1024   16   40   4   32   1 >& applog_sim3_fwd_np1x4x2_n1024_nit40_bpf32.log

#Forward only on single node
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   256   16   40   4   32   1 >& applog_sim3_fwd_np1x1x1_n256_nit40_bpf32.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   480   16   40   4   32   1 >& applog_sim3_fwd_np1x1x1_n480_nit40_bpf32.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   512   16   40   4   32   1 >& applog_sim3_fwd_np1x1x1_n512_nit40_bpf32.log
mpiexec   -n   1   --report-bindings   --bind-to   socket   ./miniapp_simulator3   1   1   1   650   16   40   4   32   1 >& applog_sim3_fwd_np1x1x1_n650_nit40_bpf32.log
