# Stencil10

## Correctness tests
To verify correctness, we created the following helper programs
* `dump_stencil10.cu` CUDA program that runs stencil10 and writse the output arrays of each kernel to a binary file.
* `check_stencil10.cu` CUDA program that runs stencil10 and reads the binary files and compares them to the output from running the program.
* `check_stencil10.cpp` the HIP-version of `check_stencil10.cu`.

### Compare reference data using CUDA
First, let's compare the original code against itself. 
```
./dump_stencil10.x 128 128 128 1
Writing: init1.bin of size 160 x 144 x 144 (13.271 MB)
    F1: Min: -0.99999 Max: 0.99999 Avg: 0.636801
    F2: Min: -1 Max: 1 Avg: 0.636799
    F3: Min: -0.99999 Max: 0.99999 Avg: 0.63658
Writing: init2.bin of size 160 x 144 x 144 (13.271 MB)
    D1: Min: -1 Max: 1 Avg: 0.636586
    D2: Min: -0.99999 Max: 0.99999 Avg: 0.63658
    D3: Min: -1 Max: 1 Avg: 0.636586
    D4: Min: -0.99999 Max: 0.99999 Avg: 0.636593
    D5: Min: -1 Max: 1 Avg: 0.636597
    D6: Min: -0.99999 Max: 0.99999 Avg: 0.636673
Writing: plainLoop1.bin of size 160 x 144 x 144 (13.271 MB)
    F1: Min: -36.8587 Max: 36.7966 Avg: 6.65001
    F2: Min: -67.7115 Max: 68.2125 Avg: 11.4415
    F3: Min: -52.8372 Max: 53.0472 Avg: 7.50835
Writing: plainLoop2.bin of size 160 x 144 x 144 (13.271 MB)
    D1: Min: -962.819 Max: 962.72 Avg: 284.728
    D2: Min: -2517.05 Max: 2563.57 Avg: 304.53
    D3: Min: -1672 Max: 1536.11 Avg: 259.715
    D4: Min: -1576.18 Max: 1537.84 Avg: 142.008
    D5: Min: -2360.73 Max: 2576.5 Avg: 157.851
    D6: Min: -555.2 Max: 548.953 Avg: 59.1016
Writing: der_7.bin of size 160 x 144 x 128 (11.7965 MB)
    der_7: Min: -23231.6 Max: 20298.8 Avg: 3261.07
Writing: der_8.bin of size 160 x 144 x 128 (11.7965 MB)
    der_8: Min: -53174.2 Max: 53297.3 Avg: 18997.4
Writing: der_13.bin of size 160 x 144 x 128 (11.7965 MB)
    der_13: Min: -27667.8 Max: 29012.5 Avg: 2272.99
Writing: der_14.bin of size 160 x 144 x 128 (11.7965 MB)
    der_14: Min: -34290.1 Max: 34868.1 Avg: 4075.78
Writing: der_17.bin of size 160 x 144 x 128 (11.7965 MB)
    der_17: Min: -4528.08 Max: 4427.74 Avg: 786.797
Writing: der_18.bin of size 160 x 144 x 128 (11.7965 MB)
    der_18: Min: -5400.08 Max: 5160.43 Avg: 705.772
Writing: der_9.bin of size 160 x 144 x 128 (11.7965 MB)
    der_9: Min: -56341.4 Max: 41081 Avg: 4618.14
Writing: der_10.bin of size 160 x 144 x 128 (11.7965 MB)
    der_10: Min: -79466.8 Max: 76942 Avg: 18067.2
Writing: der_11.bin of size 160 x 144 x 128 (11.7965 MB)
    der_11: Min: -19470 Max: 19851.2 Avg: 2889.75
Writing: der_12.bin of size 160 x 144 x 128 (11.7965 MB)
    der_12: Min: -53368.4 Max: 53143.9 Avg: 17397.4
Writing: der_15.bin of size 160 x 144 x 128 (11.7965 MB)
    der_15: Min: -28294 Max: 26774.5 Avg: 2341.83
Writing: der_16.bin of size 160 x 144 x 128 (11.7965 MB)
    der_16: Min: -33124.6 Max: 32590.1 Avg: 3902.95
Writing: plainLoop3.bin of size 160 x 144 x 144 (13.271 MB)
    F4: Min: -46597.1 Max: 54879.2 Avg: 4179.39
    F5: Min: -47101 Max: 50641.2 Avg: 4145.89
    F6: Min: -49383.3 Max: 50434.2 Avg: 4177.15
    F7: Min: -63919 Max: 64860.7 Avg: 10867.2
    F8: Min: -83160.5 Max: 80297.4 Avg: 11380.4
    F9: Min: -82116.6 Max: 90307.8 Avg: 12362.2
Done!
```
```
 ./check_stencil10.x 128 128 128 1
Reading: init1.bin of size 160 x 144 x 144 (13.271 MB)
    Difference F1: Min: 0 Max: 0 Avg: 0
    Difference F2: Min: 0 Max: 0 Avg: 0
    Difference F3: Min: 0 Max: 0 Avg: 0
    Max Relative Difference F1: Max: 0
    Max Relative Difference F2: Max: 0
    Max Relative Difference F3: Max: 0
Reading: init2.bin of size 160 x 144 x 144 (13.271 MB)
    Absolute Difference D1: Min: 0 Max: 0 Avg: 0
    Absolute Difference D2: Min: 0 Max: 0 Avg: 0
    Absolute Difference D3: Min: 0 Max: 0 Avg: 0
    Absolute Difference D4: Min: 0 Max: 0 Avg: 0
    Absolute Difference D5: Min: 0 Max: 0 Avg: 0
    Absolute Difference D6: Min: 0 Max: 0 Avg: 0
    Max Relative Difference D1: Max: 0
    Max Relative Difference D2: Max: 0
    Max Relative Difference D3: Max: 0
    Max Relative Difference D4: Max: 0
    Max Relative Difference D5: Max: 0
    Max Relative Difference D6: Max: 0
Reading: plainLoop1.bin of size 160 x 144 x 144 (13.271 MB)
    Difference F1: Min: 0 Max: 0 Avg: 0
    Difference F2: Min: 0 Max: 0 Avg: 0
    Difference F3: Min: 0 Max: 0 Avg: 0
    Max Relative Difference F1: Max: 0
    Max Relative Difference F2: Max: 0
    Max Relative Difference F3: Max: 0
Reading: plainLoop2.bin of size 160 x 144 x 144 (13.271 MB)
    Absolute Difference D1: Min: 0 Max: 0 Avg: 0
    Absolute Difference D2: Min: 0 Max: 0 Avg: 0
    Absolute Difference D3: Min: 0 Max: 0 Avg: 0
    Absolute Difference D4: Min: 0 Max: 0 Avg: 0
    Absolute Difference D5: Min: 0 Max: 0 Avg: 0
    Absolute Difference D6: Min: 0 Max: 0 Avg: 0
    Max Relative Difference D1: Max: 0
    Max Relative Difference D2: Max: 0
    Max Relative Difference D3: Max: 0
    Max Relative Difference D4: Max: 0
    Max Relative Difference D5: Max: 0
    Max Relative Difference D6: Max: 0
Reading: der_7.bin of size 160 x 144 x 128 (11.7965 MB)
    der_7 Difference: Min: 0 Max: 1540.28 Avg: 0.007692
    der_7 Max Relative Difference: Max: 0.0758802
Reading: der_8.bin of size 160 x 144 x 128 (11.7965 MB)
    der_8 Difference: Min: 0 Max: 0 Avg: 0
    der_8 Max Relative Difference: Max: 0
Reading: der_13.bin of size 160 x 144 x 128 (11.7965 MB)
    der_13 Difference: Min: 0 Max: 2564.19 Avg: 0.0525977
    der_13 Max Relative Difference: Max: 0.0883822
Reading: der_14.bin of size 160 x 144 x 128 (11.7965 MB)
    der_14 Difference: Min: 0 Max: 0 Avg: 0
    der_14 Max Relative Difference: Max: 0
Reading: der_17.bin of size 160 x 144 x 128 (11.7965 MB)
    der_17 Difference: Min: 0 Max: 0 Avg: 0
    der_17 Max Relative Difference: Max: 0
Reading: der_18.bin of size 160 x 144 x 128 (11.7965 MB)
    der_18 Difference: Min: 0 Max: 0 Avg: 0
    der_18 Max Relative Difference: Max: 0
Reading: der_9.bin of size 160 x 144 x 128 (11.7965 MB)
    der_9 Difference: Min: 0 Max: 5045.92 Avg: 0.108778
    der_9 Max Relative Difference: Max: 0.122828
Reading: der_10.bin of size 160 x 144 x 128 (11.7965 MB)
    der_10 Difference: Min: 0 Max: 0 Avg: 0
    der_10 Max Relative Difference: Max: 0
Reading: der_11.bin of size 160 x 144 x 128 (11.7965 MB)
    der_11 Difference: Min: 0 Max: 3043.58 Avg: 0.00547654
    der_11 Max Relative Difference: Max: 0.15332
Reading: der_12.bin of size 160 x 144 x 128 (11.7965 MB)
    der_12 Difference: Min: 0 Max: 0 Avg: 0
    der_12 Max Relative Difference: Max: 0
Reading: der_15.bin of size 160 x 144 x 128 (11.7965 MB)
    der_15 Difference: Min: 0 Max: 6244.09 Avg: 0.292144
    der_15 Max Relative Difference: Max: 0.23321
Reading: der_16.bin of size 160 x 144 x 128 (11.7965 MB)
    der_16 Difference: Min: 0 Max: 0 Avg: 0
    der_16 Max Relative Difference: Max: 0
Reading: plainLoop3.bin of size 160 x 144 x 144 (13.271 MB)
    Difference F1: Min: 0 Max: 3026.43 Avg: 0.00471595
    Difference F2: Min: 0 Max: 2582.02 Avg: 0.00358546
    Difference F3: Min: 0 Max: 1938.11 Avg: 0.00326538
    Difference F4: Min: 0 Max: 5971.59 Avg: 0.168414
    Difference F5: Min: 0 Max: 2380.18 Avg: 0.0341412
    Difference F6: Min: 0 Max: 4725.2 Avg: 0.064993
    Max Relative Difference F1: Max: 0.0551471
    Max Relative Difference F2: Max: 0.0509865
    Max Relative Difference F3: Max: 0.0384284
    Max Relative Difference F4: Max: 0.092068
    Max Relative Difference F5: Max: 0.029642
    Max Relative Difference F6: Max: 0.0523233
Done!

../check_stencil10.x 128 128 128 1
Reading: init1.bin of size 160 x 144 x 144 (13.271 MB)
    Difference F1: Min: 0 Max: 0 Avg: 0
    Difference F2: Min: 0 Max: 0 Avg: 0
    Difference F3: Min: 0 Max: 0 Avg: 0
    Max Relative Difference F1: Max: 0
    Max Relative Difference F2: Max: 0
    Max Relative Difference F3: Max: 0
Reading: init2.bin of size 160 x 144 x 144 (13.271 MB)
    Absolute Difference D1: Min: 0 Max: 0 Avg: 0
    Absolute Difference D2: Min: 0 Max: 0 Avg: 0
    Absolute Difference D3: Min: 0 Max: 0 Avg: 0
    Absolute Difference D4: Min: 0 Max: 0 Avg: 0
    Absolute Difference D5: Min: 0 Max: 0 Avg: 0
    Absolute Difference D6: Min: 0 Max: 0 Avg: 0
    Max Relative Difference D1: Max: 0
    Max Relative Difference D2: Max: 0
    Max Relative Difference D3: Max: 0
    Max Relative Difference D4: Max: 0
    Max Relative Difference D5: Max: 0
    Max Relative Difference D6: Max: 0
Reading: plainLoop1.bin of size 160 x 144 x 144 (13.271 MB)
    Difference F1: Min: 0 Max: 0 Avg: 0
    Difference F2: Min: 0 Max: 0 Avg: 0
    Difference F3: Min: 0 Max: 0 Avg: 0
    Max Relative Difference F1: Max: 0
    Max Relative Difference F2: Max: 0
    Max Relative Difference F3: Max: 0
Reading: plainLoop2.bin of size 160 x 144 x 144 (13.271 MB)
    Absolute Difference D1: Min: 0 Max: 0 Avg: 0
    Absolute Difference D2: Min: 0 Max: 0 Avg: 0
    Absolute Difference D3: Min: 0 Max: 0 Avg: 0
    Absolute Difference D4: Min: 0 Max: 0 Avg: 0
    Absolute Difference D5: Min: 0 Max: 0 Avg: 0
    Absolute Difference D6: Min: 0 Max: 0 Avg: 0
    Max Relative Difference D1: Max: 0
    Max Relative Difference D2: Max: 0
    Max Relative Difference D3: Max: 0
    Max Relative Difference D4: Max: 0
    Max Relative Difference D5: Max: 0
    Max Relative Difference D6: Max: 0
Reading: der_7.bin of size 160 x 144 x 128 (11.7965 MB)
    der_7 Difference: Min: 0 Max: 1444.94 Avg: 0.00364778
    der_7 Max Relative Difference: Max: 0.0711835
Reading: der_8.bin of size 160 x 144 x 128 (11.7965 MB)
    der_8 Difference: Min: 0 Max: 0 Avg: 0
    der_8 Max Relative Difference: Max: 0
Reading: der_13.bin of size 160 x 144 x 128 (11.7965 MB)
    der_13 Difference: Min: 0 Max: 2062.47 Avg: 0.00658171
    der_13 Max Relative Difference: Max: 0.0710889
Reading: der_14.bin of size 160 x 144 x 128 (11.7965 MB)
    der_14 Difference: Min: 0 Max: 0 Avg: 0
    der_14 Max Relative Difference: Max: 0
Reading: der_17.bin of size 160 x 144 x 128 (11.7965 MB)
    der_17 Difference: Min: 0 Max: 0 Avg: 0
    der_17 Max Relative Difference: Max: 0
Reading: der_18.bin of size 160 x 144 x 128 (11.7965 MB)
    der_18 Difference: Min: 0 Max: 0 Avg: 0
    der_18 Max Relative Difference: Max: 0
Reading: der_9.bin of size 160 x 144 x 128 (11.7965 MB)
    der_9 Difference: Min: 0 Max: 5045.92 Avg: 0.192721
    der_9 Max Relative Difference: Max: 0.122828
Reading: der_10.bin of size 160 x 144 x 128 (11.7965 MB)
    der_10 Difference: Min: 0 Max: 0 Avg: 0
    der_10 Max Relative Difference: Max: 0
Reading: der_11.bin of size 160 x 144 x 128 (11.7965 MB)
    der_11 Difference: Min: 0 Max: 5212.12 Avg: 0.356205
    der_11 Max Relative Difference: Max: 0.262559
Reading: der_12.bin of size 160 x 144 x 128 (11.7965 MB)
    der_12 Difference: Min: 0 Max: 0 Avg: 0
    der_12 Max Relative Difference: Max: 0
Reading: der_15.bin of size 160 x 144 x 128 (11.7965 MB)
    der_15 Difference: Min: 0 Max: 8519.19 Avg: 1.3499
    der_15 Max Relative Difference: Max: 0.318183
Reading: der_16.bin of size 160 x 144 x 128 (11.7965 MB)
    der_16 Difference: Min: 0 Max: 6.73633 Avg: 0.000185633
    der_16 Max Relative Difference: Max: 0.000206698
Reading: plainLoop3.bin of size 160 x 144 x 144 (13.271 MB)
    Difference F1: Min: 0 Max: 5202.13 Avg: 0.199079
    Difference F2: Min: 0 Max: 4136.91 Avg: 0.207929
    Difference F3: Min: 0 Max: 4852 Avg: 0.200913
    Difference F4: Min: 0 Max: 6850.48 Avg: 0.777078
    Difference F5: Min: 0 Max: 1638.75 Avg: 0.00491011
    Difference F6: Min: 0 Max: 4725.2 Avg: 0.113411
    Max Relative Difference F1: Max: 0.0947922
    Max Relative Difference F2: Max: 0.0816905
    Max Relative Difference F3: Max: 0.0962045
    Max Relative Difference F4: Max: 0.105618
    Max Relative Difference F5: Max: 0.0204085
    Max Relative Difference F6: Max: 0.0523233
```
It appears that there is a subtle bug in the pre-computation of the mixed derivatives.

Here is the output for a bigger grid, which shows the same problem:
```
  ./dump_stencil10.x 512 512 512 1
Writing: init1.bin of size 544 x 528 x 528 (606.634 MB)
    F1: Min: -0.999991 Max: 0.999991 Avg: 0.636616
    F2: Min: -1 Max: 1 Avg: 0.636622
    F3: Min: -0.999991 Max: 0.999991 Avg: 0.636616
Writing: init2.bin of size 544 x 528 x 528 (606.634 MB)
    D1: Min: -1 Max: 1 Avg: 0.636622
    D2: Min: -0.999991 Max: 0.999991 Avg: 0.636616
    D3: Min: -1 Max: 1 Avg: 0.636622
    D4: Min: -0.999991 Max: 0.999991 Avg: 0.636617
    D5: Min: -1 Max: 1 Avg: 0.636622
    D6: Min: -0.999991 Max: 0.999991 Avg: 0.636616
Writing: plainLoop1.bin of size 544 x 528 x 528 (606.634 MB)
    F1: Min: -36.9118 Max: 36.9265 Avg: 9.03908
    F2: Min: -67.7389 Max: 68.3858 Avg: 15.7583
    F3: Min: -52.8556 Max: 53.5057 Avg: 10.2713
Writing: plainLoop2.bin of size 544 x 528 x 528 (606.634 MB)
    D1: Min: -965.888 Max: 966.004 Avg: 410.288
    D2: Min: -2570.99 Max: 2658.39 Avg: 425.443
    D3: Min: -1673.4 Max: 1577.48 Avg: 375.187
    D4: Min: -1559.65 Max: 1525.95 Avg: 180.415
    D5: Min: -2376.47 Max: 2578.29 Avg: 194.225
    D6: Min: -577.473 Max: 606.674 Avg: 80.3093
Writing: der_7.bin of size 544 x 528 x 512 (588.251 MB)
    der_7: Min: -23244.1 Max: 21448.4 Avg: 3440.5
Writing: der_8.bin of size 544 x 528 x 512 (588.251 MB)
    der_8: Min: -53308.4 Max: 53302 Avg: 27464.8
Writing: der_13.bin of size 544 x 528 x 512 (588.251 MB)
    der_13: Min: -22894.8 Max: 25250.1 Avg: 3003.79
Writing: der_14.bin of size 544 x 528 x 512 (588.251 MB)
    der_14: Min: -34823.3 Max: 34881.1 Avg: 5025.78
Writing: der_17.bin of size 544 x 528 x 512 (588.251 MB)
    der_17: Min: -4449.74 Max: 4580.12 Avg: 1112.92
Writing: der_18.bin of size 544 x 528 x 512 (588.251 MB)
    der_18: Min: -4764.3 Max: 4757.26 Avg: 957.036
Writing: der_9.bin of size 544 x 528 x 512 (588.251 MB)
    der_9: Min: -38946.1 Max: 41108.2 Avg: 5396.46
Writing: der_10.bin of size 544 x 528 x 512 (588.251 MB)
    der_10: Min: -79590.5 Max: 81119.8 Avg: 25866.2
Writing: der_11.bin of size 544 x 528 x 512 (588.251 MB)
    der_11: Min: -19524.2 Max: 21812.9 Avg: 3488.09
Writing: der_12.bin of size 544 x 528 x 512 (588.251 MB)
    der_12: Min: -53564.9 Max: 53661.1 Avg: 25296.2
Writing: der_15.bin of size 544 x 528 x 512 (588.251 MB)
    der_15: Min: -28809.9 Max: 28729.2 Avg: 3123.98
Writing: der_16.bin of size 544 x 528 x 512 (588.251 MB)
    der_16: Min: -33388 Max: 33360.2 Avg: 4857.42
Writing: plainLoop3.bin of size 544 x 528 x 528 (606.634 MB)
    F4: Min: -45577 Max: 48163.2 Avg: 5158.33
    F5: Min: -45575.9 Max: 50489.8 Avg: 5101.67
    F6: Min: -47750.4 Max: 49202.1 Avg: 5126.63
    F7: Min: -66563.3 Max: 69075.6 Avg: 16363
    F8: Min: -83528.1 Max: 82290.4 Avg: 16750.9
    F9: Min: -84455.6 Max: 87315.4 Avg: 18198.8
Done!
```

```
 ./check_stencil10.x 512 512 512 1
Reading: init1.bin of size 544 x 528 x 528 (606.634 MB)
    Difference F1: Min: 0 Max: 0 Avg: 0
    Difference F2: Min: 0 Max: 0 Avg: 0
    Difference F3: Min: 0 Max: 0 Avg: 0
    Max Relative Difference F1: Max: 0
    Max Relative Difference F2: Max: 0
    Max Relative Difference F3: Max: 0
Reading: init2.bin of size 544 x 528 x 528 (606.634 MB)
    Absolute Difference D1: Min: 0 Max: 0 Avg: 0
    Absolute Difference D2: Min: 0 Max: 0 Avg: 0
    Absolute Difference D3: Min: 0 Max: 0 Avg: 0
    Absolute Difference D4: Min: 0 Max: 0 Avg: 0
    Absolute Difference D5: Min: 0 Max: 0 Avg: 0
    Absolute Difference D6: Min: 0 Max: 0 Avg: 0
    Max Relative Difference D1: Max: 0
    Max Relative Difference D2: Max: 0
    Max Relative Difference D3: Max: 0
    Max Relative Difference D4: Max: 0
    Max Relative Difference D5: Max: 0
    Max Relative Difference D6: Max: 0
Reading: plainLoop1.bin of size 544 x 528 x 528 (606.634 MB)
    Difference F1: Min: 0 Max: 0 Avg: 0
    Difference F2: Min: 0 Max: 0 Avg: 0
    Difference F3: Min: 0 Max: 0 Avg: 0
    Max Relative Difference F1: Max: 0
    Max Relative Difference F2: Max: 0
    Max Relative Difference F3: Max: 0
Reading: plainLoop2.bin of size 544 x 528 x 528 (606.634 MB)
    Absolute Difference D1: Min: 0 Max: 0 Avg: 0
    Absolute Difference D2: Min: 0 Max: 0 Avg: 0
    Absolute Difference D3: Min: 0 Max: 0 Avg: 0
    Absolute Difference D4: Min: 0 Max: 0 Avg: 0
    Absolute Difference D5: Min: 0 Max: 0 Avg: 0
    Absolute Difference D6: Min: 0 Max: 0 Avg: 0
    Max Relative Difference D1: Max: 0
    Max Relative Difference D2: Max: 0
    Max Relative Difference D3: Max: 0
    Max Relative Difference D4: Max: 0
    Max Relative Difference D5: Max: 0
    Max Relative Difference D6: Max: 0
Reading: der_7.bin of size 544 x 528 x 512 (588.251 MB)
    der_7 Difference: Min: 0 Max: 1279.1 Avg: 7.19027e-05
    der_7 Max Relative Difference: Max: 0.0596362
Reading: der_8.bin of size 544 x 528 x 512 (588.251 MB)
    der_8 Difference: Min: 0 Max: 0 Avg: 0
    der_8 Max Relative Difference: Max: 0
Reading: der_13.bin of size 544 x 528 x 512 (588.251 MB)
    der_13 Difference: Min: 0 Max: 2955.8 Avg: 0.00826913
    der_13 Max Relative Difference: Max: 0.117061
Reading: der_14.bin of size 544 x 528 x 512 (588.251 MB)
    der_14 Difference: Min: 0 Max: 3951.07 Avg: 0.000803297
    der_14 Max Relative Difference: Max: 0.113273
Reading: der_17.bin of size 544 x 528 x 512 (588.251 MB)
    der_17 Difference: Min: 0 Max: 684.778 Avg: 0.00017508
    der_17 Max Relative Difference: Max: 0.149511
Reading: der_18.bin of size 544 x 528 x 512 (588.251 MB)
    der_18 Difference: Min: 0 Max: 0 Avg: 0
    der_18 Max Relative Difference: Max: 0
Reading: der_9.bin of size 544 x 528 x 512 (588.251 MB)
    der_9 Difference: Min: 0 Max: 3538.43 Avg: 0.0255775
    der_9 Max Relative Difference: Max: 0.086076
Reading: der_10.bin of size 544 x 528 x 512 (588.251 MB)
    der_10 Difference: Min: 0 Max: 0 Avg: 0
    der_10 Max Relative Difference: Max: 0
Reading: der_11.bin of size 544 x 528 x 512 (588.251 MB)
    der_11 Difference: Min: 0 Max: 5754.83 Avg: 0.0275119
    der_11 Max Relative Difference: Max: 0.263827
Reading: der_12.bin of size 544 x 528 x 512 (588.251 MB)
    der_12 Difference: Min: 0 Max: 3992.45 Avg: 0.00177745
    der_12 Max Relative Difference: Max: 0.0744013
Reading: der_15.bin of size 544 x 528 x 512 (588.251 MB)
    der_15 Difference: Min: 0 Max: 6356.91 Avg: 0.0335225
    der_15 Max Relative Difference: Max: 0.22127
Reading: der_16.bin of size 544 x 528 x 512 (588.251 MB)
    der_16 Difference: Min: 0 Max: 0 Avg: 0
    der_16 Max Relative Difference: Max: 0
Reading: plainLoop3.bin of size 544 x 528 x 528 (606.634 MB)
    Difference F1: Min: 0 Max: 5670.67 Avg: 0.0173146
    Difference F2: Min: 0 Max: 5005.63 Avg: 0.0172233
    Difference F3: Min: 0 Max: 5294.37 Avg: 0.0167987
    Difference F4: Min: 0 Max: 4702.44 Avg: 0.0215434
    Difference F5: Min: 0 Max: 2935.47 Avg: 0.0050554
    Difference F6: Min: 0 Max: 3459.71 Avg: 0.0163225
    Max Relative Difference F1: Max: 0.117739
    Max Relative Difference F2: Max: 0.0991415
    Max Relative Difference F3: Max: 0.107604
    Max Relative Difference F4: Max: 0.0680767
    Max Relative Difference F5: Max: 0.0356721
    Max Relative Difference F6: Max: 0.0396231
Done!
```

### Compare reference data using baseline HIP port 
The baseline HIP port is called `check_stencil10.cpp`. At this directory, do:
```
make
./check_stencil10.x 32 32 32 1
```
Expected output
```
Reading: build_a100/32x32x32/init1.bin of size 64 x 48 x 48 (0.589824 MB)
Difference F1: Min: 0 Max: 5.96046e-08 Avg: 1.01985e-08
Difference F2: Min: 0 Max: 5.96046e-08 Avg: 6.54331e-09
Difference F3: Min: 0 Max: 5.96046e-08 Avg: 9.43126e-09
Max Relative Difference F1: Max: 5.96099e-08
Max Relative Difference F2: Max: 5.96046e-08
Max Relative Difference F3: Max: 5.96099e-08
Reading: build_a100/32x32x32/init2.bin of size 64 x 48 x 48 (0.589824 MB)
Absolute Difference D1: Min: 0 Max: 5.96046e-08 Avg: 7.24726e-09
Absolute Difference D2: Min: 0 Max: 5.96046e-08 Avg: 9.43126e-09
Absolute Difference D3: Min: 0 Max: 5.96046e-08 Avg: 7.24726e-09
Absolute Difference D4: Min: 0 Max: 5.96046e-08 Avg: 9.39447e-09
Absolute Difference D5: Min: 0 Max: 5.96046e-08 Avg: 7.31355e-09
Absolute Difference D6: Min: 0 Max: 5.96046e-08 Avg: 9.79061e-09
Max Relative Difference D1: Max: 5.96046e-08
Max Relative Difference D2: Max: 5.96099e-08
Max Relative Difference D3: Max: 5.96046e-08
Max Relative Difference D4: Max: 5.96099e-08
Max Relative Difference D5: Max: 5.96046e-08
Max Relative Difference D6: Max: 5.96099e-08
Reading: build_a100/32x32x32/plainLoop1.bin of size 64 x 48 x 48 (0.589824 MB)
Difference F1: Min: 0 Max: 1.52588e-05 Avg: 4.04896e-07
Difference F2: Min: 0 Max: 1.52588e-05 Avg: 3.2159e-07
Difference F3: Min: 0 Max: 1.52588e-05 Avg: 3.79166e-07
Max Relative Difference F1: Max: 4.16579e-07
Max Relative Difference F2: Max: 2.25434e-07
Max Relative Difference F3: Max: 3.01613e-07
Reading: build_a100/32x32x32/plainLoop2.bin of size 64 x 48 x 48 (0.589824 MB)
Absolute Difference D1: Min: 0 Max: 0.000244141 Avg: 8.577e-06
Absolute Difference D2: Min: 0 Max: 0.000549316 Avg: 1.84414e-05
Absolute Difference D3: Min: 0 Max: 0.000366211 Avg: 1.00189e-05
Absolute Difference D4: Min: 0 Max: 0.000427246 Avg: 1.66509e-05
Absolute Difference D5: Min: 0 Max: 0.000488281 Avg: 1.68813e-05
Absolute Difference D6: Min: 0 Max: 0.000171661 Avg: 5.48704e-06
Max Relative Difference D1: Max: 2.54445e-07
Max Relative Difference D2: Max: 2.28463e-07
Max Relative Difference D3: Max: 2.54296e-07
Max Relative Difference D4: Max: 2.83098e-07
Max Relative Difference D5: Max: 2.22272e-07
Max Relative Difference D6: Max: 3.15129e-07
Reading: build_a100/32x32x32/plainLoop3.bin of size 64 x 48 x 48 (0.589824 MB)
Difference F1: Min: 0 Max: 0.0117188 Avg: 0.000336862
Difference F2: Min: 0 Max: 0.0117188 Avg: 0.000336899
Difference F3: Min: 0 Max: 0.0117188 Avg: 0.000333099
Difference F4: Min: 0 Max: 0.015625 Avg: 0.000361566
Difference F5: Min: 0 Max: 0.0234375 Avg: 0.000441888
Difference F6: Min: 0 Max: 0.0195312 Avg: 0.000451896
Max Relative Difference F1: Max: 2.27735e-07
Max Relative Difference F2: Max: 2.44133e-07
Max Relative Difference F3: Max: 2.2281e-07
Max Relative Difference F4: Max: 2.54381e-07
Max Relative Difference F5: Max: 3.04317e-07
Max Relative Difference F6: Max: 2.46412e-07
Done!
```
The relative differences are within single precision rounding errors, which is what we would like to
see. For bigger problems, we see differences in derivative computations that then propagate to
`plainLoop3`.
