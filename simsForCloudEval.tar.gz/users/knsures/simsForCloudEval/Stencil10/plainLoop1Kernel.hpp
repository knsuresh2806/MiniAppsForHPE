    template <int TX=64, int TY=8, int TZ = 64>
__launch_bounds__(TX * TY, 1)
    __global__ void plain1optKernel(float *__restrict__ field1,
                                   float *__restrict__ field2,
                                   float *__restrict__ field3,
                                   const float *__restrict__ field4,
                                   const float *__restrict__ field5,
                                   const float *__restrict__ field6,
                                   const float *__restrict__ field7,
                                   const float *__restrict__ field8,
                                   const float *__restrict__ field9,
                                   const float *__restrict__ M22,
                                   const float *__restrict__ zprime,
                                   int ldimx,
                                   int ldimy,
                                   int nz)
{
    const float invd1 = 1.01f;
    const float invd2 = 2.01f;

    const int W = 16;
    const int R = 8;

    __shared__ float shm11[TY][TX + W];     // SHM11: Center + X halos
    __shared__ float shm13[TY][TX + W];     // SHM13: Center from register queue + X halos
    __shared__ float shm22[TY+W][TX];       // SHM22: Center + Y halos
    __shared__ float shm23[TY+W][TX];       // SHM23: Center from register queue + Y halos
    __shared__ float shm12[TY+W][TX+W];     // SHM12: Center + X halos + Y halos

    // Register queues for the Z derivatives
    float rq33[W+1];
    float rq13[W+1];
    float rq23[W+1];
    float m22z;

    const int tx = threadIdx.x + R;
    const int ty = threadIdx.y + R;
    const int ix = blockIdx.x * TX + tx;
    const int iy = blockIdx.y * TY + ty;
    const int iz = blockIdx.z * TZ;
    const int zblock = min(TZ, nz - iz);
    const int stride = ldimx * ldimy;

    // Index to load the register queues in Z
    int index_z = (iz * ldimy + iy) * ldimx + ix;
    // Index of the point to be computed
    int index = index_z + R * stride;

    // Prime the register queues in Z
    for (int i = 0; i < 16; i++)
    {
        rq13[i] = field8[index_z];
        rq23[i] = field9[index_z];
        rq33[i] = field6[index_z];
        index_z += stride;
    }
    m22z = M22[index - stride];

    // Prime the shared memory
    shm11[threadIdx.y][tx] =  field4[index];                          // Center of shm11
    shm22[threadIdx.y][threadIdx.x] = field5[index - R * ldimx];      // First half of shm22
    shm22[threadIdx.y + TY][threadIdx.x] = field5[index + R * ldimx]; // Second half of shm22
    shm12[threadIdx.y][tx] = field7[index - R * ldimx];               // First half of shm12, minus X halos
    shm12[threadIdx.y + TY][tx] = field7[index + R * ldimx];          // Second half of shm12, minus X halos
    if (threadIdx.y < R) {
        shm23[threadIdx.y][threadIdx.x] = field9[index - R * ldimx];            // Y- halos of shm23
        shm23[threadIdx.y + TY + R][threadIdx.x] = field9[index + TY * ldimx];  // Y+ halos of shm23
    }                                                                            
    if (threadIdx.x < R)
    {
        shm11[threadIdx.y][threadIdx.x] = field4[index - R];        // X- halos of shm11
        shm11[threadIdx.y][tx + TX] = field4[index + TX];           // X+ halos of shm11
        shm13[threadIdx.y][threadIdx.x] = field8[index - R];        // X- halos of shm13
        shm13[threadIdx.y][tx + TX] = field8[index + TX];           // X+ halos of shm13
        shm12[ty][threadIdx.x] = field7[index - R];                 // X- halos of shm12
        shm12[ty][tx + TX] = field7[index + TX];                    // X+ halos of shm12
    }
        shm13[threadIdx.y][tx] = rq13[R];
        shm23[ty][threadIdx.x] = rq23[R];

    for (int zloop = 0; zloop < zblock; zloop++)
    {
        __syncthreads();
        // Read new register queue values
        rq13[W] = field8[index_z];
        rq23[W] = field9[index_z];
        rq33[W] = field6[index_z];
        index_z += stride;

        float r11 = field4[index + stride];                         // Center of shm11
        float r22_1 = field5[index + stride - R * ldimx];           // First half of shm22
        float r22_2 = field5[index + stride + R * ldimx];           // Second half of shm22
        float r12_1 = field7[index + stride - R * ldimx];           // First half of shm12, minus X halos
        float r12_2 = field7[index + stride + R * ldimx];           // Second half of shm12, minus X halos

        float rh23_1, rh23_2;
        if (threadIdx.y < R)
            rh23_1 = field9[index + stride - R * ldimx];
        else 
            rh23_2 = field9[index + stride + R * ldimx];

        float rh11_1, rh11_2, rh13_1, rh13_2, rh12_1, rh12_2;
        if (threadIdx.x < R)
        {
            rh11_1 = field4[index + stride - R];                    // X- halos of shm11
            rh11_2 = field4[index + stride + TX];                   // X+ halos of shm11
            rh13_1 = field8[index + stride - R];                    // X- halos of shm13
            rh13_2 = field8[index + stride + TX];                   // X+ halos of shm13
            rh12_1 = field7[index + stride - R];                    // X- halos of shm12
            rh12_2 = field7[index + stride + TX];                   // X+ halos of shm12
        }

        float r13_1 = rq13[9];
        float r13_2 = rq23[9];
        float f1 = field1[index];
        float f2 = field2[index];
        float f3 = field3[index];



        float dt11d1 = drv1_16<true, 1>(&shm11[threadIdx.y][tx]);
        float dt22d2 = drv1_16<true, TX>(&shm22[ty][threadIdx.x]);
        float dt33d3 = drv1_16<true, 1>(&rq33[R]);
        float dt12d1 = drv1_16<false, 1>(&shm12[ty][tx]);
        float dt12d2 = drv1_16<false, TX+W>(&shm12[ty][tx]);
        float dt13d3 = drv1_16<false, 1>(&rq13[R]);
        float dt13d1 = drv1_16<false, 1>(&shm13[threadIdx.y][tx]);
        float dt23d2 = drv1_16<false, TX>(&shm23[ty][threadIdx.x]);
        float dt23d3 = drv1_16<false, 1>(&rq23[R]);

        __syncthreads();

        // Load into shared memory
        
        shm11[threadIdx.y][tx] = r11;                 // Center of shm11
        shm22[threadIdx.y][threadIdx.x] = r22_1;      // First half of shm22
        shm22[threadIdx.y + TY][threadIdx.x] = r22_2; // Second half of shm22
        shm12[threadIdx.y][tx] = r12_1;               // First half of shm12, minus X halos
        shm12[threadIdx.y + TY][tx] = r12_2;          // Second half of shm12, minus X halos


        if (threadIdx.y < R)
            shm23[threadIdx.y][threadIdx.x] = rh23_1;       // Y- halos of shm23
        else
            shm23[threadIdx.y + TY][threadIdx.x] = rh23_2;  // Y+ halos of shm23

        if (threadIdx.x < R)
        {
            shm11[threadIdx.y][threadIdx.x] = rh11_1;       // X- halos of shm11
            shm11[threadIdx.y][tx + TX] = rh11_2;           // X+ halos of shm11
            shm13[threadIdx.y][threadIdx.x] = rh13_1;       // X- halos of shm13
            shm13[threadIdx.y][tx + TX] = rh13_2;           // X+ halos of shm13
            shm12[ty][threadIdx.x] = rh12_1;                // X- halos of shm12
            shm12[ty][tx + TX] = rh12_2;                    // X+ halos of shm12
        }

        shm13[threadIdx.y][tx] = r13_1;
        shm23[ty][threadIdx.x] = r13_2;

        // Rely on the L1 cache to load the M22 model efficiently
        float zpr = zprime[iz + R + zloop];
        float res1 = (2.0f * M22[index - 1]) * (dt11d1 * invd1 + dt12d2 * invd2 + dt13d3 * zpr);
        float res2 = (2.0f * M22[index - ldimx]) * (dt12d1 * invd1 + dt22d2 * invd2 + dt23d3 * zpr);
        float res3 = (2.0f * m22z) * (dt13d1 * invd1 + dt23d2 * invd2 + dt33d3 * zpr);
        m22z = M22[index];

        // Using atomics to let the L2 cache do the load-add-store, instead of the SM.
        atomicAdd(field1 + index, res1);
        atomicAdd(field2 + index, res2);
        atomicAdd(field3 + index, res3);
        index += stride;

        // Rotate the register queues
        for (int i = 0; i < W; i++)
        {
            rq13[i] = rq13[i + 1];
            rq23[i] = rq23[i + 1];
            rq33[i] = rq33[i + 1];
        }
    }
}
void plainLoop1opt(float *field1, float *field2, float *field3,
                  float *field4, float *field5, float *field6,
                  float *field7, float *field8, float *field9,
                  float *M22, float *zprime, int nx, int ny, int nz, int ldimx, int ldimy)
{
    constexpr int tile_z = 128;
    const int tile_x = 32;
    const int tile_y = 16;
    dim3 threads(tile_x, tile_y, 1);
    dim3 blocks((nx + tile_x - 1) / tile_x, (ny + tile_y - 1) / tile_y, (nz - 1) / tile_z + 1);
    plain1optKernel<tile_x, tile_y, tile_z><<<blocks, threads, 0, 0>>>(field1, field2, field3, field4, field5, field6,
                                                      field7, field8, field9, M22, zprime,
                                                      ldimx, ldimy, nz);
}

