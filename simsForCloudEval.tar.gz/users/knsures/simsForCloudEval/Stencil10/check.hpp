#pragma once
#include <cstdio>

double min(float *u, int ldimx, int ldimy, int ldimz) {

    float minval = 1e20;
    size_t slice = ldimx * ldimy;
    for (int k = 0; k < ldimz; k++) 
    for (int j = 0; j < ldimy; j++) 
    for (int i = 0; i < ldimx; i++) {
        size_t pos = i + j * ldimx + k * slice;
        minval = minval < u[pos] ? minval : u[pos];
    }

    return minval;
}

double max(float *u, int ldimx, int ldimy, int ldimz) {

    double maxval = -1e20;
    size_t slice = ldimx * ldimy;
    for (int k = 0; k < ldimz; k++) 
    for (int j = 0; j < ldimy; j++) 
    for (int i = 0; i < ldimx; i++) {
        size_t pos = i + j * ldimx + k * slice;
        maxval = maxval > u[pos] ? maxval : u[pos];
    }

    return maxval;
}

double absavg(float *u, int ldimx, int ldimy, int ldimz) {

    double avgval = 0;
    size_t slice = ldimx * ldimy;
    for (int k = 0; k < ldimz; k++) 
    for (int j = 0; j < ldimy; j++) 
    for (int i = 0; i < ldimx; i++) {
        size_t pos = i + j * ldimx + k * slice;
        avgval += fabs(u[pos]);
    }
    avgval /= (slice * ldimz);

    return avgval;
}

void dump_array(const char *filename, const char *label, float *f1, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "w");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }
        
    CUCHK(cudaDeviceSynchronize());

    size_t n = ldimx * ldimy * ldimz;
    printf("Writing: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));
    float *h1 = new float[n];
    CUCHK(cudaMemcpy(h1, f1, n * sizeof(float), cudaMemcpyDeviceToHost));
    
    printf("    %s: Min: %g Max: %g Avg: %g \n", label, min(h1, ldimx, ldimy, ldimz), max(h1, ldimx, ldimy, ldimz), absavg(h1, ldimx, ldimy, ldimz));
    
    fwrite(h1, sizeof(float), n, fh); 

    delete[] h1;

    fclose(fh);


}

void dump_plainLoop1(const char *filename, float *f1, float *f2, float *f3, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "w");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }
        
    CUCHK(cudaDeviceSynchronize());

    size_t n = ldimx * ldimy * ldimz;
    printf("Writing: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));
    float *h1 = new float[n];
    float *h2 = new float[n];
    float *h3 = new float[n];
    CUCHK(cudaMemcpy(h1, f1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h2, f2, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h3, f3, n * sizeof(float), cudaMemcpyDeviceToHost));
    
    printf("    F1: Min: %g Max: %g Avg: %g \n", min(h1, ldimx, ldimy, ldimz), max(h1, ldimx, ldimy, ldimz), absavg(h1, ldimx, ldimy, ldimz));
    printf("    F2: Min: %g Max: %g Avg: %g \n", min(h2, ldimx, ldimy, ldimz), max(h2, ldimx, ldimy, ldimz), absavg(h2, ldimx, ldimy, ldimz));
    printf("    F3: Min: %g Max: %g Avg: %g \n", min(h3, ldimx, ldimy, ldimz), max(h3, ldimx, ldimy, ldimz), absavg(h3, ldimx, ldimy, ldimz));
    
    fwrite(h1, sizeof(float), n, fh); 
    fwrite(h2, sizeof(float), n, fh); 
    fwrite(h3, sizeof(float), n, fh); 

    delete[] h1;
    delete[] h2;
    delete[] h3;
    
    fclose(fh);


}
void dump_plainLoop2(const char *filename, float *d1, float *d2, float *d3, float *d4, float *d5, float *d6, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "w");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }

    size_t n = ldimx * ldimy * ldimz;
    printf("Writing: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));

    CUCHK(cudaDeviceSynchronize());

    float *h1 = new float[n];
    float *h2 = new float[n];
    float *h3 = new float[n];
    float *h4 = new float[n];
    float *h5 = new float[n];
    float *h6 = new float[n];
    CUCHK(cudaMemcpy(h1, d1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h2, d2, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h3, d3, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h4, d4, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h5, d5, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h6, d6, n * sizeof(float), cudaMemcpyDeviceToHost));
    
    printf("    D1: Min: %g Max: %g Avg: %g \n", min(h1, ldimx, ldimy, ldimz), max(h1, ldimx, ldimy, ldimz), absavg(h1, ldimx, ldimy, ldimz));
    printf("    D2: Min: %g Max: %g Avg: %g \n", min(h2, ldimx, ldimy, ldimz), max(h2, ldimx, ldimy, ldimz), absavg(h2, ldimx, ldimy, ldimz));
    printf("    D3: Min: %g Max: %g Avg: %g \n", min(h3, ldimx, ldimy, ldimz), max(h3, ldimx, ldimy, ldimz), absavg(h3, ldimx, ldimy, ldimz));
    printf("    D4: Min: %g Max: %g Avg: %g \n", min(h4, ldimx, ldimy, ldimz), max(h4, ldimx, ldimy, ldimz), absavg(h4, ldimx, ldimy, ldimz));
    printf("    D5: Min: %g Max: %g Avg: %g \n", min(h5, ldimx, ldimy, ldimz), max(h5, ldimx, ldimy, ldimz), absavg(h5, ldimx, ldimy, ldimz));
    printf("    D6: Min: %g Max: %g Avg: %g \n", min(h6, ldimx, ldimy, ldimz), max(h6, ldimx, ldimy, ldimz), absavg(h6, ldimx, ldimy, ldimz));
    fwrite(h1, sizeof(float), n, fh); 
    fwrite(h2, sizeof(float), n, fh); 
    fwrite(h3, sizeof(float), n, fh); 
    fwrite(h4, sizeof(float), n, fh); 
    fwrite(h5, sizeof(float), n, fh); 
    fwrite(h6, sizeof(float), n, fh); 

    delete[] h1;
    delete[] h2;
    delete[] h3;
    delete[] h4;
    delete[] h5;
    delete[] h6;

    fclose(fh);

}

void dump_plainLoop3(const char *filename, float *d1, float *d2, float *d3, float *d4, float *d5, float *d6, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "w");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }

    size_t n = ldimx * ldimy * ldimz;
    printf("Writing: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));

    CUCHK(cudaDeviceSynchronize());

    float *h1 = new float[n];
    float *h2 = new float[n];
    float *h3 = new float[n];
    float *h4 = new float[n];
    float *h5 = new float[n];
    float *h6 = new float[n];
    CUCHK(cudaMemcpy(h1, d1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h2, d2, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h3, d3, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h4, d4, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h5, d5, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h6, d6, n * sizeof(float), cudaMemcpyDeviceToHost));
    
    printf("    F4: Min: %g Max: %g Avg: %g \n", min(h1, ldimx, ldimy, ldimz), max(h1, ldimx, ldimy, ldimz), absavg(h1, ldimx, ldimy, ldimz));
    printf("    F5: Min: %g Max: %g Avg: %g \n", min(h2, ldimx, ldimy, ldimz), max(h2, ldimx, ldimy, ldimz), absavg(h2, ldimx, ldimy, ldimz));
    printf("    F6: Min: %g Max: %g Avg: %g \n", min(h3, ldimx, ldimy, ldimz), max(h3, ldimx, ldimy, ldimz), absavg(h3, ldimx, ldimy, ldimz));
    printf("    F7: Min: %g Max: %g Avg: %g \n", min(h4, ldimx, ldimy, ldimz), max(h4, ldimx, ldimy, ldimz), absavg(h4, ldimx, ldimy, ldimz));
    printf("    F8: Min: %g Max: %g Avg: %g \n", min(h5, ldimx, ldimy, ldimz), max(h5, ldimx, ldimy, ldimz), absavg(h5, ldimx, ldimy, ldimz));
    printf("    F9: Min: %g Max: %g Avg: %g \n", min(h6, ldimx, ldimy, ldimz), max(h6, ldimx, ldimy, ldimz), absavg(h6, ldimx, ldimy, ldimz));
    fwrite(h1, sizeof(float), n, fh); 
    fwrite(h2, sizeof(float), n, fh); 
    fwrite(h3, sizeof(float), n, fh); 
    fwrite(h4, sizeof(float), n, fh); 
    fwrite(h5, sizeof(float), n, fh); 
    fwrite(h6, sizeof(float), n, fh); 

    delete[] h1;
    delete[] h2;
    delete[] h3;
    delete[] h4;
    delete[] h5;
    delete[] h6;

    fclose(fh);

}

void check_plainLoop1(const char *filename, float *f1, float *f2, float *f3, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "r");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }
        
    CUCHK(cudaDeviceSynchronize());

    size_t n = ldimx * ldimy * ldimz;
    printf("Reading: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));
    float *h1 = new float[n];
    float *h2 = new float[n];
    float *h3 = new float[n];
    float *h1_ref = new float[n];
    float *h2_ref = new float[n];
    float *h3_ref = new float[n];
    float *diff1 = new float[n];
    float *diff2 = new float[n];
    float *diff3 = new float[n];
    CUCHK(cudaMemcpy(h1, f1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h2, f2, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h3, f3, n * sizeof(float), cudaMemcpyDeviceToHost));
    
    CUCHK(cudaDeviceSynchronize());
    fread(h1_ref, sizeof(float), n, fh); 
    fread(h2_ref, sizeof(float), n, fh); 
    fread(h3_ref, sizeof(float), n, fh); 
    for (size_t i = 0; i < n; ++i) {
        diff1[i] = fabs(h1[i] - h1_ref[i]);
        diff2[i] = fabs(h2[i] - h2_ref[i]);
        diff3[i] = fabs(h3[i] - h3_ref[i]);
    }

    printf("    Difference F1: Min: %g Max: %g Avg: %g \n", min(diff1, ldimx, ldimy, ldimz), max(diff1, ldimx, ldimy, ldimz), absavg(diff1, ldimx, ldimy, ldimz));
    printf("    Difference F2: Min: %g Max: %g Avg: %g \n", min(diff2, ldimx, ldimy, ldimz), max(diff2, ldimx, ldimy, ldimz), absavg(diff2, ldimx, ldimy, ldimz));
    printf("    Difference F3: Min: %g Max: %g Avg: %g \n", min(diff3, ldimx, ldimy, ldimz), max(diff3, ldimx, ldimy, ldimz), absavg(diff3, ldimx, ldimy, ldimz));
    printf("    Max Relative Difference F1: Max: %g \n", max(diff1, ldimx, ldimy, ldimz) / max(h1_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F2: Max: %g \n", max(diff2, ldimx, ldimy, ldimz) / max(h2_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F3: Max: %g \n", max(diff3, ldimx, ldimy, ldimz) / max(h3_ref, ldimx, ldimy, ldimz) );

    delete[] h1;
    delete[] h2;
    delete[] h3;

    delete[] h1_ref;
    delete[] h2_ref;
    delete[] h3_ref;

    fclose(fh);


}

void check_plainLoop2(const char *filename, float *d1, float *d2, float *d3, float *d4, float *d5, float *d6, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "r");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }
        
    CUCHK(cudaDeviceSynchronize());

    size_t n = ldimx * ldimy * ldimz;
    printf("Reading: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));
    float *h1 = new float[n];
    float *h2 = new float[n];
    float *h3 = new float[n];
    float *h4 = new float[n];
    float *h5 = new float[n];
    float *h6 = new float[n];
    float *h1_ref = new float[n];
    float *h2_ref = new float[n];
    float *h3_ref = new float[n];
    float *h4_ref = new float[n];
    float *h5_ref = new float[n];
    float *h6_ref = new float[n];
    float *diff1 = new float[n];
    float *diff2 = new float[n];
    float *diff3 = new float[n];
    float *diff4 = new float[n];
    float *diff5 = new float[n];
    float *diff6 = new float[n];

    CUCHK(cudaMemcpy(h1, d1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h2, d2, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h3, d3, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h4, d4, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h5, d5, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h6, d6, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaDeviceSynchronize());

    fread(h1_ref, sizeof(float), n, fh); 
    fread(h2_ref, sizeof(float), n, fh); 
    fread(h3_ref, sizeof(float), n, fh); 
    fread(h4_ref, sizeof(float), n, fh); 
    fread(h5_ref, sizeof(float), n, fh); 
    fread(h6_ref, sizeof(float), n, fh); 
    for (size_t i = 0; i < n; ++i) {
        diff1[i] = fabs(h1[i] - h1_ref[i]);
        diff2[i] = fabs(h2[i] - h2_ref[i]);
        diff3[i] = fabs(h3[i] - h3_ref[i]);
        diff4[i] = fabs(h4[i] - h4_ref[i]);
        diff5[i] = fabs(h5[i] - h5_ref[i]);
        diff6[i] = fabs(h6[i] - h6_ref[i]);
    }

    printf("    Absolute Difference D1: Min: %g Max: %g Avg: %g \n", min(diff1, ldimx, ldimy, ldimz), max(diff1, ldimx, ldimy, ldimz), absavg(diff1, ldimx, ldimy, ldimz));
    printf("    Absolute Difference D2: Min: %g Max: %g Avg: %g \n", min(diff2, ldimx, ldimy, ldimz), max(diff2, ldimx, ldimy, ldimz), absavg(diff2, ldimx, ldimy, ldimz));
    printf("    Absolute Difference D3: Min: %g Max: %g Avg: %g \n", min(diff3, ldimx, ldimy, ldimz), max(diff3, ldimx, ldimy, ldimz), absavg(diff3, ldimx, ldimy, ldimz));
    printf("    Absolute Difference D4: Min: %g Max: %g Avg: %g \n", min(diff4, ldimx, ldimy, ldimz), max(diff4, ldimx, ldimy, ldimz), absavg(diff4, ldimx, ldimy, ldimz));
    printf("    Absolute Difference D5: Min: %g Max: %g Avg: %g \n", min(diff5, ldimx, ldimy, ldimz), max(diff5, ldimx, ldimy, ldimz), absavg(diff5, ldimx, ldimy, ldimz));
    printf("    Absolute Difference D6: Min: %g Max: %g Avg: %g \n", min(diff6, ldimx, ldimy, ldimz), max(diff6, ldimx, ldimy, ldimz), absavg(diff6, ldimx, ldimy, ldimz));

    printf("    Max Relative Difference D1: Max: %g \n", max(diff1, ldimx, ldimy, ldimz) / max(h1_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference D2: Max: %g \n", max(diff2, ldimx, ldimy, ldimz) / max(h2_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference D3: Max: %g \n", max(diff3, ldimx, ldimy, ldimz) / max(h3_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference D4: Max: %g \n", max(diff4, ldimx, ldimy, ldimz) / max(h4_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference D5: Max: %g \n", max(diff5, ldimx, ldimy, ldimz) / max(h5_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference D6: Max: %g \n", max(diff6, ldimx, ldimy, ldimz) / max(h6_ref, ldimx, ldimy, ldimz) );

    delete[] h1;
    delete[] h2;
    delete[] h3;
    delete[] h4;
    delete[] h5;
    delete[] h6;

    delete[] h1_ref;
    delete[] h2_ref;
    delete[] h3_ref;
    delete[] h4_ref;
    delete[] h5_ref;
    delete[] h6_ref;
    
    fclose(fh);
}


void check_plainLoop3(const char *filename, float *d1, float *d2, float *d3, float *d4, float *d5, float *d6, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "r");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }
        
    CUCHK(cudaDeviceSynchronize());

    size_t n = ldimx * ldimy * ldimz;
    printf("Reading: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));
    float *h1 = new float[n];
    float *h2 = new float[n];
    float *h3 = new float[n];
    float *h4 = new float[n];
    float *h5 = new float[n];
    float *h6 = new float[n];
    float *h1_ref = new float[n];
    float *h2_ref = new float[n];
    float *h3_ref = new float[n];
    float *h4_ref = new float[n];
    float *h5_ref = new float[n];
    float *h6_ref = new float[n];
    float *diff1 = new float[n];
    float *diff2 = new float[n];
    float *diff3 = new float[n];
    float *diff4 = new float[n];
    float *diff5 = new float[n];
    float *diff6 = new float[n];

    CUCHK(cudaMemcpy(h1, d1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h2, d2, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h3, d3, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h4, d4, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h5, d5, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaMemcpy(h6, d6, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaDeviceSynchronize());

    fread(h1_ref, sizeof(float), n, fh); 
    fread(h2_ref, sizeof(float), n, fh); 
    fread(h3_ref, sizeof(float), n, fh); 
    fread(h4_ref, sizeof(float), n, fh); 
    fread(h5_ref, sizeof(float), n, fh); 
    fread(h6_ref, sizeof(float), n, fh); 
    for (size_t i = 0; i < n; ++i) {
        diff1[i] = fabs(h1[i] - h1_ref[i]);
        diff2[i] = fabs(h2[i] - h2_ref[i]);
        diff3[i] = fabs(h3[i] - h3_ref[i]);
        diff4[i] = fabs(h4[i] - h4_ref[i]);
        diff5[i] = fabs(h5[i] - h5_ref[i]);
        diff6[i] = fabs(h6[i] - h6_ref[i]);
    }

    printf("    Difference F1: Min: %g Max: %g Avg: %g \n", min(diff1, ldimx, ldimy, ldimz), max(diff1, ldimx, ldimy, ldimz), absavg(diff1, ldimx, ldimy, ldimz));
    printf("    Difference F2: Min: %g Max: %g Avg: %g \n", min(diff2, ldimx, ldimy, ldimz), max(diff2, ldimx, ldimy, ldimz), absavg(diff2, ldimx, ldimy, ldimz));
    printf("    Difference F3: Min: %g Max: %g Avg: %g \n", min(diff3, ldimx, ldimy, ldimz), max(diff3, ldimx, ldimy, ldimz), absavg(diff3, ldimx, ldimy, ldimz));
    printf("    Difference F4: Min: %g Max: %g Avg: %g \n", min(diff4, ldimx, ldimy, ldimz), max(diff4, ldimx, ldimy, ldimz), absavg(diff4, ldimx, ldimy, ldimz));
    printf("    Difference F5: Min: %g Max: %g Avg: %g \n", min(diff5, ldimx, ldimy, ldimz), max(diff5, ldimx, ldimy, ldimz), absavg(diff5, ldimx, ldimy, ldimz));
    printf("    Difference F6: Min: %g Max: %g Avg: %g \n", min(diff6, ldimx, ldimy, ldimz), max(diff6, ldimx, ldimy, ldimz), absavg(diff6, ldimx, ldimy, ldimz));

    printf("    Max Relative Difference F1: Max: %g \n", max(diff1, ldimx, ldimy, ldimz) / max(h1_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F2: Max: %g \n", max(diff2, ldimx, ldimy, ldimz) / max(h2_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F3: Max: %g \n", max(diff3, ldimx, ldimy, ldimz) / max(h3_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F4: Max: %g \n", max(diff4, ldimx, ldimy, ldimz) / max(h4_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F5: Max: %g \n", max(diff5, ldimx, ldimy, ldimz) / max(h5_ref, ldimx, ldimy, ldimz) );
    printf("    Max Relative Difference F6: Max: %g \n", max(diff6, ldimx, ldimy, ldimz) / max(h6_ref, ldimx, ldimy, ldimz) );

    delete[] h1;
    delete[] h2;
    delete[] h3;
    delete[] h4;
    delete[] h5;
    delete[] h6;

    delete[] h1_ref;
    delete[] h2_ref;
    delete[] h3_ref;
    delete[] h4_ref;
    delete[] h5_ref;
    delete[] h6_ref;

    fclose(fh);
}

void check_array(const char *filename, const char *label, float *d1, int ldimx, int ldimy, int ldimz) {

    FILE *fh = fopen(filename, "r");


    if (!fh) {
        fprintf(stderr, "Failed to open: %s\n", filename);
        exit(-1);
    }
        
    CUCHK(cudaDeviceSynchronize());

    size_t n = ldimx * ldimy * ldimz;
    printf("Reading: %s of size %d x %d x %d (%g MB) \n", filename, ldimx, ldimy, ldimz, n / 1e6 * sizeof(float));
    float *h1 = new float[n];
    float *h1_ref = new float[n];
    float *diff1 = new float[n];

    CUCHK(cudaMemcpy(h1, d1, n * sizeof(float), cudaMemcpyDeviceToHost));
    CUCHK(cudaDeviceSynchronize());

    fread(h1_ref, sizeof(float), n, fh); 
    for (size_t i = 0; i < n; ++i) {
        diff1[i] = fabs(h1[i] - h1_ref[i]);
    }

    printf("    %s Difference: Min: %g Max: %g Avg: %g \n", label, min(diff1, ldimx, ldimy, ldimz), max(diff1, ldimx, ldimy, ldimz), absavg(diff1, ldimx, ldimy, ldimz));
    printf("    %s Max Relative Difference: Max: %g \n", label, max(diff1, ldimx, ldimy, ldimz) / max(h1_ref, ldimx, ldimy, ldimz) );

    delete[] h1;
    delete[] h1_ref;

    fclose(fh);
}
