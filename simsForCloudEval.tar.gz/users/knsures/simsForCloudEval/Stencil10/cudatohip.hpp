#pragma once

#define cudaMalloc hipMalloc
#define cudaDeviceSynchronize hipDeviceSynchronize
#define cudaSuccess hipSuccess
#define cudaError_t hipError_t
#define cudaMemcpy hipMemcpy
#define cudaMemcpyDeviceToHost hipMemcpyDeviceToHost
#define cudaGetErrorString hipGetErrorString
#define __pipeline_memcpy_async(a, b, c) *a = *(b)
#define __pipeline_commit()
#define __pipeline_wait_prior(x)
#define cudaFuncSetAttribute(a,b,c,d) cudaSuccess
#define cudaFuncAttributeMaxDynamicSharedMemorySize
#define cudaMemcpyToSymbol hipMemcpyToSymbol
#define cudaEventCreate hipEventCreate
#define cudaEventRecord hipEventRecord
#define cudaEventSynchronize hipEventSynchronize
#define cudaEventElapsedTime hipEventElapsedTime
#define cudaEventDestroy hipEventDestroy
#define cudaEvent_t hipEvent_t
