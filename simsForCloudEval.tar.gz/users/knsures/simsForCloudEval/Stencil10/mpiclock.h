#include <sys/time.h>

#pragma once

inline double MPI_Wtime()
{
  struct timeval t;
  gettimeofday (&t, NULL);
  return ((double)t.tv_sec + (double)t.tv_usec * 1E-6);
}