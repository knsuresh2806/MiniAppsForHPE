#include <iostream>
#include <stdio.h>
#include <math.h>

#include <hip/hip_runtime.h>
#include "cudatohip.hpp"
#include "mpiclock.h"
#include "common.cuh"
#include "check.hpp"



// ****************************************************************************
// Initialize the arrays like the CPU code

__global__ void init(float *field1, float *field2, float *field3, float *field4, float *field5,
                     float *field6, float *field7, float *field8, float *field9, float *M1,
                     float *M2, float *M3, float *M4, float *M5, float *M6,
                     float *M7, float *M8, float *M9, float *M10, float *M11,
                     float *M12, float *M13, float *M14, float *M15, float *M16,
                     float *M17, float *M18, float *M19, float *M20, float *M21,
                     float *M22, float *der1, float *der4, float *der6,
                     float *der2, float *der3, float *der5, float *zprime,
                     int ldimx, int ldimy)
{
    int ix = blockIdx.x * blockDim.x + threadIdx.x;
    if (ix >= ldimx)
        return;
    int iy = blockIdx.y;
    int iz = blockIdx.z;
    int index = (iz * ldimy + iy) * ldimx + ix;
    field1[index] = sinf(iz + iy + ix);
    field2[index] = cosf(iz + iy + ix);
    field3[index] = sinf(2.0f * iz + iy + ix);
    field4[index] = cosf(2.0f * iz + iy + ix);
    field5[index] = sinf(iz + 2.0f * iy + ix);
    field6[index] = cosf(iz + 2.0f * iy + ix);
    field7[index] = sinf(iz + iy + 2.0 * ix);
    field8[index] = cosf(iz + iy + 2.0 * ix);
    field9[index] = sinf(3.0f * iz + iy + ix);
    M1[index] = cosf(3.0f * iz + iy + ix);
    M2[index] = sinf(iz + 3.0f * iy + ix);
    M3[index] = cosf(iz + 3.0f * iy + ix);
    M4[index] = sinf(iz + iy + 3.0f * ix);
    M5[index] = cosf(iz + iy + 3.0f * ix);
    M6[index] = sinf(4.0f * iz + iy + ix);
    M7[index] = cosf(4.0f * iz + iy + ix);
    M8[index] = sinf(iz + 4.0f * iy + ix);
    M9[index] = cosf(iz + 4.0f * iy + ix);
    M10[index] = sinf(iz + iy + 5.0f * ix);
    M11[index] = cosf(iz + iy + 5.0f * ix);
    M12[index] = sinf(6.0f * iz + iy + ix);
    M13[index] = cosf(6.0f * iz + iy + ix);
    M14[index] = sinf(iz + 6.0f * iy + ix);
    M15[index] = cosf(iz + 6.0f * iy + ix);
    M16[index] = sinf(iz + iy + 6.0f * ix);
    M17[index] = cosf(iz + iy + 6.0f * ix);
    M18[index] = sinf(7.0f * iz + iy + ix);
    M19[index] = cosf(7.0f * iz + iy + ix);
    M20[index] = sinf(iz + 7.0f * iy + ix);
    M21[index] = cosf(iz + 7.0f * iy + ix);
    der1[index] = sinf(iz + iy + 7.0f * ix);
    der2[index] = cosf(iz + iy + 7.0f * ix);
    der3[index] = sinf(8.0f * iz + iy + ix);
    der4[index] = cosf(8.0f * iz + iy + ix);
    der5[index] = sinf(iz + 8.0f * iy + ix);
    der6[index] = cosf(iz + 8.0f * iy + ix);
    M22[index] = sinf(iz + iy + 8.0f * ix);
    if (ix == 0 && iy == 0)
        zprime[iz] = cosf(8.0f * iz);
}

// ****************************************************************************
// Compute 16th order 1st derivative from a pointer with a stride known
// at compile time (e.g. register queue, shared memory)
// If shift is true, the staggered derivative is shifted one point down

template <bool SHIFT, int STRIDE>
__device__ inline float drv1_16(float *p)
{
    constexpr int is = SHIFT ? -1 : 0;
    float drv = DF_order16[0] * (p[(is + 1) * STRIDE] - p[is * STRIDE]);
#pragma unroll
    for (int i = 1; i < 8; i++)
        drv += DF_order16[i] * (p[(is + i + 1) * STRIDE] - p[(is - i) * STRIDE]);
    return drv;
}

// ****************************************************************************
// Compute the mixed derivative in XY from a pointer in shared memory
// If XS or YS are true, the indices for (X,Y) are shifted down by 1

template <bool XS, bool YS, int STRIDE_Y>
__device__ inline float mixed_XY(float *sm)
{
    constexpr int xs = XS ? -1 : 0;
    constexpr int ys = YS ? -1 : 0;
    float drv = 0.0f;
#pragma unroll
    for (int i = 0; i < 8; i++)
        drv += INT_S_O16[i] * (sm[(ys + i + 1) * STRIDE_Y + xs + i + 1] +
                               sm[(ys + i + 1) * STRIDE_Y + xs - i] +
                               sm[(ys - i) * STRIDE_Y + xs + i + 1] +
                               sm[(ys - i) * STRIDE_Y + xs - i]);

    return (0.5f * drv);
}

// ****************************************************************************
// plain1Kernel 16th order, using a tile of 32 x 16 threads
// Traditional 2D shared memory and register queue approach.
// Using 2 layers of shared memory to async load the next iteration while
// working on the current iteration.

template <int TILE_Z = 64>
__launch_bounds__(32 * 16, 1)
    __global__ void plain1Kernel(float *__restrict__ field1,
                                   float *__restrict__ field2,
                                   float *__restrict__ field3,
                                   const float *__restrict__ field4,
                                   const float *__restrict__ field5,
                                   const float *__restrict__ field6,
                                   const float *__restrict__ field7,
                                   const float *__restrict__ field8,
                                   const float *__restrict__ field9,
                                   const float *__restrict__ M22,
                                   const float *__restrict__ zprime,
                                   int ldimx,
                                   int ldimy,
                                   int nz)
{
    const float invd1 = 1.01f;
    const float invd2 = 2.01f;

    __shared__ float shm11[2][16][48]; // SHM11: Center + X halos
    __shared__ float shm13[2][16][48]; // SHM13: Center from register queue + X halos
    __shared__ float shm22[2][32][32]; // SHM22: Center + Y halos
    __shared__ float shm23[2][32][32]; // SHM23: Center from register queue + Y halos
    __shared__ float shm12[2][32][48]; // SHM12: Center + X halos + Y halos

    // Register queues for the Z derivatives
    float rq33[17];
    float rq13[17];
    float rq23[17];
    float m22z;

    const int tx = threadIdx.x + 8;
    const int ty = threadIdx.y + 8;
    const int ix = blockIdx.x * 32 + tx;
    const int iy = blockIdx.y * 16 + ty;
    const int iz = blockIdx.z * TILE_Z;
    const int zblock = min(TILE_Z, nz - iz);
    const int stride = ldimx * ldimy;

    // Index to load the register queues in Z
    int index_z = (iz * ldimy + iy) * ldimx + ix;
    // Index of the point to be computed
    int index = index_z + 8 * stride;

    // Prime the register queues in Z
    for (int i = 0; i < 16; i++)
    {
        rq13[i] = field8[index_z];
        rq23[i] = field9[index_z];
        rq33[i] = field6[index_z];
        index_z += stride;
    }
    m22z = M22[index - stride];

    // Prime the shared memory
    __pipeline_memcpy_async(&shm11[0][threadIdx.y][tx], &field4[index], sizeof(float));                           // Center of shm11
    __pipeline_memcpy_async(&shm22[0][threadIdx.y][threadIdx.x], &field5[index - 8 * ldimx], sizeof(float));      // First half of shm22
    __pipeline_memcpy_async(&shm22[0][threadIdx.y + 16][threadIdx.x], &field5[index + 8 * ldimx], sizeof(float)); // Second half of shm22
    __pipeline_memcpy_async(&shm12[0][threadIdx.y][tx], &field7[index - 8 * ldimx], sizeof(float));               // First half of shm12, minus X halos
    __pipeline_memcpy_async(&shm12[0][threadIdx.y + 16][tx], &field7[index + 8 * ldimx], sizeof(float));          // Second half of shm12, minus X halos
    if (threadIdx.y < 8)
        __pipeline_memcpy_async(&shm23[0][threadIdx.y][threadIdx.x], &field9[index - 8 * ldimx], sizeof(float)); // Y- halos of shm23
    else
        __pipeline_memcpy_async(&shm23[0][threadIdx.y + 16][threadIdx.x], &field9[index + 8 * ldimx], sizeof(float)); // Y+ halos of shm23
    if (threadIdx.x < 8)
    {
        __pipeline_memcpy_async(&shm11[0][threadIdx.y][threadIdx.x], &field4[index - 8], sizeof(float));       // X- halos of shm11
        __pipeline_memcpy_async(&shm11[0][threadIdx.y][tx + 32], &field4[index + 32], sizeof(float)); // X+ halos of shm11
        __pipeline_memcpy_async(&shm13[0][threadIdx.y][threadIdx.x], &field8[index - 8], sizeof(float));       // X- halos of shm13
        __pipeline_memcpy_async(&shm13[0][threadIdx.y][tx + 32], &field8[index + 32], sizeof(float)); // X+ halos of shm13
        __pipeline_memcpy_async(&shm12[0][ty][threadIdx.x], &field7[index - 8], sizeof(float));                // X- halos of shm12
        __pipeline_memcpy_async(&shm12[0][ty][tx + 32], &field7[index + 32], sizeof(float));                   // X+ halos of shm12
    }
    __pipeline_commit();

    int k = 1; // Shared memory index flip-flop between 0 and 1. Loaded in 0, now ready to load 1.

    for (int zloop = 0; zloop < zblock; zloop++)
    {
        // Read new register queue values
        rq13[16] = field8[index_z];
        rq23[16] = field9[index_z];
        rq33[16] = field6[index_z];
        index_z += stride;

        // Async load the shared memory for the next iteration
        __pipeline_memcpy_async(&shm11[k][threadIdx.y][tx], &field4[index + stride], sizeof(float));                           // Center of shm11
        __pipeline_memcpy_async(&shm22[k][threadIdx.y][threadIdx.x], &field5[index + stride - 8 * ldimx], sizeof(float));      // First half of shm22
        __pipeline_memcpy_async(&shm22[k][threadIdx.y + 16][threadIdx.x], &field5[index + stride + 8 * ldimx], sizeof(float)); // Second half of shm22
        __pipeline_memcpy_async(&shm12[k][threadIdx.y][tx], &field7[index + stride - 8 * ldimx], sizeof(float));               // First half of shm12, minus X halos
        __pipeline_memcpy_async(&shm12[k][threadIdx.y + 16][tx], &field7[index + stride + 8 * ldimx], sizeof(float));          // Second half of shm12, minus X halos
        if (threadIdx.y < 8)
            __pipeline_memcpy_async(&shm23[k][threadIdx.y][threadIdx.x], &field9[index + stride - 8 * ldimx], sizeof(float)); // Y- halos of shm23
        else
            __pipeline_memcpy_async(&shm23[k][threadIdx.y + 16][threadIdx.x], &field9[index + stride + 8 * ldimx], sizeof(float)); // Y+ halos of shm23
        if (threadIdx.x < 8)
        {
            __pipeline_memcpy_async(&shm11[k][threadIdx.y][threadIdx.x], &field4[index + stride - 8], sizeof(float));       // X- halos of shm11
            __pipeline_memcpy_async(&shm11[k][threadIdx.y][tx + 32], &field4[index + stride + 32], sizeof(float)); // X+ halos of shm11
            __pipeline_memcpy_async(&shm13[k][threadIdx.y][threadIdx.x], &field8[index + stride - 8], sizeof(float));       // X- halos of shm13
            __pipeline_memcpy_async(&shm13[k][threadIdx.y][tx + 32], &field8[index + stride + 32], sizeof(float)); // X+ halos of shm13
            __pipeline_memcpy_async(&shm12[k][ty][threadIdx.x], &field7[index + stride - 8], sizeof(float));                // X- halos of shm12
            __pipeline_memcpy_async(&shm12[k][ty][tx + 32], &field7[index + stride + 32], sizeof(float));                   // X+ halos of shm12
        }
        __pipeline_commit();

        // Switch back to the other shared memory
        k ^= 1;

        // Fill the center sections of shared memory with register queues
        shm13[k][threadIdx.y][tx] = rq13[8];
        shm23[k][ty][threadIdx.x] = rq23[8];

        // Wait for the previous stage to complete
        __pipeline_wait_prior(1);
        __syncthreads();

        float dt11d1 = drv1_16<true, 1>(&shm11[k][threadIdx.y][tx]);
        float dt22d2 = drv1_16<true, 32>(&shm22[k][ty][threadIdx.x]);
        float dt33d3 = drv1_16<true, 1>(&rq33[8]);
        float dt12d1 = drv1_16<false, 1>(&shm12[k][ty][tx]);
        float dt12d2 = drv1_16<false, 48>(&shm12[k][ty][tx]);
        float dt13d3 = drv1_16<false, 1>(&rq13[8]);
        float dt13d1 = drv1_16<false, 1>(&shm13[k][threadIdx.y][tx]);
        float dt23d2 = drv1_16<false, 32>(&shm23[k][ty][threadIdx.x]);
        float dt23d3 = drv1_16<false, 1>(&rq23[8]);

        __syncthreads();

        // Rely on the L1 cache to load the M22 model efficiently
        float zpr = zprime[iz + 8 + zloop];
        float res1 = (2.0f * M22[index - 1]) * (dt11d1 * invd1 + dt12d2 * invd2 + dt13d3 * zpr);
        float res2 = (2.0f * M22[index - ldimx]) * (dt12d1 * invd1 + dt22d2 * invd2 + dt23d3 * zpr);
        float res3 = (2.0f * m22z) * (dt13d1 * invd1 + dt23d2 * invd2 + dt33d3 * zpr);
        m22z = M22[index];

        // Using atomics to let the L2 cache do the load-add-store, instead of the SM.
        atomicAdd(field1 + index, res1);
        atomicAdd(field2 + index, res2);
        atomicAdd(field3 + index, res3);
        index += stride;

        // Rotate the register queues
        for (int i = 0; i < 16; i++)
        {
            rq13[i] = rq13[i + 1];
            rq23[i] = rq23[i + 1];
            rq33[i] = rq33[i + 1];
        }
    }
}

// ****************************************************************************

void plainLoop1(float *field1, float *field2, float *field3,
                  float *field4, float *field5, float *field6,
                  float *field7, float *field8, float *field9,
                  float *M22, float *zprime, int nx, int ny, int nz, int ldimx, int ldimy)
{
    constexpr int tile_z = 64;
    dim3 threads(32, 16, 1);
    dim3 blocks((nx + 31) / 32, (ny + 15) / 16, (nz - 1) / tile_z + 1);
    plain1Kernel<tile_z><<<blocks, threads, 0, 0>>>(field1, field2, field3, field4, field5, field6,
                                                      field7, field8, field9, M22, zprime,
                                                      ldimx, ldimy, nz);
}

// ****************************************************************************
// plain1Kernel 16th order, using a tile of 32 x 16 threads
// Traditional 2D shared memory and register queue approach.
// Using 2 layers of shared memory to async load the next iteration while
// working on the current iteration.

template <int TILE_Z>
__launch_bounds__(32 * 16)
    __global__ void plain2Kernel(float *__restrict__ field1,
                                           float *__restrict__ field2,
                                           float *__restrict__ field3,
                                           float *__restrict__ der1,
                                           float *__restrict__ der2,
                                           float *__restrict__ der3,
                                           float *__restrict__ der4,
                                           float *__restrict__ der5,
                                           float *__restrict__ der6,
                                           float *__restrict__ zprime,
                                           int ldimx,
                                           int ldimy,
                                           int nz)
{
    const float invd1 = 1.01f;
    const float invd2 = 2.02f;
    __shared__ float shm1[2][32][48];
    __shared__ float shm2[2][32][48];
    __shared__ float shm3[2][32][48];

    // Register queues for the Z derivatives
    float rq1[17];
    float rq2[17];
    float rq3[17];

    const int tx = threadIdx.x + 8;
    const int ty = threadIdx.y + 8;
    const int ix = blockIdx.x * 32 + tx;
    const int iy = blockIdx.y * 16 + ty;
    const int iz = blockIdx.z * TILE_Z;
    const int stride = ldimx * ldimy;

    // Index to load the register queues in Z
    int index_z = (iz * ldimy + iy) * ldimx + ix;
    // Index of the point to be computed
    int index = index_z + 8 * stride;

    // Prime the register queues
    for (int i = 0; i < 16; i++)
    {
        rq1[i] = field1[index_z];
        rq2[i] = field2[index_z];
        rq3[i] = field3[index_z];
        index_z += stride;
    }

    int k = 0; // Shared memory index flip-flop between 0 and 1. Loaded in 0, now ready to load 1.

    int nzblock = min(TILE_Z, nz - iz);
    for (int zloop = 0; zloop < nzblock; zloop++)
    {

        // Read new register queue values
        rq1[16] = field1[index_z];
        rq2[16] = field2[index_z];
        rq3[16] = field3[index_z];
        index_z += stride;

        __syncthreads();
        if (threadIdx.x < 8)
        {
            shm1[0][ty][threadIdx.x] = field1[index - 8];
            shm2[0][ty][threadIdx.x] = field2[index - 8];
            shm3[0][ty][threadIdx.x] = field3[index - 8];
            shm1[0][ty][tx + 32] = field1[index + 32];
            shm2[0][ty][tx + 32] = field2[index + 32];
            shm3[0][ty][tx + 32] = field3[index + 32];
        }
        if (threadIdx.y < 8)
        {
            shm1[0][threadIdx.y][tx] = field1[index - 8 * ldimx];
            shm2[0][threadIdx.y][tx] = field2[index - 8 * ldimx];
            shm3[0][threadIdx.y][tx] = field3[index - 8 * ldimx];
            shm1[0][ty + 16][tx] = field1[index + 16 * ldimx];
            shm2[0][ty + 16][tx] = field2[index + 16 * ldimx];
            shm3[0][ty + 16][tx] = field3[index + 16 * ldimx];
        }

        // Fill the center sections of shared memory with register queues
        shm1[k][ty][tx] = rq1[8];
        shm2[k][ty][tx] = rq2[8];
        shm3[k][ty][tx] = rq3[8];

        __syncthreads();

        float dv1d1 = drv1_16<false, 1>(&shm1[k][ty][tx]);  // X drv on sm1
        float dv2d2 = drv1_16<false, 48>(&shm2[k][ty][tx]); // Y drv on sm2
        float dv3d3 = drv1_16<false, 1>(&rq3[8]);           // Z drv on rq3
        float dv1d2 = drv1_16<true, 48>(&shm1[k][ty][tx]);  // Y drv on sm1
        float dv2d1 = drv1_16<true, 1>(&shm2[k][ty][tx]);   // X drv on sm2
        float dv1d3 = drv1_16<true, 1>(&rq1[8]);            // Z drv on rq1
        float dv3d1 = drv1_16<true, 1>(&shm3[k][ty][tx]);   // X drv on sm3
        float dv2d3 = drv1_16<true, 1>(&rq2[8]);            // Z drv on rq2
        float dv3d2 = drv1_16<true, 48>(&shm3[k][ty][tx]);  // Y drv on sm3

        __syncthreads();

        float zpr = zprime[iz + 8 + zloop];

        der1[index] = invd1 * dv1d1;
        der2[index] = invd2 * dv1d2 + invd1 * dv2d1;
        der3[index] = zpr * dv1d3 + invd1 * dv3d1;
        der4[index] = invd2 * dv2d2;
        der5[index] = zpr * dv2d3 + invd2 * dv3d2;
        der6[index] = zpr * dv3d3;
        index += stride;

        // Rotate the register queues
        for (int i = 0; i < 16; i++)
        {
            rq1[i] = rq1[i + 1];
            rq2[i] = rq2[i + 1];
            rq3[i] = rq3[i + 1];
        }
    }
}

// ****************************************************************************

void plainLoop2(float *field1, float *field2, float *field3,
                          float *der1, float *der2, float *der3,
                          float *der4, float *der5, float *der6,
                          float *zprime, int nx, int ny, int nz, int ldimx, int ldimy)
{
    constexpr int tile_z = 64;
    dim3 threads(32, 16, 1);
    dim3 blocks((nx + 31) / 32, (ny + 15) / 16, (nz - 1) / tile_z + 1);
    plain2Kernel<tile_z><<<blocks, threads, 0, 0>>>(field1, field2, field3,
                                                              der1, der2, der3,
                                                              der4, der5, der6,
                                                              zprime, ldimx, ldimy, nz);
}

// ******************************************************************************************
// Pre-compute mixed derivatives that involve the Z dimensions: XZ and YZ
// Instead of using a large 3D shared memory array, we use register queues to store
// partially computed values, that we update every time we get new data in a
// 2D shared memory plan. The shared memory is prefetched asynchronously.
// XS, YS, ZS are flags (0, 1) if the inputs must be shifted down by 1

template <int XS, int YS, int ZS, int TILE_X, int TILE_Y, int TILE_Z>
__launch_bounds__(TILE_X *TILE_Y)
    __global__ void precompute_xz_yz(const float *__restrict__ input,
                                     float *__restrict__ drvxz,
                                     float *__restrict__ drvyz,
                                     int ldimx, int ldimy, int nz)
{
    __shared__ float sm[2][TILE_Y + 16][TILE_X + 16];
    // Partial contributions register queues
    float rqxz[16];
    float rqyz[16];

    const int stride = ldimx * ldimy;

    const int tx = threadIdx.x + 8;
    const int ty = threadIdx.y + 8;
    const int ix = blockIdx.x * TILE_X + tx;
    const int iy = blockIdx.y * TILE_Y + ty;
    const int iz = blockIdx.z * TILE_Z;

    int index = ((iz + 8) * ldimy + iy) * ldimx + ix;
    int index_ld = index - (7 + ZS) * stride;

    for (int i = 0; i < 16; i++)
    {
        rqxz[i] = 0.0f;
        rqyz[i] = 0.0f;
    }

    const int X1 = -7 - XS;
    const int Y1 = -7 - YS;
    const int X2 = 8 - XS;
    const int Y2 = 8 - YS;

    // Preload the first shared memory plan
    __pipeline_memcpy_async(&sm[0][ty][tx], &input[index_ld], sizeof(float));
    if (threadIdx.x < 8)
    {
        __pipeline_memcpy_async(&sm[0][ty][threadIdx.x], &input[index_ld - 8], sizeof(float));
        __pipeline_memcpy_async(&sm[0][ty][tx + TILE_X], &input[index_ld + TILE_X], sizeof(float));
    }
    if (threadIdx.y < 8)
    {
        __pipeline_memcpy_async(&sm[0][threadIdx.y][tx], &input[index_ld - 8 * ldimx], sizeof(float));
        __pipeline_memcpy_async(&sm[0][ty + TILE_Y][tx], &input[index_ld + TILE_Y * ldimx], sizeof(float));
    }
    __pipeline_commit();
    index_ld += stride;
        __syncthreads();

    int k = 1; // Shared memory index flip-flop between 0 and 1. Loaded in 0, now ready to load 1.

    // Prime the partial contributions
#pragma unroll
    for (int i = 0; i < 15; i++)
    {
        __syncthreads();
        // Preload the input data for the next iteration
        __pipeline_memcpy_async(&sm[k][ty][tx], &input[index_ld], sizeof(float));
        if (threadIdx.x < 8)
        {
            __pipeline_memcpy_async(&sm[k][ty][threadIdx.x], &input[index_ld - 8], sizeof(float));
            __pipeline_memcpy_async(&sm[k][ty][tx + TILE_X], &input[index_ld + TILE_X], sizeof(float));
        }
        if (threadIdx.y < 8)
        {
            __pipeline_memcpy_async(&sm[k][threadIdx.y][tx], &input[index_ld - 8 * ldimx], sizeof(float));
            __pipeline_memcpy_async(&sm[k][ty + TILE_Y][tx], &input[index_ld + TILE_Y * ldimx], sizeof(float));
        }
        index_ld += stride;
        __pipeline_commit();

        // Switch to the shared memory for the current iteration
        k ^= 1;

        // Wait for the previous async stage to finish
        __pipeline_wait_prior(1);
        __syncthreads();

        // Update the partial contributions
#pragma unroll
        for (int j = 0; j <= i; j++)
        {
            int icoef = max(7 - i, i - 8);
            rqxz[j] += INT_S_O16[icoef] * (sm[k][ty][tx + X1 + i - j] + sm[k][ty][tx + X2 - i + j]);
            rqyz[j] += INT_S_O16[icoef] * (sm[k][ty + Y1 + i - j][tx] + sm[k][ty + Y2 - i + j][tx]);
        }
        __syncthreads();
    }

    int nzloop = min(TILE_Z, nz - iz);

    // Loop on all the Z block
    for (int zloop = 0; zloop < nzloop; zloop++)
    {
        __syncthreads();
        if (zloop < nzloop - 1)
        {
            // Preload the input data for the next iteration
            __pipeline_memcpy_async(&sm[k][ty][tx], &input[index_ld], sizeof(float));
            if (threadIdx.x < 8)
            {
                __pipeline_memcpy_async(&sm[k][ty][threadIdx.x], &input[index_ld - 8], sizeof(float));
                __pipeline_memcpy_async(&sm[k][ty][tx + TILE_X], &input[index_ld + TILE_X], sizeof(float));
            }
            if (threadIdx.y < 8)
            {
                __pipeline_memcpy_async(&sm[k][threadIdx.y][tx], &input[index_ld - 8 * ldimx], sizeof(float));
                __pipeline_memcpy_async(&sm[k][ty + TILE_Y][tx], &input[index_ld + TILE_Y * ldimx], sizeof(float));
            }
            index_ld += stride;
            __pipeline_commit();
        }

        // Switch to the shared memory for the current iteration
        k ^= 1;
        __pipeline_wait_prior(1);
        __syncthreads();

        // Update the partial contributions
#pragma unroll
        for (int i = 0; i < 16; i++)
        {
            int icoef = max(7 - i, i - 8);
            rqxz[i] += INT_S_O16[icoef] * (sm[k][ty][tx + X1 + i] + sm[k][ty][tx + X2 - i]);
            rqyz[i] += INT_S_O16[icoef] * (sm[k][ty + Y1 + i][tx] + sm[k][ty + Y2 - i][tx]);
        }
        __syncthreads();

        // The oldest partial values are now complete. Store the results
        drvxz[index] = 0.5f * rqxz[0];
        drvyz[index] = 0.5f * rqyz[0];
        index += stride;

        // Rotate the register queues, and zero the newest partial values
        for (int i = 0; i < 15; i++)
        {
            rqxz[i] = rqxz[i + 1];
            rqyz[i] = rqyz[i + 1];
        }
        rqxz[15] = 0.0f;
        rqyz[15] = 0.0f;
    }
}

// ****************************************************************************

template <int TILE_X, int TILE_Y>
__device__ inline void loadShared(float *sm, const int &smindex,
                                  const float *data, const int &index, const int &ldimx)
{
    constexpr int smdimx = TILE_X + 16;
    sm[smindex] = data[index];
    if (threadIdx.x < 8)
    {
        sm[smindex - 8] = data[index - 8];
        sm[smindex + TILE_X] = data[index + TILE_X];
    }
    if (threadIdx.y < 8)
    {
        sm[smindex - 8 * smdimx] = data[index - 8 * ldimx];
        sm[smindex + TILE_Y * smdimx] = data[index + TILE_Y * ldimx];
    }
    if (threadIdx.x < 8 && threadIdx.y < 8)
    {
        sm[smindex - 8 * smdimx - 8] = data[index - 8 * ldimx - 8];
        sm[smindex - 8 * smdimx + TILE_X] = data[index - 8 * ldimx + TILE_X];
        sm[smindex + TILE_Y * smdimx - 8] = data[index + TILE_Y * ldimx - 8];
        sm[smindex + TILE_Y * smdimx + TILE_X] = data[index + TILE_Y * ldimx + TILE_X];
    }
}

// ****************************************************************************
// Main plainLoop3 kernel
// All the components depending on the Z dimension have been pre-computed,
// no need for the thread blocks to walk through the Z dimension.

template <int TILE_X = 32, int TILE_Y = 32>
__launch_bounds__(TILE_X *TILE_Y, 1)
    __global__ void plain3Kernel(float *__restrict__ field4,
                                      float *__restrict__ field5,
                                      float *__restrict__ field6,
                                      float *__restrict__ field7,
                                      float *__restrict__ field8,
                                      float *__restrict__ field9,
                                      const float *__restrict__ M1,
                                      const float *__restrict__ M2,
                                      const float *__restrict__ M3,
                                      const float *__restrict__ M4,
                                      const float *__restrict__ M5,
                                      const float *__restrict__ M6,
                                      const float *__restrict__ M7,
                                      const float *__restrict__ M8,
                                      const float *__restrict__ M9,
                                      const float *__restrict__ M10,
                                      const float *__restrict__ M11,
                                      const float *__restrict__ M12,
                                      const float *__restrict__ M13,
                                      const float *__restrict__ M14,
                                      const float *__restrict__ M15,
                                      const float *__restrict__ M16,
                                      const float *__restrict__ M17,
                                      const float *__restrict__ M18,
                                      const float *__restrict__ M19,
                                      const float *__restrict__ M20,
                                      const float *__restrict__ M21,
                                      const float *__restrict__ der_1,
                                      const float *__restrict__ der_2,
                                      const float *__restrict__ der_3,
                                      const float *__restrict__ der_4,
                                      const float *__restrict__ der_5,
                                      const float *__restrict__ der_6,
                                      const float *__restrict__ der_7,
                                      const float *__restrict__ der_8,
                                      const float *__restrict__ der_9,
                                      const float *__restrict__ der_10,
                                      const float *__restrict__ der_11,
                                      const float *__restrict__ der_12,
                                      const float *__restrict__ der_13,
                                      const float *__restrict__ der_14,
                                      const float *__restrict__ der_15,
                                      const float *__restrict__ der_16,
                                      const float *__restrict__ der_17,
                                      const float *__restrict__ der_18,
                                      int ldimx, int ldimy)
{
    // Shared memory is (TILE_X + 16) * (TILE_Y + 16), for each of the 6 input arrays
    extern __shared__ float sm_1_1[];
    float *sm_2_2 = sm_1_1 + (TILE_X + 16) * (TILE_Y + 16);
    float *sm_3_3 = sm_2_2 + (TILE_X + 16) * (TILE_Y + 16);
    float *sm_1_2 = sm_3_3 + (TILE_X + 16) * (TILE_Y + 16);
    float *sm_1_3 = sm_1_2 + (TILE_X + 16) * (TILE_Y + 16);
    float *sm_2_3 = sm_1_3 + (TILE_X + 16) * (TILE_Y + 16);
    constexpr int smdimx = TILE_X + 16;
    const int smindex = (threadIdx.y + 8) * smdimx + threadIdx.x + 8; // Natural index within a 2D shared memory plan

    int ix = blockIdx.x * TILE_X + threadIdx.x + 8;
    int iy = blockIdx.y * TILE_Y + threadIdx.y + 8;
    int iz = blockIdx.z + 8;
    int index = (iz * ldimy + iy) * ldimx + ix;

    // Load all the 6 x V arrays in shared memory to compute XY derivatives
    loadShared<TILE_X, TILE_Y>(sm_1_1, smindex, der_1, index, ldimx);
    loadShared<TILE_X, TILE_Y>(sm_2_2, smindex, der_4, index, ldimx);
    loadShared<TILE_X, TILE_Y>(sm_3_3, smindex, der_6, index, ldimx);
    loadShared<TILE_X, TILE_Y>(sm_1_2, smindex, der_2, index, ldimx);
    loadShared<TILE_X, TILE_Y>(sm_1_3, smindex, der_3, index, ldimx);
    loadShared<TILE_X, TILE_Y>(sm_2_3, smindex, der_5, index, ldimx);

    __syncthreads();

    float dv1d1 = sm_1_1[smindex];
    float dv2d2 = sm_2_2[smindex];
    float dv3d3 = sm_3_3[smindex];

    float dv1d2 = sm_1_2[smindex];
    float dv1d3 = sm_1_3[smindex];
    float dv2d3 = sm_2_3[smindex];

    float dv1d2_xx = mixed_XY<false, false, smdimx>(&sm_1_2[smindex]);
    float dv1d3_xx = der_11[index];
    float dv2d3_xx = der_16[index];

    field4[index] += M1[index] * dv1d1 + M2[index] * dv2d2 + M3[index] * dv3d3 +
                  M6[index] * dv1d2_xx + M5[index] * dv1d3_xx + M4[index] * dv2d3_xx;

    field5[index] += M2[index] * dv1d1 + M7[index] * dv2d2 + M8[index] * dv3d3 +
                  M11[index] * dv1d2_xx + M10[index] * dv1d3_xx + M9[index] * dv2d3_xx;

    field6[index] += M3[index] * dv1d1 + M8[index] * dv2d2 + M12[index] * dv3d3 +
                  M15[index] * dv1d2_xx + M14[index] * dv1d3_xx + M13[index] * dv2d3_xx;

    float dv1d1_xy = mixed_XY<true, true, smdimx>(&sm_1_1[smindex]);
    float dv2d2_xy = mixed_XY<true, true, smdimx>(&sm_2_2[smindex]);
    float dv3d3_xy = mixed_XY<true, true, smdimx>(&sm_3_3[smindex]);
    float dv1d3_xy = der_12[index];
    float dv2d3_xy = der_15[index];

    field7[index] += M6[index] * dv1d1_xy + M11[index] * dv2d2_xy + M15[index] * dv3d3_xy +
                  M20[index] * dv1d3_xy + M18[index] * dv2d3_xy + M21[index] * dv1d2;

    float dv1d1_xz = der_7[index];
    float dv2d2_xz = der_13[index];
    float dv3d3_xz = der_17[index];
    float dv1d2_xz = der_10[index];
    float dv2d3_xz = mixed_XY<true, false, smdimx>(&sm_2_3[smindex]);

    field8[index] += M5[index] * dv1d1_xz + M10[index] * dv2d2_xz + M14[index] * dv3d3_xz +
                  M20[index] * dv1d2_xz + M17[index] * dv2d3_xz + M19[index] * dv1d3;

    float dv1d1_yz = der_8[index];
    float dv2d2_yz = der_14[index];
    float dv3d3_yz = der_18[index];
    float dv1d2_yz = der_9[index];
    float dv1d3_yz = mixed_XY<false, true, smdimx>(&sm_1_3[smindex]);

    field9[index] += M4[index] * dv1d1_yz + M9[index] * dv2d2_yz + M13[index] * dv3d3_yz +
                  M18[index] * dv1d2_yz + M17[index] * dv1d3_yz + M16[index] * dv2d3;
}

// ****************************************************************************

void plainLoop3(float *__restrict__ field4,
                     float *__restrict__ field5,
                     float *__restrict__ field6,
                     float *__restrict__ field7,
                     float *__restrict__ field8,
                     float *__restrict__ field9,
                     const float *__restrict__ M1,
                     const float *__restrict__ M2,
                     const float *__restrict__ M3,
                     const float *__restrict__ M4,
                     const float *__restrict__ M5,
                     const float *__restrict__ M6,
                     const float *__restrict__ M7,
                     const float *__restrict__ M8,
                     const float *__restrict__ M9,
                     const float *__restrict__ M10,
                     const float *__restrict__ M11,
                     const float *__restrict__ M12,
                     const float *__restrict__ M13,
                     const float *__restrict__ M14,
                     const float *__restrict__ M15,
                     const float *__restrict__ M16,
                     const float *__restrict__ M17,
                     const float *__restrict__ M18,
                     const float *__restrict__ M19,
                     const float *__restrict__ M20,
                     const float *__restrict__ M21,
                     const float *__restrict__ der_1,
                     const float *__restrict__ der_2,
                     const float *__restrict__ der_3,
                     const float *__restrict__ der_4,
                     const float *__restrict__ der_5,
                     const float *__restrict__ der_6,
                     float *__restrict__ der_7,
                     float *__restrict__ der_8,
                     float *__restrict__ der_9,
                     float *__restrict__ der_10,
                     float *__restrict__ der_11,
                     float *__restrict__ der_12,
                     float *__restrict__ der_13,
                     float *__restrict__ der_14,
                     float *__restrict__ der_15,
                     float *__restrict__ der_16,
                     float *__restrict__ der_17,
                     float *__restrict__ der_18,
                     int nx, int ny, int nz, int ldimx, int ldimy)
{
    // Compute all the mixed derivatives that involve the Z dimension
    // For small datasets, we could compute them in parallel (different streams)
    {
        const int tile_x = 32;
        const int tile_y = 16;
        const int tile_z = 64;
        dim3 threads(tile_x, tile_y, 1);
        dim3 blocks((nx - 1) / tile_x + 1, (ny - 1) / tile_y + 1, (nz - 1) / tile_z + 1);
        precompute_xz_yz<1, 1, 1, tile_x, tile_y, tile_z><<<blocks, threads>>>(der_1, der_7, der_8, ldimx, ldimy, nz);
        check_array("der_7.bin", "der_7", der_7, ldimx, ldimy, nz);
        check_array("der_8.bin", "der_8", der_8, ldimx, ldimy, nz);
                                                                                      // wrong
        precompute_xz_yz<1, 1, 1, tile_x, tile_y, tile_z><<<blocks, threads>>>(der_4, der_13, der_14, ldimx, ldimy, nz);
        check_array("der_13.bin", "der_13", der_13, ldimx, ldimy, nz);
        check_array("der_14.bin", "der_14", der_14, ldimx, ldimy, nz);
                                                                                      // wrong
        precompute_xz_yz<1, 1, 1, tile_x, tile_y, tile_z><<<blocks, threads>>>(der_6, der_17, der_18, ldimx, ldimy, nz);
        check_array("der_17.bin", "der_17", der_17, ldimx, ldimy, nz);
        check_array("der_18.bin", "der_18", der_18, ldimx, ldimy, nz);
                                                                                       // wrong
        precompute_xz_yz<0, 0, 1, tile_x, tile_y, tile_z><<<blocks, threads>>>(der_2, der_9, der_10, ldimx, ldimy, nz);
        check_array("der_9.bin", "der_9", der_9, ldimx, ldimy, nz);
        check_array("der_10.bin", "der_10", der_10, ldimx, ldimy, nz);
                                                                                      // wrong
        precompute_xz_yz<0, 1, 0, tile_x, tile_y, tile_z><<<blocks, threads>>>(der_3, der_11, der_12, ldimx, ldimy, nz);
        check_array("der_11.bin", "der_11", der_11, ldimx, ldimy, nz);
        check_array("der_12.bin", "der_12", der_12, ldimx, ldimy, nz);
                                                                                      // wrong
        precompute_xz_yz<1, 0, 0, tile_x, tile_y, tile_z><<<blocks, threads>>>(der_5, der_15, der_16, ldimx, ldimy, nz);
        check_array("der_15.bin", "der_15", der_15, ldimx, ldimy, nz);
        check_array("der_16.bin", "der_16", der_16, ldimx, ldimy, nz);
    }

    // Compute the final result, using a bunch of 2D thread blocks
    {
        const int tile_x = 32;
        const int tile_y = 32;
        dim3 threads(tile_x, tile_y, 1);
        dim3 blocks((nx - 1) / tile_x + 1, (ny - 1) / tile_y + 1, nz);
        int sharedmem = (tile_x + 16) * (tile_y + 16) * 6 * sizeof(float);
        CUCHK(cudaFuncSetAttribute(plain3Kernel<tile_x, tile_y>, cudaFuncAttributeMaxDynamicSharedMemorySize, sharedmem));
        plain3Kernel<tile_x, tile_y><<<blocks, threads, sharedmem, 0>>>(field4, field5, field6, field7, field8, field9,
                                                                             M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11,
                                                                             M12, M13, M14, M15, M16, M17, M18, M19, M20, M21,
                                                                             der_1, der_2, der_3, der_4, der_5, der_6,
                                                                             der_7, der_8, der_9, der_10, der_11, der_12,
                                                                             der_13, der_14, der_15, der_16, der_17, der_18,
                                                                             ldimx, ldimy);
    }
}

// ****************************************************************************

#define NUM_MODELS 22

// 144 VEL + 138 GRAD + 594 STRESS
#define NUM_ADDS 876

// 87 VEL + 81 GRAD + 198 STRESS
#define NUM_MULS 366

// 10 VEL + 9 GRAD + 33 STRESS
#define MIN_NUM_MEM_ACCESS 52

// 102 VEL + 99 GRAD + 387 STRESS
#define MAX_NUM_MEM_ACCESS 588

template <typename T>
inline T *alloc(int n, int leadpad)
{
    T *ptr;
    CUCHK(cudaMalloc((void **)&ptr, (n + leadpad) * sizeof(T)));
    return (ptr + leadpad);
}

int main(int argc, char **argv)
{
    int nx = 256;
    int ny = 256;
    int nz = 256;
    int nt = 200;
    if (argc > 1)
        nx = atoi(argv[1]);
    if (argc > 2)
        ny = atoi(argv[2]);
    if (argc > 3)
        nz = atoi(argv[3]);
    if (argc > 4)
        nt = atoi(argv[4]);

    int ldimx = nx + 16;
    int ldimy = ny + 16;
    int ldimz = nz + 16;
    ldimx = ((ldimx + 31) / 32) * 32; // Pad to next multiple of 32
    constexpr int leadpad = 32 - 8;

    float *field1 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field2 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field3 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field4 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field5 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field6 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field7 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field8 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *field9 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M1 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M2 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M3 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M4 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M5 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M6 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M7 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M8 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M9 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M10 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M11 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M12 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M13 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M14 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M15 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M16 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M17 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M18 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M19 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M20 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M21 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *M22 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der1 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der4 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der6 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der2 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der3 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der5 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der7 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der8 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der9 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der10 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der11 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der12 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der13 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der14 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der15 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der16 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der17 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *der18 = alloc<float>(ldimx * ldimy * ldimz, leadpad);
    float *zprime = alloc<float>(ldimz, 0);

    init_constant();
    dim3 blocks((ldimx + 127) / 128, ldimy, ldimz);
    init<<<blocks, 128>>>(field1, field2, field3, field4, field5,
                          field6, field7, field8, field9, M1,
                          M2, M3, M4, M5, M6,
                          M7, M8, M9, M10, M11,
                          M12, M13, M14, M15, M16,
                          M17, M18, M19, M20, M21,
                          M22, der1, der4, der6,
                          der2, der3, der5, zprime, ldimx, ldimy);
    CUCHK(cudaDeviceSynchronize());
    check_plainLoop1("init1.bin", field1, field2, field3, ldimx, ldimy, ldimz);
    check_plainLoop2("init2.bin", field4, field5, field6, field7, field8, field9, ldimx, ldimy, ldimz);

    double stTime = MPI_Wtime();
    for (int it = 0; it < nt; it++)
    {
        plainLoop1(field1, field2, field3, 
                     field4, field5, field6, field7, field8, field9,
                     M22, zprime, nx, ny, nz, ldimx, ldimy);
        check_plainLoop1("plainLoop1.bin", field1, field2, field3, ldimx, ldimy, ldimz);

        plainLoop2(field1, field2, field3,
                             der1, der2, der3,
                             der4, der5, der6,
                             zprime, nx, ny, nz, ldimx, ldimy);
        check_plainLoop2("plainLoop2.bin", der1, der2, der3, der4, der5, der6, ldimx, ldimy, ldimz);

        plainLoop3(
            field4, field5, field6, field7, field8, field9,
            M1, M2, M3, M4, M5, M6,
            M7, M8, M9, M10, M11, M12,
            M13, M14, M15, M16, M17, M18,
            M19, M20, M21,
            der1, der2, der3, der4, der5, der6,
            der7, der8, der9, der10, der11, der12,
            der13, der14, der15, der16, der17, der18,
            nx, ny, nz, ldimx, ldimy);
        check_plainLoop3("plainLoop3.bin", field4, field5, field6, field7, field8, field9, ldimx, ldimy, ldimz);
    }
    CUCHK(cudaDeviceSynchronize());
    double endTime = MPI_Wtime();

    std::cout << "Done!" << std::endl;

    double locTime = endTime - stTime;
    double maxTime = locTime;

    std::cout << "Time: " << maxTime << std::endl;
    std::cout << "Operations per grid point: " << (NUM_ADDS + NUM_MULS) << std::endl;
    std::cout << "Memory accesses per grid point (Min): " << (MIN_NUM_MEM_ACCESS) << std::endl;
    std::cout << "Memory accesses per grid point (Max): " << (MAX_NUM_MEM_ACCESS) << std::endl;
    std::cout << "Operational Intensity (Min): " << (((double)(NUM_ADDS + NUM_MULS)) / ((double)(MAX_NUM_MEM_ACCESS))) << std::endl;
    std::cout << "Operational Intensity (Max): " << (((double)(NUM_ADDS + NUM_MULS)) / ((double)(MIN_NUM_MEM_ACCESS))) << std::endl;
    long long int numAdds = ((long long int)nx) * ((long long int)ny) * ((long long int)nz) * ((long long int)(nt * NUM_ADDS));
    long long int numMuls = ((long long int)nx) * ((long long int)ny) * ((long long int)nz) * ((long long int)(nt * NUM_MULS));
    long long int totOps = numAdds + numMuls;
    double GFlops = ((double)(totOps) / maxTime) * 1.0e-9;
    std::cout << "Total number of single-precision additions per GPU: " << numAdds << std::endl;
    std::cout << "Total number of single-precision multiplications per GPU: " << numMuls << std::endl;
    std::cout << "Total number of single-precision operations per GPU: " << totOps << std::endl;
    std::cout << "Single precision GFlops per GPU: " << GFlops << std::endl;
    return 0;
}
