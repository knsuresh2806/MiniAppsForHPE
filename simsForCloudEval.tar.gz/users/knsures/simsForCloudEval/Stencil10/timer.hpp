
class Timer {
    cudaEvent_t _start, _stop;
    double time;
    double min_time, max_time;
    int niter;
    int total_niter;
    int skip;

    public:

    Timer(int skip=0);

    void start();

    void stop();

    void sync();

    float elapsed();

    void accumulate();

    void reset();

    void show_throughput(const char *msg, size_t size, const char *unit="Gpoints/s", double scaling=1e6);

    ~Timer();

};

Timer::Timer(int skip) {
        CUCHK(cudaEventCreate(&_start));
        CUCHK(cudaEventCreate(&_stop));
        time = 0;
        niter = 0;
        total_niter = 0;
        min_time = 1e20;
        max_time = 0.0;
        this->skip = skip;
}

void Timer::start() {
        CUCHK(cudaEventRecord(_start));
}

void Timer::stop() {
        CUCHK(cudaEventRecord(_stop));
}

void Timer::sync() {
        CUCHK(cudaEventSynchronize(_stop));
}

float Timer::elapsed() {
        float _time;
        sync();
        CUCHK(cudaEventElapsedTime(&_time, _start, _stop));
        return _time;
}

void Timer::accumulate() {
        niter++;
        if (niter <= skip) 
            return;
        total_niter++;
        double temp = elapsed();
        time += temp;
        min_time = min_time < temp ? min_time : temp;
        max_time = max_time < temp ? temp : max_time;
}

void Timer::reset() {
        niter = 0;
        time = 0.0;
        min_time = 1e20;
        max_time = 0.0;
}

void Timer::show_throughput(const char *msg, size_t size, const char *unit, double scaling) {
            double avg_time = time / total_niter;

            double avg_throughput = size / avg_time / scaling;
            double min_throughput = size / max_time / scaling;
            double max_throughput = size / min_time / scaling;

            printf("%s: [min=%g max=%g mean=%g] ms [min=%g max=%g mean=%g] %s iter=%d \n", msg, 
                    min_time,
                    max_time,
                    avg_time, 
                    min_throughput,
                    max_throughput,
                    avg_throughput,
                    unit, 
                    total_niter
                    );
}

Timer::~Timer() {
        CUCHK(cudaEventDestroy(_start));
        CUCHK(cudaEventDestroy(_stop));
}
