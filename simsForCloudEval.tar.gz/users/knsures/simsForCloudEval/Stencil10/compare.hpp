#pragma once
#include <math.h>


template <typename T>
__device__ __inline__ void lds_sum_kernel(T *out, const T value, const size_t idx, const size_t n) { 
    __shared__ T s_sum[512];

    s_sum[threadIdx.x] = value;
    __syncthreads();

    for (int offset = 512 >> 1; offset > 0; offset >>= 1) {
        if (threadIdx.x < offset)
            s_sum[threadIdx.x] += s_sum[threadIdx.x + offset];
        __syncthreads();

    }

    if (threadIdx.x == 0) {
        atomicAdd(out, s_sum[threadIdx.x]);
    }

}

template <typename T>
__device__ __inline__ T __max(const T x, const T y) {
    return x > y ? x : y;
}

template <typename T>
__device__ __inline__ void lds_max_kernel(T *out, const T value, const size_t idx, const size_t n) { 
    __shared__ T s_max[512];

    s_max[threadIdx.x] = value;
    __syncthreads();

    for (int offset = 512 >> 1; offset > 0; offset >>= 1) {
        if (threadIdx.x < offset)
            s_max[threadIdx.x] = __max(s_max[threadIdx.x], s_max[threadIdx.x + offset]);
        __syncthreads();

    }

    if (threadIdx.x == 0) {
        atomicMax(out, s_max[threadIdx.x]);
    }

}

template <typename T>
__global__ void l2_kernel(T *sum, const T *u, const T *v, size_t n) {
    size_t idx = threadIdx.x + blockIdx.x * blockDim.x;
    size_t size = blockDim.x * gridDim.x;
    T local_sum = 0.0;
    for (size_t i = idx; i < n; i += size) {
        T diff = u[i] - v[i];
        local_sum += diff * diff;
    }

    lds_sum_kernel(sum, local_sum, idx, n);

}

template <typename T>
__global__ void l1_kernel(T *sum, const T *u, const T *v, size_t n) {
    size_t idx = threadIdx.x + blockIdx.x * blockDim.x;
    size_t size = blockDim.x * gridDim.x;
    T local_sum = 0.0;
    for (size_t i = idx; i < n; i += size) {
        local_sum += fabs(u[i] - v[i]);
    }

    lds_sum_kernel(sum, local_sum, idx, n);

}

template <typename T>
__global__ void linf_kernel(T *sum, const T *u, const T *v, size_t n) {
    size_t idx = threadIdx.x + blockIdx.x * blockDim.x;
    size_t size = blockDim.x * gridDim.x;
    T local_sum = 0.0;
    for (size_t i = idx; i < n; i += size) {
        local_sum = __max(local_sum, (T)fabs(u[i] - v[i]));
    }

    lds_max_kernel(sum, local_sum, idx, n);

}

template <typename T>
T compare(const T *u, const T *v, size_t n, const char *type) {

    T *d_out; 
    CUCHK(hipMalloc(&d_out, sizeof(T)));
    CUCHK(hipMemset(d_out, 0, sizeof(T)));

    hipDeviceProp_t properties;
    CUCHK(hipGetDeviceProperties(&properties, 0));
    unsigned int cu_count = properties.multiProcessorCount;
    dim3 block(512);
    unsigned int nblock = (n - 1) / block.x + 1;
    dim3 grid(cu_count > nblock ? nblock : cu_count);

    if (strcmp(type, "l2") == 0) {
        l2_kernel<<<grid, block>>>(d_out, u, v, n);
    }
    else if (strcmp(type, "l1") == 0) {
        l1_kernel<<<grid, block>>>(d_out, u, v, n);
    }
    else if (strcmp(type, "linf") == 0) {
        linf_kernel<<<grid, block>>>(d_out, u, v, n);
    }
    else {
        fprintf(stderr, "Unrecognized comparison operator: %s \n", type);
    }

    T *h_out = new T[1];
    CUCHK(hipMemcpy(h_out, d_out, sizeof(T), hipMemcpyDeviceToHost));
    CUCHK(hipFree(d_out));

    T out = h_out[0];
    delete[] h_out;

    return sqrt(out);

}

template <typename T>
void compare_all(const T *u, const T *v, const char *msg, size_t n) {
    double l2 = compare(u, v, n, "l2");
    double l1 = compare(u, v, n, "l1");
    double linf = compare(u, v, n, "linf");
    printf("%s ||e||_2: %g ||e||_1: %g ||e||_inf: %g\n", msg, l2, l1, linf);
}

