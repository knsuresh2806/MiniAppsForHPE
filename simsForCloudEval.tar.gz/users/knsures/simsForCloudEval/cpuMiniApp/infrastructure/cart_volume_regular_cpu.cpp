
/*************************************************************************
 * Cartesian volume regular module 
 *
 * Author:
 *
 *************************************************************************/

#include "cart_volume_regular_cpu.h"
#include "axis.h"
#include <std_const.h>
#include <emsl_error.h>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <new>
#include <stdint.h>

//TODO Potentially remove once alignment is handled correctly in codebase
bool
is_unaligned(const axis* ax)
{
    return ax->alignMnt.alignValue == AlignMemBytes::NOEXTENSION;
}

// FIXME Pointers should only accepted if this constructor can deal gracefully with null pointers.
// Here the code will crash in the call to copyAxis if any of the axis pointers are null. This
// constructor should not accept pointers.

// 3 axis constructor
cart_volume_regular_cpu ::cart_volume_regular_cpu(const axis* _ax1_, const axis* _ax2_, const axis* _ax3_,
                                                  bool set_to_zero)
{
    copyAxis(_ax1_, _ax2_, _ax3_);

    _base_data = new (std::nothrow) realtype[size_t(_ax1->ntot) * size_t(_ax2->ntot) * size_t(_ax3->ntot)];
    EMSL_VERIFY(_base_data != NULL);
    allocate_data();

    if (set_to_zero) {
        zero(false, false);
    }

    send_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
    recv_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
}

// constructor with _data pre-allocated
cart_volume_regular_cpu ::cart_volume_regular_cpu(axis* _ax1_, axis* _ax2_, axis* _ax3_, realtype* base_data_)
{
    copyAxis(_ax1_, _ax2_, _ax3_);

    EMSL_VERIFY(base_data_ != NULL);
    _base_data = base_data_;
    allocate_data();

    send_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
    recv_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
}

// FIXME A pointer should only be passed if this constructor can deal gracefully with a null
// pointer (not crash). Otherwise, which is the case here, the constructor should only accept a reference.
// Here is crashes, which is better than limping along.

// copy constructor with option to leave off halo
cart_volume_regular_cpu ::cart_volume_regular_cpu(cart_volume_regular* vol, bool skipHalos, bool skipInterleaving,
                                                  bool set_to_zero)
{
    EMSL_VERIFY(vol != NULL);
    // EMSL_VERIFY(vol->is<cart_volume_regular_cpu>());

    Nx = vol->Nx;
    Ny = vol->Ny;
    Nz = vol->Nz;

    EMSL_VERIFY(vol->ax1() != NULL);
    EMSL_VERIFY(is_unaligned(vol->ax1()));
    EMSL_VERIFY(vol->ax2() != NULL);
    EMSL_VERIFY(vol->ax3() != NULL);
    if (skipHalos) {
        _ax1 = new axis(vol->ax1()->o, vol->ax1()->d, vol->ax1()->n);
        _ax2 = new axis(vol->ax2()->o, vol->ax2()->d, vol->ax2()->n);
        _ax3 = new axis(vol->ax3()->o, vol->ax3()->d, vol->ax3()->n);
    } else {
        _ax1 = new axis(vol->ax1());
        _ax2 = new axis(vol->ax2());
        _ax3 = new axis(vol->ax3());
    }
    EMSL_VERIFY(_ax1 != NULL);
    EMSL_VERIFY(_ax2 != NULL);
    EMSL_VERIFY(_ax3 != NULL);
    _base_data = new (std::nothrow) realtype[((size_t)(_ax1->ntot)) * (_ax2->ntot) * (_ax3->ntot)];
    EMSL_VERIFY(_base_data != NULL);
    allocate_data();

    if (set_to_zero) {
        zero(false, false);
    }

    send_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
    recv_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
} //end copyConstructor - 1

// FIXME See previous comments abound pointers.
//Copy constructor with axis rotation
cart_volume_regular_cpu ::cart_volume_regular_cpu(cart_volume_regular* vol, ROTATE_TYPE type)
{
    EMSL_VERIFY(vol != NULL);

    if (type == _ROTATE_FROM_XYZ_TO_ZXY) {
        Nx = vol->Nz;
        Ny = vol->Nx;
        Nz = vol->Ny;

        EMSL_VERIFY(vol->ax1() != NULL);
        EMSL_VERIFY(is_unaligned(vol->ax1()));
        EMSL_VERIFY(vol->ax2() != NULL);
        EMSL_VERIFY(vol->ax3() != NULL);
        _ax1 = new axis(vol->ax3());
        _ax2 = new axis(vol->ax1());
        _ax3 = new axis(vol->ax2());
        EMSL_VERIFY(_ax1 != NULL);
        EMSL_VERIFY(_ax2 != NULL);
        EMSL_VERIFY(_ax3 != NULL);
        _base_data = new (std::nothrow) realtype[((size_t)(_ax1->ntot)) * (_ax2->ntot) * (_ax3->ntot)];
        EMSL_VERIFY(_base_data != NULL);
        allocate_data();
    } else {
        //This type is not implemented
        EMSL_VERIFY(false);
    }

    send_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
    recv_buffers = std::make_unique<halo_buffers>(Nx, Ny, Nz, 1);
} //end copyConstructor - 2

void
cart_volume_regular_cpu ::copyAxis(const axis* _ax1_, const axis* _ax2_, const axis* _ax3_)
{
    EMSL_VERIFY(_ax1_ != NULL);
    EMSL_VERIFY(is_unaligned(_ax1_));
    EMSL_VERIFY(_ax2_ != NULL);
    EMSL_VERIFY(_ax3_ != NULL);

    _ax1 = new axis(_ax1_);
    EMSL_VERIFY(_ax1 != NULL);
    _ax2 = new axis(_ax2_);
    EMSL_VERIFY(_ax2 != NULL);
    _ax3 = new axis(_ax3_);
    EMSL_VERIFY(_ax3 != NULL);

    Nx = (_ax1->iend) - (_ax1->ibeg) + 1;
    Ny = (_ax2->iend) - (_ax2->ibeg) + 1;
    Nz = (_ax3->iend) - (_ax3->ibeg) + 1;
} //end copyAxis

void
cart_volume_regular_cpu ::allocate_data()
{
    _data = new (std::nothrow) Float2Ptr[_ax3->ntot];
    EMSL_VERIFY(_data != NULL);
    _data[0] = new (std::nothrow) FloatPtr[(_ax2->ntot) * (_ax3->ntot)];
    EMSL_VERIFY(_data[0] != NULL);
    for (size_t i = 1; i < (_ax3->ntot); ++i) {
        _data[i] = _data[0] + (i * (_ax2->ntot));
    } //end i
    for (size_t j = 0; j < (_ax3->ntot); ++j) {
        for (size_t i = 0; i < (_ax2->ntot); ++i) {
            _data[j][i] = _base_data + (((j * (_ax2->ntot)) + i) * (_ax1->ntot));
        } //end i
    }     //end j
} //end allocate_data

// destructor
cart_volume_regular_cpu ::~cart_volume_regular_cpu()
{
    if (_data) {
        delete[](_data[0]);
        delete[] _data;
    }
    if (_base_data)
        delete[] _base_data;
} //end destructor

void
cart_volume_regular_cpu ::injectHalos(RECV_TYPE_3D type, std::vector<int> const& sz, realtype* rBuf)
{
    int xSt = -1, xEnd = -1, ySt = -1, yEnd = -1, zSt = -1, zEnd = -1;
    switch (type) {
        case _RECV_TYPE_3D_NEGX: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGY: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg - sz[0];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSY1: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[0];
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg - sz[0];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[0];
            break;
        }
        case _RECV_TYPE_3D_NEGY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg - sz[0];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg - sz[0];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            break;
        }
        case _RECV_TYPE_3D_POSY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[0];
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_POSY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[0];
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY1: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY1: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY_NEGZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY_POSZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY_NEGZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY_POSZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY_NEGZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY_POSZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY_NEGZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY_POSZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            break;
        }
        default:
            break;
    } //end switch

    realtype*** outPtr = NULL;
    int xStride = 0;
    outPtr = _data;
    xStride = _ax1->ntot;

    for (int iz = zSt, cnt = 0; iz <= zEnd; ++iz) {
        for (int iy = ySt; iy <= yEnd; ++iy) {
#pragma concurrent
            for (int ix = xSt; ix <= xEnd; ++ix, ++cnt) {
                outPtr[iz][iy][ix] = rBuf[cnt];
            } //end ix
        }     //end iy
    }         //end iz
} //end injectHalos

void
cart_volume_regular_cpu ::copyHalos(RECV_TYPE_3D type, std::vector<int> const& sz, cart_volume<realtype>* fromVol)
{

    int xSt = -1, xEnd = -1, ySt = -1, yEnd = -1, zSt = -1, zEnd = -1;
    int xOff = -1, yOff = -1, zOff = -1;
    switch (type) {
        case _RECV_TYPE_3D_NEGX: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGY: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg - sz[0];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[0] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSY1: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[0];
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg - sz[0];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[0] - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[0];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg - sz[0];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[0] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[1] - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg - sz[0];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[0] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[0];
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[1] - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[0];
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[1] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY1: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[1] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY1: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[1] - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg - sz[1];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[1] - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[1];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY_NEGZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[1] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[2] - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY_POSZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[1] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY_NEGZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[2] - zSt;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY_POSZ: {
            xSt = _ax1->ibeg - sz[0];
            xEnd = _ax1->ibeg - 1;
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->iend + 1 - sz[0] - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY_NEGZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[1] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[2] - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY_POSZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->ibeg - sz[1];
            yEnd = _ax2->ibeg - 1;
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->iend + 1 - sz[1] - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY_NEGZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->ibeg - sz[2];
            zEnd = _ax3->ibeg - 1;
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->iend + 1 - sz[2] - zSt;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY_POSZ: {
            xSt = _ax1->iend + 1;
            xEnd = _ax1->iend + sz[0];
            ySt = _ax2->iend + 1;
            yEnd = _ax2->iend + sz[1];
            zSt = _ax3->iend + 1;
            zEnd = _ax3->iend + sz[2];
            xOff = fromVol->as<cart_volume_regular_cpu>()->ax1()->ibeg - xSt;
            yOff = fromVol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ySt;
            zOff = fromVol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zSt;
            break;
        }
        default:
            break;
    } //end switch

    realtype*** inPtr = NULL;
    realtype*** outPtr = NULL;
    int inXstride = 0;
    int outXstride = 0;
    outPtr = _data;
    inPtr = fromVol->as<cart_volume_regular_cpu>()->data();
    outXstride = _ax1->ntot;
    inXstride = fromVol->as<cart_volume_regular_cpu>()->ax1()->ntot;

    for (int iz = zSt; iz <= zEnd; ++iz) {
        for (int iy = ySt; iy <= yEnd; ++iy) {
#pragma concurrent
            for (int ix = xSt; ix <= xEnd; ++ix) {
                outPtr[iz][iy][ix] = inPtr[zOff + iz][yOff + iy][xOff + ix];
            } //end ix
        }     //end iy
    }         //end iz
} //end copyHalos

void
cart_volume_regular_cpu ::extractHalos(RECV_TYPE_3D type, std::vector<int> const& sz, realtype* sBuf,
                                       bool isFirstLocalXsubdom, bool isLastLocalXsubdom)
{
    int xSt = -1, xEnd = -1, ySt = -1, yEnd = -1, zSt = -1, zEnd = -1;
    switch (type) {
        case _RECV_TYPE_3D_NEGX: {
            EMSL_VERIFY(isLastLocalXsubdom);
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX: {
            EMSL_VERIFY(isFirstLocalXsubdom);
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGY: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1 - sz[0];
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSY1: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[0] - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1 - sz[0];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[0] - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1 - sz[0];
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1 - sz[1];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1 - sz[0];
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[1] - 1;
            break;
        }
        case _RECV_TYPE_3D_POSY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[0] - 1;
            zSt = _ax3->iend + 1 - sz[1];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[0] - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[1] - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1 - sz[1];
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY1: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[1] - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->iend + 1 - sz[1];
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY1: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[1] - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY2: {
            //Should not come here.
            EMSL_VERIFY(false);
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGZ: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1 - sz[1];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSZ: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[1] - 1;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1 - sz[1];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[1] - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY_NEGZ: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1 - sz[1];
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1 - sz[2];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_NEGY_POSZ: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->iend + 1 - sz[1];
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[2] - 1;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY_NEGZ: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[1] - 1;
            zSt = _ax3->iend + 1 - sz[2];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_NEGX_POSY_POSZ: {
            xSt = _ax1->iend + 1 - sz[0];
            xEnd = _ax1->iend;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[1] - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[2] - 1;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->iend + 1 - sz[1];
            yEnd = _ax2->iend;
            zSt = _ax3->iend + 1 - sz[2];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_NEGY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->iend + 1 - sz[1];
            yEnd = _ax2->iend;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[2] - 1;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY_NEGZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[1] - 1;
            zSt = _ax3->iend + 1 - sz[2];
            zEnd = _ax3->iend;
            break;
        }
        case _RECV_TYPE_3D_POSX_POSY_POSZ: {
            xSt = _ax1->ibeg;
            xEnd = _ax1->ibeg + sz[0] - 1;
            ySt = _ax2->ibeg;
            yEnd = _ax2->ibeg + sz[1] - 1;
            zSt = _ax3->ibeg;
            zEnd = _ax3->ibeg + sz[2] - 1;
            break;
        }
        default:
            break;

    } //end switch

    realtype*** inPtr = NULL;
    int xStride = 0;
    inPtr = _data;
    xStride = _ax1->ntot;

    for (int iz = zSt, cnt = 0; iz <= zEnd; ++iz) {
        for (int iy = ySt; iy <= yEnd; ++iy) {
#pragma concurrent
            for (int ix = xSt; ix <= xEnd; ++ix, ++cnt) {
                sBuf[cnt] = inPtr[iz][iy][ix];
            } //end ix
        }     //end iy
    }         //end iz
} //end extractHalos

void
cart_volume_regular_cpu ::get_min_max(realtype* min_, realtype* max_, bool skipHalosAndPadding, bool skipInterleaving)
{
    skipInterleaving = false;
    realtype min, max;
    if (skipHalosAndPadding) {
        const int xbeg = _ax1->ibeg;
        const int xend = _ax1->iend;
        const int ybeg = _ax2->ibeg;
        const int yend = _ax2->iend;
        const int zbeg = _ax3->ibeg;
        const int zend = _ax3->iend;

        min = _data[zbeg][ybeg][xbeg];
        max = _data[zbeg][ybeg][xbeg];
        for (int iz = zbeg; iz <= zend; ++iz) {
            for (int iy = ybeg; iy <= yend; ++iy) {
                for (int ix = xbeg; ix <= xend; ++ix) {
                    if (_data[iz][iy][ix] < min)
                        min = _data[iz][iy][ix];
                    if (_data[iz][iy][ix] > max)
                        max = _data[iz][iy][ix];
                } //ix
            }     //iy
        }         //iz
    } else {
        realtype* buf = &(_data[0][0][0]);
        size_t Ntot = ((size_t)(_ax1->ntot)) * (_ax2->ntot) * (_ax3->ntot);

        min = _data[0][0][0];
        max = _data[0][0][0];
        for (size_t i = 0; i < Ntot; ++i) {
            if (buf[i] < min)
                min = buf[i];
            if (buf[i] > max)
                max = buf[i];
        } //end i
    }     //end if skipHalosAndPadding

    *min_ = min;
    *max_ = max;
} //end get_min_max

int
cart_volume_regular_cpu ::has_nan_inf(bool skipHalosAndPadding, bool skipInterleaving)
{
    skipInterleaving = false;
    if (skipHalosAndPadding) {
        const int xbeg = _ax1->ibeg;
        const int xend = _ax1->iend;
        const int ybeg = _ax2->ibeg;
        const int yend = _ax2->iend;
        const int zbeg = _ax3->ibeg;
        const int zend = _ax3->iend;
        for (int iz = zbeg; iz <= zend; ++iz) {
            for (int iy = ybeg; iy <= yend; ++iy) {
                for (int ix = xbeg; ix <= xend; ++ix) {
                    if (std::isnan(_data[iz][iy][ix]) || std::isinf(_data[iz][iy][ix])) {
                        return 1;
                    }
                } //end ix
            }     //end iy
        }         //end iz
    } else {
        realtype* buf = &(_data[0][0][0]);
        size_t Ntot = ((size_t)(_ax1->ntot)) * (_ax2->ntot) * (_ax3->ntot);
        for (size_t i = 0; i < Ntot; ++i) {
            if (std::isnan(buf[i]) || std::isinf(buf[i])) {
                return 1;
            }
        } //end i
    }     //end if skipHalosAndPadding
    return 0;
} //end has_nan_inf

void
cart_volume_regular_cpu ::set_constant(realtype val, bool skipHalos, bool skipInterleaving)
{
    skipInterleaving = false;
    if (skipHalos) {
        const int xbeg = _ax1->ibeg;
        const int xend = _ax1->iend;
        const int ybeg = _ax2->ibeg;
        const int yend = _ax2->iend;
        const int zbeg = _ax3->ibeg;
        const int zend = _ax3->iend;
        for (int iz = zbeg; iz <= zend; ++iz) {
            for (int iy = ybeg; iy <= yend; ++iy) {
#pragma concurrent
                for (int ix = xbeg; ix <= xend; ++ix) {
                    _data[iz][iy][ix] = val;
                } //end ix
            }     //end iy
        }         //end iz
    } else {
        realtype* buf = &(_data[0][0][0]);
        size_t Ntot = ((size_t)(_ax1->ntot)) * (_ax2->ntot) * (_ax3->ntot);
#pragma concurrent
        for (size_t i = 0; i < Ntot; ++i) {
            buf[i] = val;
        } //end i
    }     //end if skipHalos
} //end set_constant

void
cart_volume_regular_cpu ::copyData(cart_volume<realtype>* vol_orig, bool skipHalos, bool skipInterleaving)
{
    EMSL_VERIFY(vol_orig->is<cart_volume_regular_cpu>());
    auto vol = vol_orig->as<cart_volume_regular_cpu>();
    skipInterleaving = false;
    if (skipHalos) {
        const int xbeg = _ax1->ibeg;
        const int ybeg = _ax2->ibeg;
        const int yend = _ax2->iend;
        const int zbeg = _ax3->ibeg;
        const int zend = _ax3->iend;
        const int xSt = vol->as<cart_volume_regular_cpu>()->ax1()->ibeg;
        const int yoff = vol->as<cart_volume_regular_cpu>()->ax2()->ibeg - ybeg;
        const int zoff = vol->as<cart_volume_regular_cpu>()->ax3()->ibeg - zbeg;
        for (int iz = zbeg; iz <= zend; ++iz) {
            for (int iy = ybeg; iy <= yend; ++iy) {
                realtype* buf = &(_data[iz][iy][xbeg]);
                realtype* volBuf = &(vol->data()[zoff + iz][yoff + iy][xSt]);
                std::memcpy(buf, volBuf, (Nx * sizeof(realtype)));
            } //end iy
        }     //end iz
    } else {
        realtype* buf = &(_data[0][0][0]);
        realtype* volBuf = &(vol->data()[0][0][0]);
        size_t Ntot = ((size_t)(_ax1->ntot)) * (_ax2->ntot) * (_ax3->ntot);
        std::memcpy(buf, volBuf, (Ntot * sizeof(realtype)));
    } //end if skipHalos
} //end copyData

void
cart_volume_regular_cpu ::print(FILE* fd)
{
    fprintf(fd, "************** begin volume ********************\n");
    _ax1->print(fd);
    _ax2->print(fd);
    _ax3->print(fd);
    fprintf(fd, "*************** end volume *********************\n");
} //end print
