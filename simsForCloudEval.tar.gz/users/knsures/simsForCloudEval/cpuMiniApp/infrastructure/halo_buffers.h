#ifndef _HALO_BUFFERS_H
#define _HALO_BUFFERS_H

#include "grid_const.h"
#include "std_const.h"

#include <map>
#include <utility>
#include <vector>
#include <Array.h>
#include <memory>

class halo_buffers
{
public:
    halo_buffers(int Nx, int Ny, int Nz, int numInterleaved);

    void getBuffer(RECV_TYPE_3D type, std::vector<int> const& sz, realtype*& buf, int& bufSz);

private:
    void getPair(std::pair<std::unique_ptr<realtype[]>, size_t>& p, realtype*& buf, int& bufSz);

    int Nx;
    int Ny;
    int Nz;
    int numInterleaved;

    std::map<int, std::pair<std::unique_ptr<realtype[]>, size_t>> bufMap1[_RECV_TYPE_3D_DIM1_TOTAL];
    std::map<Array<int, 2>, std::pair<std::unique_ptr<realtype[]>, size_t>> bufMap2[_RECV_TYPE_3D_DIM2_TOTAL];
    std::map<Array<int, 3>, std::pair<std::unique_ptr<realtype[]>, size_t>> bufMap3[_RECV_TYPE_3D_DIM3_TOTAL];
};

#endif
