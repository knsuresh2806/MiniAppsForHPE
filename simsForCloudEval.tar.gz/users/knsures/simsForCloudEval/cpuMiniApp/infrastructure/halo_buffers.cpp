#include "halo_buffers.h"

halo_buffers ::halo_buffers(int Nx, int Ny, int Nz, int numInterleaved)
    : Nx(Nx), Ny(Ny), Nz(Nz), numInterleaved(numInterleaved)
{}
void
halo_buffers ::getPair(std::pair<std::unique_ptr<realtype[]>, size_t>& p, realtype*& buf, int& bufSz)
{
    buf = p.first.get();
    bufSz = p.second;
}

void
halo_buffers ::getBuffer(RECV_TYPE_3D type, std::vector<int> const& sz, realtype*& buf, int& bufSz)
{
    buf = NULL;
    bufSz = 0;
    const int typeDim = RECV_TYPE_3D_DIM[type];
    const int mapIdx = RECV_TYPE_3D_DIM_MAP[type];
    if (typeDim == 1) {
        std::map<int, std::pair<std::unique_ptr<realtype[]>, size_t>>::iterator pos = bufMap1[mapIdx].find(sz[0]);
        if (pos == bufMap1[mapIdx].end()) {
            int oN;
            if ((type == _RECV_TYPE_3D_NEGX) || (type == _RECV_TYPE_3D_POSX)) {
                oN = Ny * Nz;
            } else if ((type == _RECV_TYPE_3D_NEGY) || (type == _RECV_TYPE_3D_POSY1)) {
                oN = Nx * Nz;
            } else if (type == _RECV_TYPE_3D_POSY2) {
                return;
            } else {
                oN = Nx * Ny;
            }
            bufSz = sz[0] * oN * numInterleaved;
            buf = new realtype[bufSz];
            std::pair<realtype*, size_t> val(buf, bufSz);
            std::pair<int, std::pair<realtype*, size_t>> entry(sz[0], val);
            bufMap1[mapIdx].insert(entry);
        } else {
            getPair(pos->second, buf, bufSz);
        }
    } else if (typeDim == 2) {
        Array<int, 2> key;
        key[0] = sz[0];
        key[1] = sz[1];
        std::map<Array<int, 2>, std::pair<std::unique_ptr<realtype[]>, size_t>>::iterator pos =
            bufMap2[mapIdx].find(key);
        if (pos == bufMap2[mapIdx].end()) {
            int oN;
            if ((type == _RECV_TYPE_3D_NEGY_NEGZ) || (type == _RECV_TYPE_3D_NEGY_POSZ) ||
                (type == _RECV_TYPE_3D_POSY_NEGZ) || (type == _RECV_TYPE_3D_POSY_POSZ)) {
                oN = Nx;
            } else if ((type == _RECV_TYPE_3D_NEGX_NEGY) || (type == _RECV_TYPE_3D_NEGX_POSY1) ||
                       (type == _RECV_TYPE_3D_POSX_NEGY) || (type == _RECV_TYPE_3D_POSX_POSY1)) {
                oN = Nz;
            } else if ((type == _RECV_TYPE_3D_NEGX_POSY2) || (type == _RECV_TYPE_3D_POSX_POSY2)) {
                return;
            } else {
                oN = Ny;
            }
            bufSz = sz[0] * sz[1] * oN * numInterleaved;
            buf = new realtype[bufSz];
            std::pair<realtype*, size_t> val(buf, bufSz);
            std::pair<Array<int, 2>, std::pair<realtype*, size_t>> entry(key, val);
            bufMap2[mapIdx].insert(entry);
        } else {
            getPair(pos->second, buf, bufSz);
        }
    } else {
        Array<int, 3> key;
        key[0] = sz[0];
        key[1] = sz[1];
        key[2] = sz[2];
        std::map<Array<int, 3>, std::pair<std::unique_ptr<realtype[]>, size_t>>::iterator pos =
            bufMap3[mapIdx].find(key);
        if (pos == bufMap3[mapIdx].end()) {
            bufSz = sz[0] * sz[1] * sz[2] * numInterleaved;
            buf = new realtype[bufSz];
            std::pair<realtype*, size_t> val(buf, bufSz);
            std::pair<Array<int, 3>, std::pair<realtype*, size_t>> entry(key, val);
            bufMap3[mapIdx].insert(entry);
        } else {
            getPair(pos->second, buf, bufSz);
        }
    }
}
