
/**
  @author Rahul S. Sampath
  */

#include <mpi.h>
#include "haloManager3D_cpu.h"
#include "decompositionManager3D.h"
#include <cart_volume.h>
#include <timer.h>

haloManager3D_cpu ::haloManager3D_cpu(decompositionManager3D* decomp, std::vector<cart_volume<realtype>**>& data,
                                      std::vector<std::vector<int>> wSz[3][2],
                                      std::vector<std::vector<bool>>& includeEdges,
                                      std::vector<std::vector<bool>>& includeCorners)
{

    int nfields = data.size();

    MPI_Comm_dup(decomp->get_comm(), &comm);

    int rank = decomp->get_rank();

    int npes = decomp->get_npes();

    int nsubdom = decomp->getTotalNumLocalSubDom();

    int nhRank[_NH_ID_3D_TOTAL];
    decomp->getNeighbors(nhRank);

    int sendCnts[2][_NH_ID_3D_TOTAL];
    int recvCnts[2][_NH_ID_3D_TOTAL];
    int sendOffsets[2][_NH_ID_3D_TOTAL];
    int recvOffsets[2][_NH_ID_3D_TOTAL];

    std::vector<int> map[_NH_ID_3D_TOTAL];

    MPI_Request sendReq[3][_NH_ID_3D_TOTAL];
    MPI_Request recvReq[3][_NH_ID_3D_TOTAL];

    for (int j = 0; j < 2; ++j) {
        for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
            sendCnts[j][i] = 0;
            recvCnts[j][i] = 0;
            sendOffsets[j][i] = 0;
            recvOffsets[j][i] = 0;
        } //end i
    }     //end j

    for (int j = 0; j < 3; ++j) {
        for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
            sendReq[j][i] = MPI_REQUEST_NULL;
            recvReq[j][i] = MPI_REQUEST_NULL;
        } //end i
    }     //end j

    int currLocalRecvTag = 0;

    for (int j = 0; j < nsubdom; ++j) {
        int nhSubDomId[_NH_ID_3D_TOTAL];
        decomp->getLocalNeighborID(j, nhSubDomId);

        for (int i = 0; i < nfields; ++i) {
            //NEGX
            if (wSz[0][0][i][j] > 0) {
                std::vector<int> tmpSz;
                tmpSz.push_back(wSz[0][0][i][j]);
                if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                    ctType.push_back(_RECV_TYPE_3D_NEGX);
                    copyToData.push_back(data[i][j]);
                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ]]);
                    ctSz.push_back(tmpSz);
                } else if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                    realtype* buf = NULL;
                    int bufSz = 0;
                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX, tmpSz, buf, bufSz);
                    ++(sendCnts[0][_NH_ID_3D_NEGX_CENY_CENZ]);
                    map[_NH_ID_3D_NEGX_CENY_CENZ].push_back(rRank.size());
                    map[_NH_ID_3D_NEGX_CENY_CENZ].push_back(i);
                    map[_NH_ID_3D_NEGX_CENY_CENZ].push_back(j);
                    rType.push_back(_RECV_TYPE_3D_NEGX);
                    rRank.push_back(nhRank[_NH_ID_3D_NEGX_CENY_CENZ]);
                    injectData.push_back(data[i][j]);
                    iSz.push_back(tmpSz);
                    rBuf.push_back(buf);
                    rSz.push_back(bufSz);
                    rReq.push_back(MPI_REQUEST_NULL);
                    rTag.push_back(currLocalRecvTag);
                    ++currLocalRecvTag;
                }
            }

            //POSX
            if (wSz[0][1][i][j] > 0) {
                std::vector<int> tmpSz;
                tmpSz.push_back(wSz[0][1][i][j]);
                if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                    ctType.push_back(_RECV_TYPE_3D_POSX);
                    copyToData.push_back(data[i][j]);
                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ]]);
                    ctSz.push_back(tmpSz);
                } else if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                    realtype* buf = NULL;
                    int bufSz = 0;
                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX, tmpSz, buf, bufSz);
                    ++(sendCnts[0][_NH_ID_3D_POSX_CENY_CENZ]);
                    map[_NH_ID_3D_POSX_CENY_CENZ].push_back(rRank.size());
                    map[_NH_ID_3D_POSX_CENY_CENZ].push_back(i);
                    map[_NH_ID_3D_POSX_CENY_CENZ].push_back(j);
                    rType.push_back(_RECV_TYPE_3D_POSX);
                    rRank.push_back(nhRank[_NH_ID_3D_POSX_CENY_CENZ]);
                    injectData.push_back(data[i][j]);
                    iSz.push_back(tmpSz);
                    rBuf.push_back(buf);
                    rSz.push_back(bufSz);
                    rReq.push_back(MPI_REQUEST_NULL);
                    rTag.push_back(currLocalRecvTag);
                    ++currLocalRecvTag;
                }
            }

            //NEGY
            if (wSz[1][0][i][j] > 0) {
                std::vector<int> tmpSz;
                tmpSz.push_back(wSz[1][0][i][j]);
                if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                    ctType.push_back(_RECV_TYPE_3D_NEGY);
                    copyToData.push_back(data[i][j]);
                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ]]);
                    ctSz.push_back(tmpSz);
                } else if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                    realtype* buf = NULL;
                    int bufSz = 0;
                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGY, tmpSz, buf, bufSz);
                    ++(sendCnts[0][_NH_ID_3D_CENX_NEGY_CENZ]);
                    map[_NH_ID_3D_CENX_NEGY_CENZ].push_back(rRank.size());
                    map[_NH_ID_3D_CENX_NEGY_CENZ].push_back(i);
                    map[_NH_ID_3D_CENX_NEGY_CENZ].push_back(j);
                    rType.push_back(_RECV_TYPE_3D_NEGY);
                    rRank.push_back(nhRank[_NH_ID_3D_CENX_NEGY_CENZ]);
                    injectData.push_back(data[i][j]);
                    iSz.push_back(tmpSz);
                    rBuf.push_back(buf);
                    rSz.push_back(bufSz);
                    rReq.push_back(MPI_REQUEST_NULL);
                    rTag.push_back(currLocalRecvTag);
                    ++currLocalRecvTag;
                }
            }

            //POSY1 & POSY2
            if (wSz[1][1][i][j] > 0) {
                std::vector<int> tmpSz;
                tmpSz.push_back(wSz[1][1][i][j]);
                if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                    ctType.push_back(_RECV_TYPE_3D_POSY1);
                    copyToData.push_back(data[i][j]);
                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ]]);
                    ctSz.push_back(tmpSz);
                } else if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                    realtype* buf = NULL;
                    int bufSz = 0;
                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSY1, tmpSz, buf, bufSz);
                    ++(sendCnts[0][_NH_ID_3D_CENX_POSY_CENZ]);
                    map[_NH_ID_3D_CENX_POSY_CENZ].push_back(rRank.size());
                    map[_NH_ID_3D_CENX_POSY_CENZ].push_back(i);
                    map[_NH_ID_3D_CENX_POSY_CENZ].push_back(j);
                    rType.push_back(_RECV_TYPE_3D_POSY1);
                    rRank.push_back(nhRank[_NH_ID_3D_CENX_POSY_CENZ]);
                    injectData.push_back(data[i][j]);
                    iSz.push_back(tmpSz);
                    rBuf.push_back(buf);
                    rSz.push_back(bufSz);
                    rReq.push_back(MPI_REQUEST_NULL);
                    rTag.push_back(currLocalRecvTag);
                    ++currLocalRecvTag;

                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSY2, tmpSz, buf, bufSz);
                    if (buf) {
                        ++(sendCnts[0][_NH_ID_3D_CENX_POSY_CENZ]);
                        map[_NH_ID_3D_CENX_POSY_CENZ].push_back(rRank.size());
                        map[_NH_ID_3D_CENX_POSY_CENZ].push_back(i);
                        map[_NH_ID_3D_CENX_POSY_CENZ].push_back(j);
                        rType.push_back(_RECV_TYPE_3D_POSY2);
                        rRank.push_back(nhRank[_NH_ID_3D_CENX_POSY_CENZ]);
                        injectData.push_back(data[i][j]);
                        iSz.push_back(tmpSz);
                        rBuf.push_back(buf);
                        rSz.push_back(bufSz);
                        rReq.push_back(MPI_REQUEST_NULL);
                        rTag.push_back(currLocalRecvTag);
                        ++currLocalRecvTag;
                    }
                }
            }

            //NEGZ
            if (wSz[2][0][i][j] > 0) {
                std::vector<int> tmpSz;
                tmpSz.push_back(wSz[2][0][i][j]);
                if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                    ctType.push_back(_RECV_TYPE_3D_NEGZ);
                    copyToData.push_back(data[i][j]);
                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ]]);
                    ctSz.push_back(tmpSz);
                } else if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                    realtype* buf = NULL;
                    int bufSz = 0;
                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGZ, tmpSz, buf, bufSz);
                    ++(sendCnts[0][_NH_ID_3D_CENX_CENY_NEGZ]);
                    map[_NH_ID_3D_CENX_CENY_NEGZ].push_back(rRank.size());
                    map[_NH_ID_3D_CENX_CENY_NEGZ].push_back(i);
                    map[_NH_ID_3D_CENX_CENY_NEGZ].push_back(j);
                    rType.push_back(_RECV_TYPE_3D_NEGZ);
                    rRank.push_back(nhRank[_NH_ID_3D_CENX_CENY_NEGZ]);
                    injectData.push_back(data[i][j]);
                    iSz.push_back(tmpSz);
                    rBuf.push_back(buf);
                    rSz.push_back(bufSz);
                    rReq.push_back(MPI_REQUEST_NULL);
                    rTag.push_back(currLocalRecvTag);
                    ++currLocalRecvTag;
                }
            }

            //POSZ
            if (wSz[2][1][i][j] > 0) {
                std::vector<int> tmpSz;
                tmpSz.push_back(wSz[2][1][i][j]);
                if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                    ctType.push_back(_RECV_TYPE_3D_POSZ);
                    copyToData.push_back(data[i][j]);
                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ]]);
                    ctSz.push_back(tmpSz);
                } else if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                    realtype* buf = NULL;
                    int bufSz = 0;
                    data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSZ, tmpSz, buf, bufSz);
                    ++(sendCnts[0][_NH_ID_3D_CENX_CENY_POSZ]);
                    map[_NH_ID_3D_CENX_CENY_POSZ].push_back(rRank.size());
                    map[_NH_ID_3D_CENX_CENY_POSZ].push_back(i);
                    map[_NH_ID_3D_CENX_CENY_POSZ].push_back(j);
                    rType.push_back(_RECV_TYPE_3D_POSZ);
                    rRank.push_back(nhRank[_NH_ID_3D_CENX_CENY_POSZ]);
                    injectData.push_back(data[i][j]);
                    iSz.push_back(tmpSz);
                    rBuf.push_back(buf);
                    rSz.push_back(bufSz);
                    rReq.push_back(MPI_REQUEST_NULL);
                    rTag.push_back(currLocalRecvTag);
                    ++currLocalRecvTag;
                }
            }

            if (includeEdges[i][j]) {
                if (wSz[0][0][i][j] > 0) {
                    //NEGX_NEGY
                    if (wSz[1][0][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][0][i][j]);
                        tmpSz.push_back(wSz[1][0][i][j]);
                        if (nhSubDomId[_NH_ID_3D_NEGX_NEGY_CENZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_NEGX_NEGY);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_NEGY_CENZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_NEGX_NEGY_CENZ] >= 0) {
                                nhId = _NH_ID_3D_NEGX_NEGY_CENZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_NEGY, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_NEGX_NEGY);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }

                    //NEGX_POSY1 & NEGX_POSY2
                    if (wSz[1][1][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][0][i][j]);
                        tmpSz.push_back(wSz[1][1][i][j]);
                        if (nhSubDomId[_NH_ID_3D_NEGX_POSY_CENZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_NEGX_POSY1);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_POSY_CENZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_NEGX_POSY_CENZ] >= 0) {
                                nhId = _NH_ID_3D_NEGX_POSY_CENZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_POSY1, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_NEGX_POSY1);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;

                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_POSY2, tmpSz, buf, bufSz);
                                if (buf) {
                                    ++(sendCnts[0][nhId]);
                                    map[nhId].push_back(rRank.size());
                                    map[nhId].push_back(i);
                                    map[nhId].push_back(j);
                                    rType.push_back(_RECV_TYPE_3D_NEGX_POSY2);
                                    rRank.push_back(nhRank[nhId]);
                                    injectData.push_back(data[i][j]);
                                    iSz.push_back(tmpSz);
                                    rBuf.push_back(buf);
                                    rSz.push_back(bufSz);
                                    rReq.push_back(MPI_REQUEST_NULL);
                                    rTag.push_back(currLocalRecvTag);
                                    ++currLocalRecvTag;
                                }
                            }
                        }
                    }
                }

                if (wSz[0][1][i][j] > 0) {
                    //POSX_NEGY
                    if (wSz[1][0][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][1][i][j]);
                        tmpSz.push_back(wSz[1][0][i][j]);
                        if (nhSubDomId[_NH_ID_3D_POSX_NEGY_CENZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_POSX_NEGY);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_NEGY_CENZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_POSX_NEGY_CENZ] >= 0) {
                                nhId = _NH_ID_3D_POSX_NEGY_CENZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_NEGY, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_POSX_NEGY);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }

                    //POSX_POSY1 & POSX_POSY2
                    if (wSz[1][1][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][1][i][j]);
                        tmpSz.push_back(wSz[1][1][i][j]);
                        if (nhSubDomId[_NH_ID_3D_POSX_POSY_CENZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_POSX_POSY1);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_POSY_CENZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_POSX_POSY_CENZ] >= 0) {
                                nhId = _NH_ID_3D_POSX_POSY_CENZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_POSY1, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_POSX_POSY1);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;

                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_POSY2, tmpSz, buf, bufSz);
                                if (buf) {
                                    ++(sendCnts[0][nhId]);
                                    map[nhId].push_back(rRank.size());
                                    map[nhId].push_back(i);
                                    map[nhId].push_back(j);
                                    rType.push_back(_RECV_TYPE_3D_POSX_POSY2);
                                    rRank.push_back(nhRank[nhId]);
                                    injectData.push_back(data[i][j]);
                                    iSz.push_back(tmpSz);
                                    rBuf.push_back(buf);
                                    rSz.push_back(bufSz);
                                    rReq.push_back(MPI_REQUEST_NULL);
                                    rTag.push_back(currLocalRecvTag);
                                    ++currLocalRecvTag;
                                }
                            }
                        }
                    }
                }

                if (wSz[1][0][i][j] > 0) {
                    //NEGY_NEGZ
                    if (wSz[2][0][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[1][0][i][j]);
                        tmpSz.push_back(wSz[2][0][i][j]);
                        if (nhSubDomId[_NH_ID_3D_CENX_NEGY_NEGZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_NEGY_NEGZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_NEGY_NEGZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_CENX_NEGY_NEGZ] >= 0) {
                                nhId = _NH_ID_3D_CENX_NEGY_NEGZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGY_NEGZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_NEGY_NEGZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }

                    //NEGY_POSZ
                    if (wSz[2][1][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[1][0][i][j]);
                        tmpSz.push_back(wSz[2][1][i][j]);
                        if (nhSubDomId[_NH_ID_3D_CENX_NEGY_POSZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_NEGY_POSZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_NEGY_POSZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_CENX_NEGY_POSZ] >= 0) {
                                nhId = _NH_ID_3D_CENX_NEGY_POSZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGY_POSZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_NEGY_POSZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }
                }

                if (wSz[1][1][i][j] > 0) {
                    //POSY_NEGZ
                    if (wSz[2][0][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[1][1][i][j]);
                        tmpSz.push_back(wSz[2][0][i][j]);
                        if (nhSubDomId[_NH_ID_3D_CENX_POSY_NEGZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_POSY_NEGZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_POSY_NEGZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_CENX_POSY_NEGZ] >= 0) {
                                nhId = _NH_ID_3D_CENX_POSY_NEGZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSY_NEGZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_POSY_NEGZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }

                    //POSY_POSZ
                    if (wSz[2][1][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[1][1][i][j]);
                        tmpSz.push_back(wSz[2][1][i][j]);
                        if (nhSubDomId[_NH_ID_3D_CENX_POSY_POSZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_POSY_POSZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_CENX_POSY_POSZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_CENX_POSY_POSZ] >= 0) {
                                nhId = _NH_ID_3D_CENX_POSY_POSZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSY_POSZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_POSY_POSZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }
                }

                if (wSz[0][0][i][j] > 0) {
                    //NEGX_NEGZ
                    if (wSz[2][0][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][0][i][j]);
                        tmpSz.push_back(wSz[2][0][i][j]);
                        if (nhSubDomId[_NH_ID_3D_NEGX_CENY_NEGZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_NEGX_NEGZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_CENY_NEGZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_NEGX_CENY_NEGZ] >= 0) {
                                nhId = _NH_ID_3D_NEGX_CENY_NEGZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_NEGZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_NEGX_NEGZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }

                    //NEGX_POSZ
                    if (wSz[2][1][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][0][i][j]);
                        tmpSz.push_back(wSz[2][1][i][j]);
                        if (nhSubDomId[_NH_ID_3D_NEGX_CENY_POSZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_NEGX_POSZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_CENY_POSZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_NEGX_CENY_POSZ] >= 0) {
                                nhId = _NH_ID_3D_NEGX_CENY_POSZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_POSZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_NEGX_POSZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }
                }

                if (wSz[0][1][i][j] > 0) {
                    //POSX_NEGZ
                    if (wSz[2][0][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][1][i][j]);
                        tmpSz.push_back(wSz[2][0][i][j]);
                        if (nhSubDomId[_NH_ID_3D_POSX_CENY_NEGZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_POSX_NEGZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_CENY_NEGZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_POSX_CENY_NEGZ] >= 0) {
                                nhId = _NH_ID_3D_POSX_CENY_NEGZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_NEGZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_POSX_NEGZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }

                    //POSX_POSZ
                    if (wSz[2][1][i][j] > 0) {
                        std::vector<int> tmpSz;
                        tmpSz.push_back(wSz[0][1][i][j]);
                        tmpSz.push_back(wSz[2][1][i][j]);
                        if (nhSubDomId[_NH_ID_3D_POSX_CENY_POSZ] >= 0) {
                            ctType.push_back(_RECV_TYPE_3D_POSX_POSZ);
                            copyToData.push_back(data[i][j]);
                            copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_CENY_POSZ]]);
                            ctSz.push_back(tmpSz);
                        } else {
                            int nhId = -1;
                            if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                    nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                }
                            } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                    nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                }
                            } else if (nhRank[_NH_ID_3D_POSX_CENY_POSZ] >= 0) {
                                nhId = _NH_ID_3D_POSX_CENY_POSZ;
                            }
                            if (nhId >= 0) {
                                realtype* buf = NULL;
                                int bufSz = 0;
                                data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_POSZ, tmpSz, buf, bufSz);
                                ++(sendCnts[0][nhId]);
                                map[nhId].push_back(rRank.size());
                                map[nhId].push_back(i);
                                map[nhId].push_back(j);
                                rType.push_back(_RECV_TYPE_3D_POSX_POSZ);
                                rRank.push_back(nhRank[nhId]);
                                injectData.push_back(data[i][j]);
                                iSz.push_back(tmpSz);
                                rBuf.push_back(buf);
                                rSz.push_back(bufSz);
                                rReq.push_back(MPI_REQUEST_NULL);
                                rTag.push_back(currLocalRecvTag);
                                ++currLocalRecvTag;
                            }
                        }
                    }
                }

                if (includeCorners[i][j]) {
                    if (wSz[0][0][i][j] > 0) {
                        if (wSz[1][0][i][j] > 0) {
                            //NEGX_NEGY_NEGZ
                            if (wSz[2][0][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][0][i][j]);
                                tmpSz.push_back(wSz[1][0][i][j]);
                                tmpSz.push_back(wSz[2][0][i][j]);
                                if (nhSubDomId[_NH_ID_3D_NEGX_NEGY_NEGZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_NEGX_NEGY_NEGZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_NEGY_NEGZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_NEGY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_NEGY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_NEGX_CENY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_CENY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_NEGX_NEGY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_NEGY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_NEGX_NEGY_NEGZ] >= 0) {
                                        nhId = _NH_ID_3D_NEGX_NEGY_NEGZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_NEGY_NEGZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_NEGX_NEGY_NEGZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }

                            //NEGX_NEGY_POSZ
                            if (wSz[2][1][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][0][i][j]);
                                tmpSz.push_back(wSz[1][0][i][j]);
                                tmpSz.push_back(wSz[2][1][i][j]);
                                if (nhSubDomId[_NH_ID_3D_NEGX_NEGY_POSZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_NEGX_NEGY_POSZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_NEGY_POSZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_NEGY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_NEGY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_NEGX_CENY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_CENY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_NEGX_NEGY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_NEGY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_NEGX_NEGY_POSZ] >= 0) {
                                        nhId = _NH_ID_3D_NEGX_NEGY_POSZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_NEGY_POSZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_NEGX_NEGY_POSZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }
                        }

                        if (wSz[1][1][i][j] > 0) {
                            //NEGX_POSY_NEGZ
                            if (wSz[2][0][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][0][i][j]);
                                tmpSz.push_back(wSz[1][1][i][j]);
                                tmpSz.push_back(wSz[2][0][i][j]);
                                if (nhSubDomId[_NH_ID_3D_NEGX_POSY_NEGZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_NEGX_POSY_NEGZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_POSY_NEGZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_POSY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_POSY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_NEGX_CENY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_CENY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_NEGX_POSY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_POSY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_NEGX_POSY_NEGZ] >= 0) {
                                        nhId = _NH_ID_3D_NEGX_POSY_NEGZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_POSY_NEGZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_NEGX_POSY_NEGZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }

                            //NEGX_POSY_POSZ
                            if (wSz[2][1][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][0][i][j]);
                                tmpSz.push_back(wSz[1][1][i][j]);
                                tmpSz.push_back(wSz[2][1][i][j]);
                                if (nhSubDomId[_NH_ID_3D_NEGX_POSY_POSZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_NEGX_POSY_POSZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_NEGX_POSY_POSZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_POSY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_POSY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_NEGX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_NEGX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_NEGX_CENY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_CENY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_NEGX_POSY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_NEGX_POSY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_NEGX_POSY_POSZ] >= 0) {
                                        nhId = _NH_ID_3D_NEGX_POSY_POSZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_NEGX_POSY_POSZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_NEGX_POSY_POSZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }
                        }
                    }

                    if (wSz[0][1][i][j] > 0) {
                        if (wSz[1][0][i][j] > 0) {
                            //POSX_NEGY_NEGZ
                            if (wSz[2][0][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][1][i][j]);
                                tmpSz.push_back(wSz[1][0][i][j]);
                                tmpSz.push_back(wSz[2][0][i][j]);
                                if (nhSubDomId[_NH_ID_3D_POSX_NEGY_NEGZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_POSX_NEGY_NEGZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_NEGY_NEGZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_NEGY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_NEGY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_POSX_CENY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_CENY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_POSX_NEGY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_NEGY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_POSX_NEGY_NEGZ] >= 0) {
                                        nhId = _NH_ID_3D_POSX_NEGY_NEGZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_NEGY_NEGZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_POSX_NEGY_NEGZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }

                            //POSX_NEGY_POSZ
                            if (wSz[2][1][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][1][i][j]);
                                tmpSz.push_back(wSz[1][0][i][j]);
                                tmpSz.push_back(wSz[2][1][i][j]);
                                if (nhSubDomId[_NH_ID_3D_POSX_NEGY_POSZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_POSX_NEGY_POSZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_NEGY_POSZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_NEGY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_NEGY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_NEGY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_NEGY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_POSX_CENY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_CENY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_POSX_NEGY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_NEGY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_POSX_NEGY_POSZ] >= 0) {
                                        nhId = _NH_ID_3D_POSX_NEGY_POSZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_NEGY_POSZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_POSX_NEGY_POSZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }
                        }

                        if (wSz[1][1][i][j] > 0) {
                            //POSX_POSY_NEGZ
                            if (wSz[2][0][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][1][i][j]);
                                tmpSz.push_back(wSz[1][1][i][j]);
                                tmpSz.push_back(wSz[2][0][i][j]);
                                if (nhSubDomId[_NH_ID_3D_POSX_POSY_NEGZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_POSX_POSY_NEGZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_POSY_NEGZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_NEGZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_POSY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_POSY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_POSX_CENY_NEGZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_CENY_NEGZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_NEGZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_POSX_POSY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_POSY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_POSX_POSY_NEGZ] >= 0) {
                                        nhId = _NH_ID_3D_POSX_POSY_NEGZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_POSY_NEGZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_POSX_POSY_NEGZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }

                            //POSX_POSY_POSZ
                            if (wSz[2][1][i][j] > 0) {
                                std::vector<int> tmpSz;
                                tmpSz.push_back(wSz[0][1][i][j]);
                                tmpSz.push_back(wSz[1][1][i][j]);
                                tmpSz.push_back(wSz[2][1][i][j]);
                                if (nhSubDomId[_NH_ID_3D_POSX_POSY_POSZ] >= 0) {
                                    ctType.push_back(_RECV_TYPE_3D_POSX_POSY_POSZ);
                                    copyToData.push_back(data[i][j]);
                                    copyFromData.push_back(data[i][nhSubDomId[_NH_ID_3D_POSX_POSY_POSZ]]);
                                    ctSz.push_back(tmpSz);
                                } else {
                                    int nhId = -1;
                                    if (nhSubDomId[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_CENY_POSZ;
                                            }
                                        } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_CENX_POSY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_CENX_POSY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_CENX_POSY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_POSY_CENZ] >= 0) {
                                        if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                            if (nhRank[_NH_ID_3D_POSX_CENY_CENZ] >= 0) {
                                                nhId = _NH_ID_3D_POSX_CENY_CENZ;
                                            }
                                        } else if (nhRank[_NH_ID_3D_POSX_CENY_POSZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_CENY_POSZ;
                                        }
                                    } else if (nhSubDomId[_NH_ID_3D_CENX_CENY_POSZ] >= 0) {
                                        if (nhRank[_NH_ID_3D_POSX_POSY_CENZ] >= 0) {
                                            nhId = _NH_ID_3D_POSX_POSY_CENZ;
                                        }
                                    } else if (nhRank[_NH_ID_3D_POSX_POSY_POSZ] >= 0) {
                                        nhId = _NH_ID_3D_POSX_POSY_POSZ;
                                    }
                                    if (nhId >= 0) {
                                        realtype* buf = NULL;
                                        int bufSz = 0;
                                        data[i][j]->getRecvBuffer(_RECV_TYPE_3D_POSX_POSY_POSZ, tmpSz, buf, bufSz);
                                        ++(sendCnts[0][nhId]);
                                        map[nhId].push_back(rRank.size());
                                        map[nhId].push_back(i);
                                        map[nhId].push_back(j);
                                        rType.push_back(_RECV_TYPE_3D_POSX_POSY_POSZ);
                                        rRank.push_back(nhRank[nhId]);
                                        injectData.push_back(data[i][j]);
                                        iSz.push_back(tmpSz);
                                        rBuf.push_back(buf);
                                        rSz.push_back(bufSz);
                                        rReq.push_back(MPI_REQUEST_NULL);
                                        rTag.push_back(currLocalRecvTag);
                                        ++currLocalRecvTag;
                                    }
                                }
                            }
                        }
                    }
                } //end if includeCorners
            }     //end if includeEdges
        }         //end i
    }             //end j

    int trueTagOffset;
    MPI_Exscan(&currLocalRecvTag, &trueTagOffset, 1, MPI_INT, MPI_SUM, comm);
    if (rank == 0) {
        trueTagOffset = 0;
    }

    for (int i = 0; i < rTag.size(); ++i) {
        rTag[i] += trueTagOffset;
    } //end i

    if (rTag.size() > 0) {
        // Check that we haven't exceed the MPI implementation's upper tag limit.
        int flag;
        MPI_Aint* tagUpperBoundPtr;
        MPI_Comm_get_attr(MPI_COMM_WORLD, MPI_TAG_UB, &tagUpperBoundPtr, &flag);
        int tagUpperBound = *tagUpperBoundPtr;
        EMSL_VERIFY(rTag.back() <= tagUpperBound);
    }

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        if (nhRank[i] >= 0) {
            MPI_Irecv(&(recvCnts[0][i]), 1, MPI_INT, nhRank[i], INV_NH_ID_3D[i], comm, &(recvReq[0][i]));
        }
    } //end i

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        if (nhRank[i] >= 0) {
            MPI_Isend(&(sendCnts[0][i]), 1, MPI_INT, nhRank[i], i, comm, &(sendReq[0][i]));
        }
    } //end i

    for (int i = 1; i < _NH_ID_3D_TOTAL; ++i) {
        sendOffsets[0][i] = sendOffsets[0][i - 1] + sendCnts[0][i - 1];
    } //end i

    //rTag, rType, field and splitSubDomID (X, Y, Z)
    std::vector<int> sendData1(6 * (rTag.size()), -1);

    //iSz
    std::vector<int> sendData2;

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        for (int j = 0; j < sendCnts[0][i]; ++j) {
            int idx1 = map[i][3 * j];
            int idx2 = sendOffsets[0][i] + j;
            sendData1[6 * idx2] = rTag[idx1];
            sendData1[6 * idx2 + 1] = rType[idx1];
            sendData1[6 * idx2 + 2] = map[i][3 * j + 1];
            int splitLocalSubDomId[3];
            decomp->getSplitLocalSubDomID(map[i][3 * j + 2], splitLocalSubDomId);
            sendData1[6 * idx2 + 3] = splitLocalSubDomId[0];
            sendData1[6 * idx2 + 4] = splitLocalSubDomId[1];
            sendData1[6 * idx2 + 5] = splitLocalSubDomId[2];
            sendCnts[1][i] += iSz[idx1].size();
            sendData2.insert(sendData2.end(), iSz[idx1].begin(), iSz[idx1].end());
        } //end j
    }     //end i

    for (int i = 1; i < _NH_ID_3D_TOTAL; ++i) {
        sendOffsets[1][i] = sendOffsets[1][i - 1] + sendCnts[1][i - 1];
    } //end i

    MPI_Waitall(_NH_ID_3D_TOTAL, recvReq[0], MPI_STATUSES_IGNORE);

    for (int i = 1; i < _NH_ID_3D_TOTAL; ++i) {
        recvOffsets[0][i] = recvOffsets[0][i - 1] + recvCnts[0][i - 1];
    } //end i

    sTag.resize((recvOffsets[0][_NH_ID_3D_TOTAL - 1] + recvCnts[0][_NH_ID_3D_TOTAL - 1]), -1);

    //rTag, rType, field and splitSubDomID (X, Y, Z)
    std::vector<int> recvData1(6 * (sTag.size()), -1);

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        if (recvCnts[0][i] > 0) {
            MPI_Irecv(&(recvData1[6 * recvOffsets[0][i]]), 6 * recvCnts[0][i], MPI_INT, nhRank[i],
                      (_NH_ID_3D_TOTAL + INV_NH_ID_3D[i]), comm, &(recvReq[1][i]));
        }
    } //end i

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        if (sendCnts[0][i] > 0) {
            MPI_Isend(&(sendData1[6 * sendOffsets[0][i]]), 6 * sendCnts[0][i], MPI_INT, nhRank[i],
                      (_NH_ID_3D_TOTAL + i), comm, &(sendReq[1][i]));
        }
    } //end i

    sReq.resize(sTag.size(), MPI_REQUEST_NULL);
    sRank.resize(sTag.size(), -1);
    sType.resize(sTag.size());
    eSz.resize(sTag.size());
    extractData.resize(sTag.size(), NULL);
    isFirstLocalXsubdom.resize(sTag.size());
    isLastLocalXsubdom.resize(sTag.size());

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        for (int j = 0; j < recvCnts[0][i]; ++j) {
            sRank[recvOffsets[0][i] + j] = nhRank[i];
        } //end j
    }     //end i

    int nLocSubDom[3];
    decomp->getSplitNumLocalSubDom(nLocSubDom);

    MPI_Waitall(_NH_ID_3D_TOTAL, recvReq[1], MPI_STATUSES_IGNORE);

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        for (int j = 0; j < recvCnts[0][i]; ++j) {
            int idx = recvOffsets[0][i] + j;
            sTag[idx] = recvData1[6 * idx];
            sType[idx] = RECV_TYPE_3D_MAP[recvData1[6 * idx + 1]];
            eSz[idx].resize(RECV_TYPE_3D_DIM[recvData1[6 * idx + 1]]);
            int subDomIDtoSend = decomp->getSubDomIDtoSend(NH_ID_3D_MAP[i], sType[idx], recvData1[6 * idx + 3],
                                                           recvData1[6 * idx + 4], recvData1[6 * idx + 5]);
            extractData[idx] = data[recvData1[6 * idx + 2]][subDomIDtoSend];
            int splitLocalSubDomId[3];
            decomp->getSplitLocalSubDomID(subDomIDtoSend, splitLocalSubDomId);
            isFirstLocalXsubdom[idx] = (splitLocalSubDomId[0] == 0);
            isLastLocalXsubdom[idx] = (splitLocalSubDomId[0] == (nLocSubDom[0] - 1));
            recvCnts[1][i] += eSz[idx].size();
        } //end j
    }     //end i

    for (int i = 1; i < _NH_ID_3D_TOTAL; ++i) {
        recvOffsets[1][i] = recvOffsets[1][i - 1] + recvCnts[1][i - 1];
    } //end i

    std::vector<int> recvData2((recvOffsets[1][_NH_ID_3D_TOTAL - 1] + recvCnts[1][_NH_ID_3D_TOTAL - 1]), -1);

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        if (recvCnts[1][i] > 0) {
            MPI_Irecv(&(recvData2[recvOffsets[1][i]]), recvCnts[1][i], MPI_INT, nhRank[i],
                      (2 * _NH_ID_3D_TOTAL + INV_NH_ID_3D[i]), comm, &(recvReq[2][i]));
        }
    } //end i

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        if (sendCnts[1][i] > 0) {
            MPI_Isend(&(sendData2[sendOffsets[1][i]]), sendCnts[1][i], MPI_INT, nhRank[i], (2 * _NH_ID_3D_TOTAL + i),
                      comm, &(sendReq[2][i]));
        }
    } //end i

    sBuf.resize(sTag.size(), NULL);
    sSz.resize(sTag.size(), 0);

    MPI_Waitall(_NH_ID_3D_TOTAL, recvReq[2], MPI_STATUSES_IGNORE);

    for (int i = 0; i < _NH_ID_3D_TOTAL; ++i) {
        for (int j = 0, k = 0; j < recvCnts[0][i]; ++j) {
            int idx = recvOffsets[0][i] + j;
            for (int l = 0; l < eSz[idx].size(); ++l, ++k) {
                eSz[idx][l] = recvData2[recvOffsets[1][i] + k];
            } //end l
        }     //end j
    }         //end i

    for (int i = 0; i < sTag.size(); ++i) {
        extractData[i]->getSendBuffer(sType[i], eSz[i], sBuf[i], sSz[i]);
    } //end i

    for (int i = 0; i < sTag.size(); ++i) {
        if ((sType[i] == _RECV_TYPE_3D_NEGX) || (sType[i] == _RECV_TYPE_3D_POSX)) {
            negX_posX_sendList.push_back(i);
        } else {
            other_sendList.push_back(i);
        }
    } //end i

    MPI_Waitall(_NH_ID_3D_TOTAL, sendReq[0], MPI_STATUSES_IGNORE);
    MPI_Waitall(_NH_ID_3D_TOTAL, sendReq[1], MPI_STATUSES_IGNORE);
    MPI_Waitall(_NH_ID_3D_TOTAL, sendReq[2], MPI_STATUSES_IGNORE);
} //end constructor

void
haloManager3D_cpu ::start_update()
{
    for (int i = 0; i < rTag.size(); ++i) {
        MPI_Irecv(rBuf[i], rSz[i], MPI_REALTYPE, rRank[i], rTag[i], comm, &(rReq[i]));
    } //end i

    for (int j = 0; j < negX_posX_sendList.size(); ++j) {
        int i = negX_posX_sendList[j];
        TIMED_BLOCK("HaloExtract")
        {
            extractData[i]->extractHalos(sType[i], eSz[i], sBuf[i], isFirstLocalXsubdom[i], isLastLocalXsubdom[i]);
        }
        MPI_Isend(sBuf[i], sSz[i], MPI_REALTYPE, sRank[i], sTag[i], comm, &(sReq[i]));
    } //end j

    for (int j = 0; j < other_sendList.size(); ++j) {
        int i = other_sendList[j];
        TIMED_BLOCK("HaloExtract")
        {
            extractData[i]->extractHalos(sType[i], eSz[i], sBuf[i], isFirstLocalXsubdom[i], isLastLocalXsubdom[i]);
        }
        MPI_Isend(sBuf[i], sSz[i], MPI_REALTYPE, sRank[i], sTag[i], comm, &(sReq[i]));
    } //end j

    TIMED_BLOCK("HaloCopy")
    {
        for (int i = 0; i < ctType.size(); ++i) {
            copyToData[i]->copyHalos(ctType[i], ctSz[i], copyFromData[i]);
        } //end i
    }
}

void
haloManager3D_cpu ::finish_update()
{
    for (int i = 0; i < rReq.size(); ++i) {
        int idx;
        TIMED_BLOCK("HaloWait") { MPI_Waitany(rReq.size(), &(rReq[0]), &idx, MPI_STATUS_IGNORE); }
        TIMED_BLOCK("HaloInject") { injectData[idx]->injectHalos(rType[idx], iSz[idx], rBuf[idx]); }
    } //end i

    TIMED_BLOCK("HaloWait") { MPI_Waitall(sReq.size(), &(sReq[0]), MPI_STATUSES_IGNORE); }
}

void
haloManager3D_cpu ::print(FILE* fd)
{
    int rank;
    MPI_Comm_rank(comm, &rank);

    int npes;
    MPI_Comm_size(comm, &npes);

    if (rank == 0) {
        fprintf(fd, "---- begin 3D halo manager info ----\n");
    }

    char token = 1;
    if (rank > 0) {
        MPI_Recv(&token, 1, MPI_CHAR, (rank - 1), 1, comm, MPI_STATUS_IGNORE);
    }

    fprintf(fd, "halo(%d): rReqsz=%d, sReqsz=%d \n", rank, (int)(rReq.size()), (int)(sReq.size()));
    fflush(fd);

    if (rank < (npes - 1)) {
        MPI_Send(&token, 1, MPI_CHAR, (rank + 1), 1, comm);
    }

    if (rank == (npes - 1)) {
        fprintf(fd, "---- end 3D halo manager info ----\n");
    }
}
