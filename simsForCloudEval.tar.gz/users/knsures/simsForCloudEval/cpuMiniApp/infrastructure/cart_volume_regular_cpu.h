
/*************************************************************************
 * Cartesian volume regular module 
 *
 * Author: 
 * Change Log:
 *
 *************************************************************************/

#ifndef _CART_VOLUME_REGULAR_CPU
#define _CART_VOLUME_REGULAR_CPU

#include "cart_volume_regular.h"
#include <map>
#include <utility>
#include <vector>
#include <Array.h>

class cart_volume_regular_cpu : public cart_volume_regular
{
public:
    /*! Constructor 
     * \param ax1_ 1st dimension axis
     * \param ax2_ 2nd dimension axis
     * \param ax3_ 3rd dimension axis
     * \param set_to_zero - true to set all values to zero (false by default)
     */
    cart_volume_regular_cpu(const axis* ax1_, const axis* ax2_, const axis* ax3_, bool set_to_zero = false);
    cart_volume_regular_cpu(axis* ax1_, axis* ax2_, axis* ax3_, realtype* base_data_);

    /*! Copy constructor with option to leave off halo 
     * \param vol volume to be copied
     * \param skipHalos - true to skip halos (false by default)
     * \param skipInterleaving - true to only allocate for one volume (false by default)
     * \param set_to_zero - true to set all values to zero (false by default)
     */
    cart_volume_regular_cpu(cart_volume_regular* vol, bool skipHalos = false, bool skipInterleaving = false,
                            bool set_to_zero = false);

    //Copy constructor with axis rotation
    cart_volume_regular_cpu(cart_volume_regular* vol, ROTATE_TYPE type);

    // Destructor
    ~cart_volume_regular_cpu();

    void injectHalos(RECV_TYPE_3D type, std::vector<int> const& sz, realtype* rBuf);
    void copyHalos(RECV_TYPE_3D type, std::vector<int> const& sz, cart_volume<realtype>* fromVol);
    void extractHalos(RECV_TYPE_3D type, std::vector<int> const& sz, realtype* sBuf, bool isFirstLocalXsubdom,
                      bool isLastLocalXsubdom);
    void get_min_max(realtype* min_, realtype* max_, bool skipHalosAndPadding = true,
                     bool skipInterleaving = false);
    int has_nan_inf(bool skipHalosAndPadding = true, bool skipInterleaving = false);
    // void scale(realtype val, bool skipHalos = true, bool skipInterleaving = false) final;
    // void scale(cart_volume<realtype>* in, realtype val, bool skipHalos = true, bool skipInterleaving = false) final;

    //! set all values to a constant
    void set_constant(realtype val, bool skipHalos = true, bool skipInterleaving = false) final;

    //! copy data from argument volume (used for checkpointing)
    void copyData(cart_volume<realtype>* vol, bool skipHalos = true, bool skipInterleaving = false) final;

    // //! serialize cart_volume<realtype> to a realtype stream specified by input argument chkptBuf; return #floats copied
    // size_t serialize(realtype* chkptBuf, bool skipHalos = true, bool skipInterleaving = false) final;

    // //! deserialize cart_volume<realtype> to a realtype stream specified by input argument chkptBuf; return #floats copied
    // size_t deserialize(realtype* chkptBuf, bool skipHalos = true, bool skipInterleaving = false) final;

    // void extractSubplane_xz(cart_plane* pln, int yoff, int xoff, int zoff, int xstep, int zstep) final;

    // void extractSubplane_yz(cart_plane* pln, int xoff, int yoff, int zoff, int ystep, int zstep) final;

    // void extractSubplane_xy(cart_plane* pln, int zoff, int xoff, int yoff, int xstep, int ystep) final;

    // //! stack data from argument volume - returns number of values stacked
    // size_t stack(cart_volume<realtype>* vol);

    // //! reassemble volumes
    // void reassemble(cart_volume<realtype>* vol);

    //! diagnostic print
    void print(FILE* fd);

    // As function to access the variables
    realtype*** data() const { return this->_data; }
    void setData(realtype*** data)
    {
        this->_data = data;
        this->_base_data = data[0][0];
    }
    realtype* base_data() { return this->_base_data; }

private:
    cart_volume_regular_cpu() {}

    void allocate_data();

    realtype* _base_data;
    realtype*** _data;

    void copyAxis(const axis* ax1_, const axis* ax2_, const axis* ax3_);
};
#endif //_CART_VOLUME_REGULAR_CPU
