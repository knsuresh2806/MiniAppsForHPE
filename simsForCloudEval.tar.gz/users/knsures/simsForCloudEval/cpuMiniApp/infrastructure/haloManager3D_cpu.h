/*
CPU Halo exchange manager for 3-D domains. 
Author:
*/

#ifndef _HALO_MANAGER_3D_CPU
#define _HALO_MANAGER_3D_CPU

#include "haloManager3D.h"

class haloManager3D_cpu : public haloManager3D
{
public:
    /**
      Constructor
decomp: domain decomposition object.
data: list of fields that participate in the halo-exchange.
wSz: Widths of the stencil for each sub-volume of each field in each direction. This is 
typically equal to the number of halo values received, except when there is no adjacent 
sub-volume in that direction. The first dimension is one of X = 0, Y = 1 or Z = 2. The second 
dimension is one of Negative = 0 or Positive = 1.
includeEdges: True to include edges and false otherwise.
includeCorners: True to include corners and false otherwise. Ignored if includeEdges is false.
*/
    haloManager3D_cpu(decompositionManager3D* decomp, std::vector<cart_volume<realtype>**>& data,
                      std::vector<std::vector<int>> wSz[3][2], std::vector<std::vector<bool>>& includeEdges,
                      std::vector<std::vector<bool>>& includeCorners);

    // We do not want copy operations because of the duplicated comm
    haloManager3D_cpu(const haloManager3D_cpu& other) = delete;
    haloManager3D_cpu& operator=(const haloManager3D_cpu& other) = delete;

    //Destructor
    ~haloManager3D_cpu() { MPI_Comm_free(&comm); }

    void start_update() override;

    void finish_update() override;

    void print(FILE* fd) override;

private:
    //Indices of NEGX and POSX sends
    std::vector<int> negX_posX_sendList;

    //Indices of other sends
    std::vector<int> other_sendList;

    //Send requests
    std::vector<MPI_Request> sReq;

    //Recv requests
    std::vector<MPI_Request> rReq;

    std::vector<bool> isFirstLocalXsubdom;

    std::vector<bool> isLastLocalXsubdom;

    //data from which to extract before sending
    std::vector<cart_volume<realtype>*> extractData;

    //Extract Widths
    std::vector<std::vector<int>> eSz;

    //data to inject to after recieving
    std::vector<cart_volume<realtype>*> injectData;

    //Inject Widths
    std::vector<std::vector<int>> iSz;

    //Send buffer
    std::vector<realtype*> sBuf;

    //Send size
    std::vector<int> sSz;

    //Recv buffer
    std::vector<realtype*> rBuf;

    //Recv size
    std::vector<int> rSz;

    //Send rank
    std::vector<int> sRank;

    //Recv rank
    std::vector<int> rRank;

    //Send tag
    std::vector<int> sTag;

    //Recv tag
    std::vector<int> rTag;

    //Send Type
    std::vector<RECV_TYPE_3D> sType;

    //Recv Type
    std::vector<RECV_TYPE_3D> rType;

    //data from which to copy from
    std::vector<cart_volume<realtype>*> copyFromData;

    //data from which to copy to
    std::vector<cart_volume<realtype>*> copyToData;

    //Copy To Type
    std::vector<RECV_TYPE_3D> ctType;

    //Copy To Widths
    std::vector<std::vector<int>> ctSz;
};

#endif
