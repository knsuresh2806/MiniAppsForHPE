#include <math.h>
#include "simulator4SetUp.h"
#include "cart_volume_regular_cpu.h"
#include "file_snap_factory.h"
#include "timer.h"

#define DF_order16_1 1.01f
#define DF_order16_2 2.01f
#define DF_order16_3 3.01f
#define DF_order16_4 4.01f
#define DF_order16_5 5.01f
#define DF_order16_6 6.01f
#define DF_order16_7 7.01f
#define DF_order16_8 8.01f

#define INT_S_O16_1 1.01f
#define INT_S_O16_2 2.01f
#define INT_S_O16_3 3.01f
#define INT_S_O16_4 4.01f
#define INT_S_O16_5 5.01f
#define INT_S_O16_6 6.01f
#define INT_S_O16_7 7.01f
#define INT_S_O16_8 8.01f

void
init_fields_and_models_kernel(float*** f1, float*** f2, float*** f3, float*** f4, float*** f5, float*** f6, float*** f7,
                 float*** f8, float*** f9, float*** f10, float*** f11, float*** f12, float*** f13, float*** f14,
                 float*** f15, float*** f16, float*** f17, float*** f18, float*** f19, float*** f20, float*** f21,
                 float*** M1, float*** M2, float*** M3, float*** M4, float*** M5, float*** M6, float*** M7,
                 float*** M8, float*** M9, float*** M10, float*** M11, float*** M12, float*** M13, float*** M14,
                 float*** M15, float*** M16, float*** M17, float*** M18, float*** M19, float*** M20, float*** M21, 
                 float*** M22, float*** d4, float*** d5, float*** d6, float*** d7, float*** d8, float*** d9,
                 float* zprime, int ixbeg, int ixend, int iybeg, int iyend, int izbeg, int izend)
{
    for (int iz = izbeg; iz <= izend; ++iz) {
      for (int iy = iybeg; iy <= iyend; ++iy) {
        for (int ix = ixbeg; ix <= ixend; ++ix) {
          f1[iz][iy][ix] = cosf(12.0f * iz + iy + ix);
          f2[iz][iy][ix] = sinf(12.0f * iz + iy + ix);
          f3[iz][iy][ix] = cosf(iz + 12.0f * iy + ix);
          f4[iz][iy][ix] = sinf(iz + 12.0f * iy + ix);
          f5[iz][iy][ix] = cosf(iz + iy + 12.0f * ix);
          f6[iz][iy][ix] = sinf(iz + iy + 12.0f * ix);
          f7[iz][iy][ix] = cosf(13.0f * iz + iy + ix);
          f8[iz][iy][ix] = sinf(13.0f * iz + iy + ix);
          f9[iz][iy][ix] = cosf(iz + 13.0f * iy + ix);
          f10[iz][iy][ix] = sinf(iz + 13.0f * iy + ix);
          f11[iz][iy][ix] = cosf(iz + iy + 13.0f * ix);
          f12[iz][iy][ix] = sinf(iz + iy + 13.0f * ix);
          f13[iz][iy][ix] = cosf(14.0f * iz + iy + ix);
          f14[iz][iy][ix] = sinf(14.0f * iz + iy + ix);
          f15[iz][iy][ix] = cosf(iz + 14.0f * iy + ix);
          f16[iz][iy][ix] = sinf(iz + 14.0f * iy + ix);
          f17[iz][iy][ix] = cosf(iz + iy + 14.0f * ix);
          f18[iz][iy][ix] = sinf(iz + iy + 14.0f * ix);
          f19[iz][iy][ix] = cosf(15.0f * iz + iy + ix);
          f20[iz][iy][ix] = sinf(15.0f * iz + iy + ix);
          f21[iz][iy][ix] = cosf(iz + 15.0f * iy + ix);
          M1[iz][iy][ix] = cosf(2.0f * iz + iy + ix);
          M2[iz][iy][ix] = sinf(2.0f * iz + iy + ix);
          M3[iz][iy][ix] = cosf(iz + 2.0f * iy + ix);
          M4[iz][iy][ix] = sinf(iz + 2.0f * iy + ix);
          M5[iz][iy][ix] = cosf(iz + iy + 2.0f * ix);
          M6[iz][iy][ix] = sinf(iz + iy + 2.0f * ix);
          M7[iz][iy][ix] = cosf(3.0f * iz + iy + ix);
          M8[iz][iy][ix] = sinf(3.0f * iz + iy + ix);
          M9[iz][iy][ix] = cosf(iz + 3.0f * iy + ix);
          M10[iz][iy][ix] = sinf(iz + 3.0f * iy + ix);
          M11[iz][iy][ix] = cosf(iz + iy + 3.0f * ix);
          M12[iz][iy][ix] = sinf(iz + iy + 3.0f * ix);
          M13[iz][iy][ix] = cosf(4.0f * iz + iy + ix);
          M14[iz][iy][ix] = sinf(4.0f * iz + iy + ix);
          M15[iz][iy][ix] = cosf(iz + 4.0f * iy + ix);
          M16[iz][iy][ix] = sinf(iz + 4.0f * iy + ix);
          M17[iz][iy][ix] = cosf(iz + iy + 4.0f * ix);
          M18[iz][iy][ix] = sinf(iz + iy + 4.0f * ix);
          M19[iz][iy][ix] = cosf(5.0f * iz + iy + ix);
          M20[iz][iy][ix] = sinf(5.0f * iz + iy + ix);
          M21[iz][iy][ix] = cosf(iz + 5.0f * iy + ix);
          M22[iz][iy][ix] = sinf(iz + 5.0f * iy + ix);
          d4[iz][iy][ix] = cosf(iz + iy + 5.0f * ix);
          d5[iz][iy][ix] = sinf(iz + iy + 5.0f * ix);
          d6[iz][iy][ix] = cosf(6.0f * iz + iy + ix);
          d7[iz][iy][ix] = sinf(6.0f * iz + iy + ix);
          d8[iz][iy][ix] = cosf(iz + 6.0f * iy + ix);
          d9[iz][iy][ix] = sinf(iz + 6.0f * iy + ix);
        }
      }
    zprime[iz] = cosf(6.0f * iz);
  }
}

void
compute_p_kernel(float*** p, float*** f4, float*** f5, float*** f6, float*** f7, float*** f8, 
                        float*** f9, int ixbeg, int ixend, int iybeg, int iyend, int izbeg, int izend)
{
    for (int iz = izbeg; iz <= izend; ++iz) {
      for (int iy = iybeg; iy <= iyend; ++iy) {
        for (int ix = ixbeg; ix <= ixend; ++ix) {
          p[iz][iy][iz] = -(2.0f * f4[iz][iy][iz] + 3.0f * f5[iz][iy][iz] + 4.0f * f6[iz][iy][iz]
                                    + 5.0f * f7[iz][iy][iz] + 6.0f * f8[iz][iy][iz] + 7.0f * f9[iz][iy][iz]) / 27.0f;
        }
      }
    }
}

void
init_src_kernel(float*** f4, float*** f5, float*** f6, float*** f7, float*** f8, float*** f9, 
                int x, int y, int z, float press)
{
    f4[z][y][x] = press * 1.0f;
    f5[z][y][x] = press * 2.0f;
    f6[z][y][x] = press * 3.0f;
    f7[z][y][x] = press * 4.0f;
    f8[z][y][x] = press * 5.0f;
    f9[z][y][x] = press * 6.0f;
}

simulator4SetUp::simulator4SetUp(int npoints, int npml, int niter, int xcorr_step, int nzones[3], int ranks[3], int radius_lo, int radius_hi, int fwd_only, MPI_Comm communicator):
    _npoints {npoints},
    _npml {npml},
    _niter {niter},
    scratch_folder {"test_snapshot_area"},
    _xcorr_step {xcorr_step},
    _fwd_only {fwd_only}
{
    EMSL_VERIFY(nzones[0] >= 1 && nzones[1] >= 1 && nzones[2] >= 1);
    EMSL_VERIFY(ranks[0] >= 1 && ranks[1] >= 1 && ranks[2] >= 1);

    _comm = communicator;
    MPI_Comm_rank(_comm, &_rank);
    r_lo = radius_lo;
    r_hi = radius_hi;
    radius = std::max(radius_lo, radius_hi);

    // Define the number of points in each zone
    for (int i = 0; i < 3; i++) {
        int sum = 0;
        numPts[i] = new int[nzones[i]];
        for (int j = 0; j < nzones[i]; j++) {
            numPts[i][j] = get_n_for_zone(j, nzones[i]);
            sum += numPts[i][j];
        }
        n_total[i] = sum;
    }

    numZonesinX = nzones[0];
    numZonesinY = nzones[1];
    numZonesinZ = nzones[2];

    // Costs are all the same = 1
    costs = new float**[numZonesinZ];
    for (int i = 0; i < numZonesinZ; ++i) {
        costs[i] = new float*[numZonesinY];
        for (int j = 0; j < numZonesinY; ++j) {
            costs[i][j] = new float[numZonesinX];
            for (int k = 0; k < numZonesinX; ++k)
                costs[i][j][k] = 1.0f;
        }
    }

    // Same stencil width for all 3D but allow staggered
    for (int axis = 0; axis < 3; ++axis) {
        for (int sign = 0; sign < 2; ++sign) {
            stencilWidths[axis][sign] = new int**[numZonesinZ];
            int r = sign ? radius_lo : radius_hi;
            for (int z = 0; z < numZonesinZ; ++z) {
                stencilWidths[axis][sign][z] = new int*[numZonesinY];
                for (int y = 0; y < numZonesinY; ++y) {
                    stencilWidths[axis][sign][z][y] = new int[numZonesinX];
                    for (int x = 0; x < numZonesinX; ++x)
                        stencilWidths[axis][sign][z][y][x] = r;
                }
            }
        }
    }
    // Create a decomposition manager
    decompmgr = new decompositionManager3D(nzones, numPts, costs, stencilWidths, ranks, communicator, 0);

    float dx = 1.0f;
    float dy = 1.0f;
    float dz = 1.0f;
    // no halo
    axgiX = new axis(0, dx, _npoints);
    axgiY = new axis(0, dy, _npoints);
    axgiZ = new axis(0, dz, _npoints);
    //Global axis including boundaries
    axgX = new axis(axgiX->o - _npml * axgiX->d, axgiX->e + _npml * axgiX->d, axgiX->d);
    axgY = new axis(axgiY->o - _npml * axgiY->d, axgiY->e + _npml * axgiY->d, axgiY->d);
    axgZ = new axis(axgiZ->o - _npml * axgiZ->d, axgiZ->e + _npml * axgiZ->d, axgiZ->d);

    // Get the  number of subdomains for each dimension
    int nsubs_per_dim[3];
    decompmgr->getSplitNumLocalSubDom(nsubs_per_dim);

    // For each subdomain of each dimension, create an axis
    local_X_axes.resize(nsubs_per_dim[0], nullptr);
    local_X_axes_noHalo.resize(nsubs_per_dim[0], nullptr);
    local_Y_axes.resize(nsubs_per_dim[1], nullptr);
    local_Y_axes_noHalo.resize(nsubs_per_dim[1], nullptr);
    local_Z_axes.resize(nsubs_per_dim[2], nullptr);
    local_Z_axes_noHalo.resize(nsubs_per_dim[2], nullptr);

    for (int isub = 0; isub < nsubs_per_dim[0]; ++isub) // num sub domains in X axis
    {
        int offset = decompmgr->getOffset(isub, 0); // 0 -- X axis
        float origin = axgX->o + (float(offset) * axgX->d);
        int nxloc = decompmgr->getNumPtsSplit(isub, 0);
        local_X_axes[isub] =
            new axis(origin, dx, nxloc, radius, AlignmentElem(AlignMemBytes::NOEXTENSION, sizeof(float)));
        //for each subdomain of cpu axis without halo.
        local_X_axes_noHalo[isub] = new axis(origin, dx, nxloc);
    }

    for (int isub = 0; isub < nsubs_per_dim[1]; ++isub) // num sub domains in Y axis
    {
        int offset = decompmgr->getOffset(isub, 1); // 1 -- Y axis
        float origin = axgY->o + (float(offset) * axgY->d);
        int nyloc = decompmgr->getNumPtsSplit(isub, 1);
        local_Y_axes[isub] = new axis(origin, dy, nyloc, radius);
        local_Y_axes_noHalo[isub] = new axis(origin, dy, nyloc);
    }

    for (int isub = 0; isub < nsubs_per_dim[2]; ++isub) // num sub domains in Z axis
    {
        int offset = decompmgr->getOffset(isub, 2); // 2 -- Z axis
        float origin = axgZ->o + (float(offset) * axgZ->d);
        int nzloc = decompmgr->getNumPtsSplit(isub, 2);
        local_Z_axes[isub] = new axis(origin, dz, nzloc, radius);
        local_Z_axes_noHalo[isub] = new axis(origin, dz, nzloc);
    }

    // Total number of subvolumes
    nsubs = nsubs_per_dim[0] * nsubs_per_dim[1] * nsubs_per_dim[2];
   
    p_cpu = new cart_volume<float>*[nsubs];
    g1 = new cart_volume<float>*[nsubs];
    g2 = new cart_volume<float>*[nsubs];

    /*****************eTTI cart volumes************/

    f1 = new cart_volume<float>*[nsubs];
    f2 = new cart_volume<float>*[nsubs];
    f3 = new cart_volume<float>*[nsubs];
    f4 = new cart_volume<float>*[nsubs];
    f5 = new cart_volume<float>*[nsubs];
    f6 = new cart_volume<float>*[nsubs];
    f7 = new cart_volume<float>*[nsubs];
    f8 = new cart_volume<float>*[nsubs];
    f9 = new cart_volume<float>*[nsubs];
    M1 = new cart_volume<float>*[nsubs];
    M2 = new cart_volume<float>*[nsubs];
    M3 = new cart_volume<float>*[nsubs];
    M4 = new cart_volume<float>*[nsubs];
    M5 = new cart_volume<float>*[nsubs];
    M6 = new cart_volume<float>*[nsubs];
    M7 = new cart_volume<float>*[nsubs];
    M8 = new cart_volume<float>*[nsubs];
    M9 = new cart_volume<float>*[nsubs];
    M10 = new cart_volume<float>*[nsubs];
    M11 = new cart_volume<float>*[nsubs];
    M12 = new cart_volume<float>*[nsubs];
    M13 = new cart_volume<float>*[nsubs];
    M14 = new cart_volume<float>*[nsubs];
    M15 = new cart_volume<float>*[nsubs];
    M16 = new cart_volume<float>*[nsubs];
    M17 = new cart_volume<float>*[nsubs];
    M18 = new cart_volume<float>*[nsubs];
    M19 = new cart_volume<float>*[nsubs];
    M20 = new cart_volume<float>*[nsubs];
    M21 = new cart_volume<float>*[nsubs];
    M22 = new cart_volume<float>*[nsubs];
    d4 = new cart_volume<float>*[nsubs];
    d5 = new cart_volume<float>*[nsubs];
    d6 = new cart_volume<float>*[nsubs];
    d7 = new cart_volume<float>*[nsubs];
    d8 = new cart_volume<float>*[nsubs];
    d9 = new cart_volume<float>*[nsubs];
    f10 = new cart_volume<float>*[nsubs];
    f11 = new cart_volume<float>*[nsubs];
    f12 = new cart_volume<float>*[nsubs];
    f13 = new cart_volume<float>*[nsubs];
    f14 = new cart_volume<float>*[nsubs];
    f15 = new cart_volume<float>*[nsubs];
    f16 = new cart_volume<float>*[nsubs];
    f17 = new cart_volume<float>*[nsubs];
    f18 = new cart_volume<float>*[nsubs];
    f19 = new cart_volume<float>*[nsubs];
    f20 = new cart_volume<float>*[nsubs];
    f21 = new cart_volume<float>*[nsubs];
    zprime = new float*[nsubs];

    snap_f1.resize(nsubs, nullptr);
    snap_f2.resize(nsubs, nullptr);
    snap_f3.resize(nsubs, nullptr);
    snap_f4.resize(nsubs, nullptr);
    snap_f5.resize(nsubs, nullptr);
    snap_f6.resize(nsubs, nullptr);
    snap_f7.resize(nsubs, nullptr);
    snap_f8.resize(nsubs, nullptr);
    snap_f9.resize(nsubs, nullptr);

    //create and initialize cart vols
    for (int isub = 0; isub < nsubs; isub++) {
        int subid[3];
        decompmgr->getSplitLocalSubDomID(isub, subid);
        axis* ax1 = local_X_axes[subid[0]];
        axis* ax2 = local_Y_axes[subid[1]];
        axis* ax3 = local_Z_axes[subid[2]];

        // creat cart_vols and set 0
        p_cpu[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        
        f1[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f2[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f3[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f4[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f5[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f6[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f7[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f8[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f9[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M1[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M2[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M3[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M4[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M5[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M6[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M7[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M8[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M9[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M10[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M11[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M12[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M13[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M14[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M15[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M16[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M17[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M18[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M19[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M20[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M21[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        M22[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        d4[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        d5[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        d6[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        d7[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        d8[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        d9[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f10[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f11[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f12[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f13[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f14[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f15[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f16[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f17[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f18[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f19[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f20[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        f21[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        
        zprime[isub] = new float[(ax3->ntot)];

        init_fields_and_models(isub);

        // Initialize correlation buffer with snapshots
        axis* ax1_noHalo = local_X_axes_noHalo[subid[0]];
        axis* ax2_noHalo = local_Y_axes_noHalo[subid[1]];
        axis* ax3_noHalo = local_Z_axes_noHalo[subid[2]];

        snap_f1[isub] =  new cart_volume_regular_cpu(ax1_noHalo, ax2_noHalo, ax3_noHalo, true);
        snap_f2[isub] =  new cart_volume_regular_cpu(ax1_noHalo, ax2_noHalo, ax3_noHalo, true);
        snap_f3[isub] =  new cart_volume_regular_cpu(ax1_noHalo, ax2_noHalo, ax3_noHalo, true);
        snap_f4[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        snap_f5[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        snap_f6[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        snap_f7[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        snap_f8[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        snap_f9[isub] = new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        g1[isub] =  new cart_volume_regular_cpu(ax1_noHalo, ax2_noHalo, ax3_noHalo, true);
        g2[isub] =  new cart_volume_regular_cpu(ax1, ax2, ax3, true);
        corrBuffList.push_back(snap_f1[isub]);
        corrBuffList.push_back(snap_f2[isub]);
        corrBuffList.push_back(snap_f3[isub]);
        corrBuffList.push_back(snap_f4[isub]);
        corrBuffList.push_back(snap_f5[isub]);
        corrBuffList.push_back(snap_f6[isub]);
        corrBuffList.push_back(snap_f7[isub]);
        corrBuffList.push_back(snap_f8[isub]);
        corrBuffList.push_back(snap_f9[isub]);
    }
    int nbuf = corrBuffList.size();
    corrBuff_size.resize(nbuf, 0);

    for (int i = 0; i < nbuf; ++i) {
        cart_volume<realtype>* vol = corrBuffList[i];
        // Use nvalid here, so that the snapshot computational volumes can have alignment padding if desired.
        // The snapshot storage will strip any padding.
        int n1 = vol->as<cart_volume_regular>()->ax1()->nvalid;
        int n2 = vol->as<cart_volume_regular>()->ax2()->nvalid;
        int n3 = vol->as<cart_volume_regular>()->ax3()->nvalid;

        corrBuff_size[i] = n1 * n2 * n3;
    }


    //Create cart_volumes for all sf, all subdomains.
    sf.push_back(f4);
    sf.push_back(f5);
    sf.push_back(f6);
    sf.push_back(f7);
    sf.push_back(f8);
    sf.push_back(f9);

    int nf_s = sf.size();

    vf.push_back(f1);
    vf.push_back(f2);
    vf.push_back(f3);
    int nf_v = vf.size();

    vdf.push_back(d4);
    vdf.push_back(d5);
    vdf.push_back(d6);
    vdf.push_back(d7);
    vdf.push_back(d8);
    vdf.push_back(d9);

    int nf_vd = vdf.size();

    //Sub-domain Stencil widths
    for (int axis = 0; axis < 3; ++axis) // 0 -- x; 1 -- y, 2 -- z
    {
        for (int sign = 0; sign < 2; ++sign) // 0 -- neg; 1 -- pos
        {
            subDomStencilWidths_s[axis][sign] = std::vector<std::vector<int>>(nf_s, std::vector<int>(nsubs, 0));
            subDomStencilWidths_v[axis][sign] = std::vector<std::vector<int>>(nf_v, std::vector<int>(nsubs, 0));
            subDomStencilWidths_vd[axis][sign] = std::vector<std::vector<int>>(nf_vd, std::vector<int>(nsubs, 0));
            for (int isub = 0; isub < nsubs; ++isub) {
                subDomStencilWidths_s[axis][sign][0][isub] = radius;
                subDomStencilWidths_s[axis][sign][1][isub] = radius;
                subDomStencilWidths_s[axis][sign][2][isub] = radius;
                subDomStencilWidths_s[axis][sign][3][isub] = radius;
                subDomStencilWidths_s[axis][sign][4][isub] = radius;
                subDomStencilWidths_s[axis][sign][5][isub] = radius;

                subDomStencilWidths_v[axis][sign][0][isub] = radius;
                subDomStencilWidths_v[axis][sign][1][isub] = radius;
                subDomStencilWidths_v[axis][sign][2][isub] = radius;

                subDomStencilWidths_vd[axis][sign][0][isub] = radius;
                subDomStencilWidths_vd[axis][sign][1][isub] = radius;
                subDomStencilWidths_vd[axis][sign][2][isub] = radius;
                subDomStencilWidths_vd[axis][sign][3][isub] = radius;
                subDomStencilWidths_vd[axis][sign][4][isub] = radius;
                subDomStencilWidths_vd[axis][sign][5][isub] = radius;
            } // isub
        }
    }

    //Create the GPU halo manager
    std::vector<std::vector<bool>> incEdges_s(sf.size(), std::vector<bool>(nsubs, true));
    std::vector<std::vector<bool>> incCorners_s(sf.size(), std::vector<bool>(nsubs, true));
    halomgr_s = new haloManager3D_cpu(decompmgr, sf, subDomStencilWidths_s, incEdges_s, incCorners_s);

    std::vector<std::vector<bool>> incEdges_v(vf.size(), std::vector<bool>(nsubs, true));
    std::vector<std::vector<bool>> incCorners_velocity(vf.size(), std::vector<bool>(nsubs, true));
    halomgr_v = new haloManager3D_cpu(decompmgr, vf, subDomStencilWidths_v, incEdges_v, incCorners_velocity);

    std::vector<std::vector<bool>> incEdges_vd(vdf.size(), std::vector<bool>(nsubs, true));
    std::vector<std::vector<bool>> incCorners_vd(vdf.size(), std::vector<bool>(nsubs, true));
    halomgr_vd = new haloManager3D_cpu(decompmgr, vdf, subDomStencilWidths_vd, 
                                                        incEdges_vd, incCorners_vd);


    long nfloats = 0;
    for (int i = 0; i < corrBuff_size.size(); ++i) {
        nfloats += corrBuff_size[i];
    }
    file_snap_p = file_snap_factory::create(_comm, const_cast<char*>(scratch_folder.c_str()),
                                            nfloats, memoryPercent, _niter/xcorr_step, snap_type);

    snapReaderWriter = std::make_unique<rtm_snap_cpu>();  
}

simulator4SetUp::~simulator4SetUp()
{
    for (int i = 0; i < 3; ++i) {
        delete[] numPts[i];
    }

    if (costs != nullptr) {
        for (int i = 0; i < numZonesinZ; ++i) {
            for (int j = 0; j < numZonesinY; ++j) {
                delete[] costs[i][j];
            }
            delete[] costs[i];
        }
        delete[] costs;
    }

    for (int axis = 0; axis < 3; ++axis) {
        for (int sign = 0; sign < 2; ++sign) {
            if (stencilWidths[axis][sign] != nullptr) {
                for (int z = 0; z < numZonesinZ; ++z) {
                    for (int y = 0; y < numZonesinY; ++y) {
                        delete[] stencilWidths[axis][sign][z][y];
                    }
                    delete[] stencilWidths[axis][sign][z];
                }
                delete[] stencilWidths[axis][sign];
            }
        }
    }

    delete axgiX;
    delete axgiY;
    delete axgiZ;
    delete axgX;
    delete axgY;
    delete axgZ;

    delete decompmgr;
    delete halomgr_s;
    delete halomgr_v;
}


int simulator4SetUp::get_n_for_zone(int izone, int nzones)
{
    if (nzones == 1)
        return _npoints; // 1 zone -> [_npoints]
    else {
        if (nzones == 2) // 2 zones -> [_npoints PML]
            return izone ? _npoints : _npml;
        else // 3+ zones -> [PML _npoints [_npoints...] PML]
            return (izone == 0 || izone == nzones - 1) ? _npml : _npoints;
    }
    EMSL_VERIFY(false); // shouln't be here
    return 0;
}

void simulator4SetUp::init_fields_and_models(int isub)
{
    cart_volume_regular_cpu* M1_gpu = M1[isub]->as<cart_volume_regular_cpu>();

    int ixbeg = M1_gpu->ax1()->ibeg, ixend = M1_gpu->ax1()->iend;
    int iybeg = M1_gpu->ax2()->ibeg, iyend = M1_gpu->ax2()->iend;
    int izbeg = M1_gpu->ax3()->ibeg, izend = M1_gpu->ax3()->iend;

    int xsize = M1_gpu->ax1()->ntot - M1_gpu->ax1()->npad_trailing;

    float*** f1data = f1[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f2data = f2[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f3data = f3[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f4data = f4[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f5data = f5[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f6data = f6[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f7data = f7[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f8data = f8[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f9data = f9[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f10data = f10[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f11data = f11[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f12data = f12[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f13data = f13[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f14data = f14[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f15data = f15[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f16data = f16[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f17data = f17[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f18data = f18[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f19data = f19[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f20data = f20[isub]->as<cart_volume_regular_cpu>()->data();
    float*** f21data = f21[isub]->as<cart_volume_regular_cpu>()->data();

    float*** M1data = M1[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M2data = M2[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M3data = M3[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M4data = M4[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M5data = M5[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M6data = M6[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M7data = M7[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M8data = M8[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M9data = M9[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M10data = M10[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M11data = M11[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M12data = M12[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M13data = M13[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M14data = M14[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M15data = M15[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M16data = M16[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M17data = M17[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M18data = M18[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M19data = M19[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M20data = M20[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M21data = M21[isub]->as<cart_volume_regular_cpu>()->data();
    float*** M22data = M22[isub]->as<cart_volume_regular_cpu>()->data();

    float*** d4data = d4[isub]->as<cart_volume_regular_cpu>()->data();
    float*** d5data = d5[isub]->as<cart_volume_regular_cpu>()->data();
    float*** d6data = d6[isub]->as<cart_volume_regular_cpu>()->data();
    float*** d7data = d7[isub]->as<cart_volume_regular_cpu>()->data();
    float*** d8data = d8[isub]->as<cart_volume_regular_cpu>()->data();
    float*** d9data = d9[isub]->as<cart_volume_regular_cpu>()->data();

    init_fields_and_models_kernel( f1data,  f2data,  f3data,  f4data,  f5data,  f6data,  f7data,
                  f8data,  f9data,  f10data,  f11data,  f12data,  f13data,  f14data,
                  f15data,  f16data,  f17data,  f18data,  f19data,  f20data,  f21data,
                  M1data,  M2data,  M3data,  M4data,  M5data,  M6data,  M7data,
                  M8data,  M9data,  M10data,  M11data,  M12data,  M13data,  M14data,
                  M15data,  M16data,  M17data,  M18data,  M19data,  M20data,  M21data, 
                  M22data, d4data, d5data, d6data, d7data, d8data, d9data, zprime[isub], ixbeg, ixend,
                  iybeg, iyend, izbeg, izend);
}

void vPlainLoop(float ***f1, float ***f2, float ***f3,
        float ***f4, float ***f5, float ***f6,
        float ***f7, float ***f8, float ***f9,
        float ***M22, float *zprime,
    	int Nxtot, int Nytot, int Nztot) {

    int xbeg = 8; int ybeg = 8; int zbeg = 8;
    int xend = Nxtot - 8 - 1; int yend = Nytot - 8 - 1; int zend = Nztot - 8 - 1;

    float invd1 = 1.01f; float invd2 = 2.01f;

    float df4d1, df5d2, df6d3;
    float df7d1, df7d2;
    float df8d1, df8d3;
    float df9d2, df9d3;

    for(int iz = zbeg; iz <= zend; iz++) {
      for(int iy = ybeg; iy <= yend; iy++) {
#pragma omp simd
        for(int ix = xbeg; ix <= xend; ix++) {
        	df4d1 = invd1 * (DF_order16_1 * (f4[iz][iy][ix]   - f4[iz][iy][ix-1]) +
        		DF_order16_2 * (f4[iz][iy][ix+1] - f4[iz][iy][ix-2]) +
        		DF_order16_3 * (f4[iz][iy][ix+2] - f4[iz][iy][ix-3]) +
        		DF_order16_4 * (f4[iz][iy][ix+3] - f4[iz][iy][ix-4]) +
        		DF_order16_5 * (f4[iz][iy][ix+4] - f4[iz][iy][ix-5]) +
        		DF_order16_6 * (f4[iz][iy][ix+5] - f4[iz][iy][ix-6]) +
        		DF_order16_7 * (f4[iz][iy][ix+6] - f4[iz][iy][ix-7]) +
        		DF_order16_8 * (f4[iz][iy][ix+7] - f4[iz][iy][ix-8]));

        	df5d2 = invd2 * (DF_order16_1 * (f5[iz][iy][ix]   - f5[iz][iy-1][ix]) +
        		DF_order16_2 * (f5[iz][iy+1][ix] - f5[iz][iy-2][ix]) +
        		DF_order16_3 * (f5[iz][iy+2][ix] - f5[iz][iy-3][ix]) +
        		DF_order16_4 * (f5[iz][iy+3][ix] - f5[iz][iy-4][ix]) +
        		DF_order16_5 * (f5[iz][iy+4][ix] - f5[iz][iy-5][ix]) +
        		DF_order16_6 * (f5[iz][iy+5][ix] - f5[iz][iy-6][ix]) +
        		DF_order16_7 * (f5[iz][iy+6][ix] - f5[iz][iy-7][ix]) +
        		DF_order16_8 * (f5[iz][iy+7][ix] - f5[iz][iy-8][ix]));

        	df6d3 = zprime[iz] * (DF_order16_1 * (f6[iz][iy][ix]   - f6[iz-1][iy][ix]) +
        		DF_order16_2 * (f6[iz+1][iy][ix] - f6[iz-2][iy][ix]) +
        		DF_order16_3 * (f6[iz+2][iy][ix] - f6[iz-3][iy][ix]) +
        		DF_order16_4 * (f6[iz+3][iy][ix] - f6[iz-4][iy][ix]) +
        		DF_order16_5 * (f6[iz+4][iy][ix] - f6[iz-5][iy][ix]) +
        		DF_order16_6 * (f6[iz+5][iy][ix] - f6[iz-6][iy][ix]) +
        		DF_order16_7 * (f6[iz+6][iy][ix] - f6[iz-7][iy][ix]) +
        		DF_order16_8 * (f6[iz+7][iy][ix] - f6[iz-8][iy][ix]));

        	df7d1 = invd1 * (DF_order16_1 * (f7[iz][iy][ix+1] - f7[iz][iy][ix]) +
        		DF_order16_2 * (f7[iz][iy][ix+2] - f7[iz][iy][ix-1]) +
        		DF_order16_3 * (f7[iz][iy][ix+3] - f7[iz][iy][ix-2]) +
        		DF_order16_4 * (f7[iz][iy][ix+4] - f7[iz][iy][ix-3]) +
        		DF_order16_5 * (f7[iz][iy][ix+5] - f7[iz][iy][ix-4]) +
        		DF_order16_6 * (f7[iz][iy][ix+6] - f7[iz][iy][ix-5]) +
        		DF_order16_7 * (f7[iz][iy][ix+7] - f7[iz][iy][ix-6]) +
        		DF_order16_8 * (f7[iz][iy][ix+8] - f7[iz][iy][ix-7]));

        	df7d2 = invd2 * (DF_order16_1 * (f7[iz][iy+1][ix] - f7[iz][iy][ix]) +
        		DF_order16_2 * (f7[iz][iy+2][ix] - f7[iz][iy-1][ix]) +
        		DF_order16_3 * (f7[iz][iy+3][ix] - f7[iz][iy-2][ix]) +
        		DF_order16_4 * (f7[iz][iy+4][ix] - f7[iz][iy-3][ix]) +
        		DF_order16_5 * (f7[iz][iy+5][ix] - f7[iz][iy-4][ix]) +
        		DF_order16_6 * (f7[iz][iy+6][ix] - f7[iz][iy-5][ix]) +
        		DF_order16_7 * (f7[iz][iy+7][ix] - f7[iz][iy-6][ix]) +
        		DF_order16_8 * (f7[iz][iy+8][ix] - f7[iz][iy-7][ix]));

        	df8d3 = zprime[iz] * (DF_order16_1 * (f8[iz+1][iy][ix] - f8[iz][iy][ix])   +
        		DF_order16_2 * (f8[iz+2][iy][ix] - f8[iz-1][iy][ix]) +
        		DF_order16_3 * (f8[iz+3][iy][ix] - f8[iz-2][iy][ix]) +
        		DF_order16_4 * (f8[iz+4][iy][ix] - f8[iz-3][iy][ix]) +
        		DF_order16_5 * (f8[iz+5][iy][ix] - f8[iz-4][iy][ix])   +
        		DF_order16_6 * (f8[iz+6][iy][ix] - f8[iz-5][iy][ix]) +
        		DF_order16_7 * (f8[iz+7][iy][ix] - f8[iz-6][iy][ix]) +
        		DF_order16_8 * (f8[iz+8][iy][ix] - f8[iz-7][iy][ix]));

        	df8d1 = invd1 * (DF_order16_1 * (f8[iz][iy][ix+1] - f8[iz][iy][ix])   +
        		DF_order16_2 * (f8[iz][iy][ix+2] - f8[iz][iy][ix-1]) +
        		DF_order16_3 * (f8[iz][iy][ix+3] - f8[iz][iy][ix-2]) +
        		DF_order16_4 * (f8[iz][iy][ix+4] - f8[iz][iy][ix-3]) +
        		DF_order16_5 * (f8[iz][iy][ix+5] - f8[iz][iy][ix-4])   +
        		DF_order16_6 * (f8[iz][iy][ix+6] - f8[iz][iy][ix-5]) +
        		DF_order16_7 * (f8[iz][iy][ix+7] - f8[iz][iy][ix-6]) +
        		DF_order16_8 * (f8[iz][iy][ix+8] - f8[iz][iy][ix-7]));

        	df9d2 = invd2 * (DF_order16_1 * (f9[iz][iy+1][ix] - f9[iz][iy][ix]) +
        		DF_order16_2 * (f9[iz][iy+2][ix] - f9[iz][iy-1][ix]) +
        		DF_order16_3 * (f9[iz][iy+3][ix] - f9[iz][iy-2][ix]) +
        		DF_order16_4 * (f9[iz][iy+4][ix] - f9[iz][iy-3][ix]) +
        		DF_order16_5 * (f9[iz][iy+5][ix] - f9[iz][iy-4][ix]) +
        		DF_order16_6 * (f9[iz][iy+6][ix] - f9[iz][iy-5][ix]) +
        		DF_order16_7 * (f9[iz][iy+7][ix] - f9[iz][iy-6][ix]) +
        		DF_order16_8 * (f9[iz][iy+8][ix] - f9[iz][iy-7][ix]));

        	df9d3 = zprime[iz] * (DF_order16_1 * (f9[iz+1][iy][ix] - f9[iz][iy][ix])   +
        		DF_order16_2 * (f9[iz+2][iy][ix] - f9[iz-1][iy][ix]) +
        		DF_order16_3 * (f9[iz+3][iy][ix] - f9[iz-2][iy][ix]) +
        		DF_order16_4 * (f9[iz+4][iy][ix] - f9[iz-3][iy][ix]) +
        		DF_order16_5 * (f9[iz+5][iy][ix] - f9[iz-4][iy][ix])   +
        		DF_order16_6 * (f9[iz+6][iy][ix] - f9[iz-5][iy][ix]) +
        		DF_order16_7 * (f9[iz+7][iy][ix] - f9[iz-6][iy][ix]) +
        		DF_order16_8 * (f9[iz+8][iy][ix] - f9[iz-7][iy][ix]));

          f1[iz][iy][ix] += (2.0f*M22[iz][iy][ix-1]) * (df4d1 + df7d2 + df8d3);
          f2[iz][iy][ix] += (2.0f*M22[iz][iy-1][ix]) * (df7d1 + df5d2 + df9d3);
          f3[iz][iy][ix] += (2.0f*M22[iz-1][iy][ix]) * (df8d1 + df9d2 + df6d3);

        }//end ix
      }//end iy
    }//end iz
}//end vPlainLoop

void vgPlainLoop(float ***f1, float ***f2, float ***f3,
    float ***d4, float ***d5, float ***d6,
    float ***d7, float ***d8, float ***d9,
    float *zprime, int Nxtot, int Nytot, int Nztot) 
{

    int xbeg = 8; int ybeg = 8; int zbeg = 8;
    int xend = Nxtot - 8 - 1; int yend = Nytot - 8 - 1; int zend = Nztot - 8 - 1;

    float df1d1, df1d2, df1d3;
    float df2d1, df2d2, df2d3;
    float df3d1, df3d2, df3d3;
    float df1d2_sum_df2d1, df1d3_sum_df3d1, df2d3_sum_df3d2;

    float invd1 = 1.01f, invd2 = 2.02f;

    for(int iz = zbeg; iz <= zend; iz++) {
        for(int iy = ybeg; iy <= yend; iy++) {
#pragma omp simd
            for(int ix = xbeg; ix <= xend; ix++) {
                df1d1 = invd1 * (
                    DF_order16_1*(f1[iz][iy][ix+1]-f1[iz][iy][ix  ]) +
                    DF_order16_2*(f1[iz][iy][ix+2]-f1[iz][iy][ix-1]) +
                    DF_order16_3*(f1[iz][iy][ix+3]-f1[iz][iy][ix-2]) +
                    DF_order16_4*(f1[iz][iy][ix+4]-f1[iz][iy][ix-3]) +
					DF_order16_5*(f1[iz][iy][ix+5]-f1[iz][iy][ix-4]) +
					DF_order16_6*(f1[iz][iy][ix+6]-f1[iz][iy][ix-5]) +
					DF_order16_7*(f1[iz][iy][ix+7]-f1[iz][iy][ix-6]) +
					DF_order16_8*(f1[iz][iy][ix+8]-f1[iz][iy][ix-7]));

                df2d2 = invd2 * (
                    DF_order16_1*(f2[iz][iy+1][ix]-f2[iz][iy  ][ix]) +
                    DF_order16_2*(f2[iz][iy+2][ix]-f2[iz][iy-1][ix]) +
                    DF_order16_3*(f2[iz][iy+3][ix]-f2[iz][iy-2][ix]) +
                    DF_order16_4*(f2[iz][iy+4][ix]-f2[iz][iy-3][ix]) +
					DF_order16_5*(f2[iz][iy+5][ix]-f2[iz][iy-4][ix]) +
					DF_order16_6*(f2[iz][iy+6][ix]-f2[iz][iy-5][ix]) +
					DF_order16_7*(f2[iz][iy+7][ix]-f2[iz][iy-6][ix]) +
					DF_order16_8*(f2[iz][iy+8][ix]-f2[iz][iy-7][ix]));

                df3d3 = zprime[iz] * (
                    DF_order16_1*(f3[iz+1][iy][ix]-f3[iz  ][iy][ix]) +
                    DF_order16_2*(f3[iz+2][iy][ix]-f3[iz-1][iy][ix]) +
                    DF_order16_3*(f3[iz+3][iy][ix]-f3[iz-2][iy][ix]) +
                    DF_order16_4*(f3[iz+4][iy][ix]-f3[iz-3][iy][ix]) +
					DF_order16_1*(f3[iz+5][iy][ix]-f3[iz-4][iy][ix]) +
					DF_order16_2*(f3[iz+6][iy][ix]-f3[iz-5][iy][ix]) +
					DF_order16_3*(f3[iz+7][iy][ix]-f3[iz-6][iy][ix]) +
					DF_order16_4*(f3[iz+8][iy][ix]-f3[iz-7][iy][ix]));

                df1d2 = invd2 * (
                    DF_order16_1*(f1[iz][iy  ][ix]-f1[iz][iy-1][ix]) +
                    DF_order16_2*(f1[iz][iy+1][ix]-f1[iz][iy-2][ix]) +
                    DF_order16_3*(f1[iz][iy+2][ix]-f1[iz][iy-3][ix]) +
                    DF_order16_4*(f1[iz][iy+3][ix]-f1[iz][iy-4][ix]) +
					DF_order16_5*(f1[iz][iy+4][ix]-f1[iz][iy-5][ix]) +
					DF_order16_6*(f1[iz][iy+5][ix]-f1[iz][iy-6][ix]) +
					DF_order16_7*(f1[iz][iy+6][ix]-f1[iz][iy-7][ix]) +
					DF_order16_8*(f1[iz][iy+7][ix]-f1[iz][iy-8][ix]));

                df2d1 = invd1 * (
                    DF_order16_1*(f2[iz][iy][ix  ]-f2[iz][iy][ix-1]) +
                    DF_order16_2*(f2[iz][iy][ix+1]-f2[iz][iy][ix-2]) +
                    DF_order16_3*(f2[iz][iy][ix+2]-f2[iz][iy][ix-3]) +
                    DF_order16_4*(f2[iz][iy][ix+3]-f2[iz][iy][ix-4]) +
					DF_order16_5*(f2[iz][iy][ix+4]-f2[iz][iy][ix-5]) +
					DF_order16_6*(f2[iz][iy][ix+5]-f2[iz][iy][ix-6]) +
					DF_order16_7*(f2[iz][iy][ix+6]-f2[iz][iy][ix-7]) +
					DF_order16_8*(f2[iz][iy][ix+7]-f2[iz][iy][ix-8]));

                df1d3 = zprime[iz] * (
                    DF_order16_1*(f1[iz  ][iy][ix]-f1[iz-1][iy][ix]) +
                    DF_order16_2*(f1[iz+1][iy][ix]-f1[iz-2][iy][ix]) +
                    DF_order16_3*(f1[iz+2][iy][ix]-f1[iz-3][iy][ix]) +
                    DF_order16_4*(f1[iz+3][iy][ix]-f1[iz-4][iy][ix]) +
					DF_order16_5*(f1[iz+4][iy][ix]-f1[iz-5][iy][ix]) +
					DF_order16_6*(f1[iz+5][iy][ix]-f1[iz-6][iy][ix]) +
					DF_order16_7*(f1[iz+6][iy][ix]-f1[iz-7][iy][ix]) +
					DF_order16_8*(f1[iz+7][iy][ix]-f1[iz-8][iy][ix]));

                df3d1 = invd1 * (
                    DF_order16_1*(f3[iz][iy][ix  ]-f3[iz][iy][ix-1]) +
                    DF_order16_2*(f3[iz][iy][ix+1]-f3[iz][iy][ix-2]) +
                    DF_order16_3*(f3[iz][iy][ix+2]-f3[iz][iy][ix-3]) +
                    DF_order16_4*(f3[iz][iy][ix+3]-f3[iz][iy][ix-4]) +
					DF_order16_5*(f3[iz][iy][ix+4]-f3[iz][iy][ix-5]) +
					DF_order16_6*(f3[iz][iy][ix+5]-f3[iz][iy][ix-6]) +
					DF_order16_7*(f3[iz][iy][ix+6]-f3[iz][iy][ix-7]) +
					DF_order16_8*(f3[iz][iy][ix+7]-f3[iz][iy][ix-8]));

                df2d3 = zprime[iz] * (
                    DF_order16_1*(f2[iz  ][iy][ix]-f2[iz-1][iy][ix]) +
                    DF_order16_2*(f2[iz+1][iy][ix]-f2[iz-2][iy][ix]) +
                    DF_order16_3*(f2[iz+2][iy][ix]-f2[iz-3][iy][ix]) +
                    DF_order16_4*(f2[iz+3][iy][ix]-f2[iz-4][iy][ix]) +
					DF_order16_5*(f2[iz+4][iy][ix]-f2[iz-5][iy][ix]) +
					DF_order16_6*(f2[iz+5][iy][ix]-f2[iz-6][iy][ix]) +
					DF_order16_7*(f2[iz+6][iy][ix]-f2[iz-7][iy][ix]) +
					DF_order16_8*(f2[iz+7][iy][ix]-f2[iz-8][iy][ix]));

                df3d2 = invd2 * (
                    DF_order16_1*(f3[iz][iy  ][ix]-f3[iz][iy-1][ix]) +
                    DF_order16_2*(f3[iz][iy+1][ix]-f3[iz][iy-2][ix]) +
                    DF_order16_3*(f3[iz][iy+2][ix]-f3[iz][iy-3][ix]) +
                    DF_order16_4*(f3[iz][iy+3][ix]-f3[iz][iy-4][ix]) +
					DF_order16_5*(f3[iz][iy+4][ix]-f3[iz][iy-5][ix]) +
					DF_order16_6*(f3[iz][iy+5][ix]-f3[iz][iy-6][ix]) +
					DF_order16_7*(f3[iz][iy+6][ix]-f3[iz][iy-7][ix]) +
					DF_order16_8*(f3[iz][iy+7][ix]-f3[iz][iy-8][ix]));

                df1d2_sum_df2d1 = df1d2 + df2d1;
                df1d3_sum_df3d1 = df1d3 + df3d1;
                df2d3_sum_df3d2 = df2d3 + df3d2;

                d4[iz][iy][ix] = df1d1;
                d5[iz][iy][ix] = df1d2_sum_df2d1;
                d6[iz][iy][ix] = df1d3_sum_df3d1;
                d7[iz][iy][ix] = df2d2;
                d8[iz][iy][ix] = df2d3_sum_df3d2;
                d9[iz][iy][ix] = df3d3;
            } // end ix
        } // end iy
    } // end iz
}

void sPlainLoop(
        float ***f4, float ***f5, float ***f6,
        float ***f7, float ***f8, float ***f9,
        float ***M1, float ***M2,  float ***M3,
        float ***M4, float ***M5,  float ***M6,
        float ***M7, float ***M8,  float ***M9,
        float ***M10, float ***M11,  float ***M12,
        float ***M13, float ***M14,  float ***M15,
        float ***M16, float ***M17,  float ***M18,
        float ***M19, float ***M20,  float ***M21,
        float ***d4, float ***d5, float ***d6,
        float ***d7, float ***d8, float ***d9,
        float *zprime, int Nxtot, int Nytot, int Nztot) 
{

    int xbeg = 8; int ybeg = 8; int zbeg = 8;
    int xend = Nxtot - 8 - 1; int yend = Nytot - 8 - 1; int zend = Nztot - 8 - 1;

    float dv1d1, dv2d2, dv3d3;
    float dv1d2, dv1d3, dv2d3;
    float dv1d2_xx, dv1d3_xx, dv2d3_xx;
    float dv1d1_xy, dv2d2_xy, dv3d3_xy, dv1d3_xy, dv2d3_xy;
    float dv1d1_xz, dv2d2_xz, dv3d3_xz, dv2d3_xz, dv1d2_xz;
    float dv1d1_yz, dv2d2_yz, dv3d3_yz, dv1d3_yz, dv1d2_yz;

    for(int iz = zbeg; iz <= zend; iz++) {
        for(int iy = ybeg; iy <= yend; iy++) {
#pragma omp simd
            for(int ix = xbeg; ix <= xend; ix++) {
                dv1d1 = d4[iz][iy][ix];
                dv2d2 = d7[iz][iy][ix];
                dv3d3 = d9[iz][iy][ix];

                dv1d2 = d5[iz][iy][ix];
                dv1d3 = d6[iz][iy][ix];
                dv2d3 = d8[iz][iy][ix];

                dv1d2_xx = 0.5f*(
                    INT_S_O16_1*(d5[iz][iy+1][ix+1]+d5[iz][iy  ][ix  ]+d5[iz][iy+1][ix  ]+d5[iz][iy  ][ix+1]) +
                    INT_S_O16_2*(d5[iz][iy+2][ix+2]+d5[iz][iy-1][ix-1]+d5[iz][iy+2][ix-1]+d5[iz][iy-1][ix+2]) +
                    INT_S_O16_3*(d5[iz][iy+3][ix+3]+d5[iz][iy-2][ix-2]+d5[iz][iy+3][ix-2]+d5[iz][iy-2][ix+3]) +
                    INT_S_O16_4*(d5[iz][iy+4][ix+4]+d5[iz][iy-3][ix-3]+d5[iz][iy+4][ix-3]+d5[iz][iy-3][ix+4]) +
                    INT_S_O16_5*(d5[iz][iy+5][ix+5]+d5[iz][iy-4][ix-4]+d5[iz][iy+5][ix-4]+d5[iz][iy-4][ix+5]) +
                    INT_S_O16_6*(d5[iz][iy+6][ix+6]+d5[iz][iy-5][ix-5]+d5[iz][iy+6][ix-5]+d5[iz][iy-5][ix+6]) +
                    INT_S_O16_7*(d5[iz][iy+7][ix+7]+d5[iz][iy-6][ix-6]+d5[iz][iy+7][ix-6]+d5[iz][iy-6][ix+7]) +
                    INT_S_O16_8*(d5[iz][iy+8][ix+8]+d5[iz][iy-7][ix-7]+d5[iz][iy+8][ix-7]+d5[iz][iy-7][ix+8]));

                dv1d3_xx = 0.5f*(
                    INT_S_O16_1*(d6[iz+1][iy][ix+1]+d6[iz  ][iy][ix  ]+d6[iz+1][iy][ix  ]+d6[iz  ][iy][ix+1]) +
                    INT_S_O16_2*(d6[iz+2][iy][ix+2]+d6[iz-1][iy][ix-1]+d6[iz+2][iy][ix-1]+d6[iz-1][iy][ix+2]) +
                    INT_S_O16_3*(d6[iz+3][iy][ix+3]+d6[iz-2][iy][ix-2]+d6[iz+3][iy][ix-2]+d6[iz-2][iy][ix+3]) +
                    INT_S_O16_4*(d6[iz+4][iy][ix+4]+d6[iz-3][iy][ix-3]+d6[iz+4][iy][ix-3]+d6[iz-3][iy][ix+4]) +
                    INT_S_O16_5*(d6[iz+5][iy][ix+5]+d6[iz-4][iy][ix-4]+d6[iz+5][iy][ix-4]+d6[iz-4][iy][ix+5]) +
                    INT_S_O16_6*(d6[iz+6][iy][ix+6]+d6[iz-5][iy][ix-5]+d6[iz+6][iy][ix-5]+d6[iz-5][iy][ix+6]) +
                    INT_S_O16_7*(d6[iz+7][iy][ix+7]+d6[iz-6][iy][ix-6]+d6[iz+7][iy][ix-6]+d6[iz-6][iy][ix+7]) +
                    INT_S_O16_8*(d6[iz+8][iy][ix+8]+d6[iz-7][iy][ix-7]+d6[iz+8][iy][ix-7]+d6[iz-7][iy][ix+8]));

                dv2d3_xx = 0.5f*(
                    INT_S_O16_1*(d8[iz+1][iy+1][ix]+d8[iz  ][iy  ][ix]+d8[iz+1][iy  ][ix]+d8[iz  ][iy+1][ix]) +
                    INT_S_O16_2*(d8[iz+2][iy+2][ix]+d8[iz-1][iy-1][ix]+d8[iz+2][iy-1][ix]+d8[iz-1][iy+2][ix]) +
                    INT_S_O16_3*(d8[iz+3][iy+3][ix]+d8[iz-2][iy-2][ix]+d8[iz+3][iy-2][ix]+d8[iz-2][iy+3][ix]) +
                    INT_S_O16_4*(d8[iz+4][iy+4][ix]+d8[iz-3][iy-3][ix]+d8[iz+4][iy-3][ix]+d8[iz-3][iy+4][ix]) +
                    INT_S_O16_5*(d8[iz+5][iy+5][ix]+d8[iz-4][iy-4][ix]+d8[iz+5][iy-4][ix]+d8[iz-4][iy+5][ix]) +
                    INT_S_O16_6*(d8[iz+6][iy+6][ix]+d8[iz-5][iy-5][ix]+d8[iz+6][iy-5][ix]+d8[iz-5][iy+6][ix]) +
                    INT_S_O16_7*(d8[iz+7][iy+7][ix]+d8[iz-6][iy-6][ix]+d8[iz+7][iy-6][ix]+d8[iz-6][iy+7][ix]) +
                    INT_S_O16_8*(d8[iz+8][iy+8][ix]+d8[iz-7][iy-7][ix]+d8[iz+8][iy-7][ix]+d8[iz-7][iy+8][ix]));

                f4[iz][iy][ix] += M1[iz][iy][ix]*dv1d1    + M2[iz][iy][ix]*dv2d2    + M3[iz][iy][ix]*dv3d3
                  + M6[iz][iy][ix]*dv1d2_xx + M5[iz][iy][ix]*dv1d3_xx + M4[iz][iy][ix]*dv2d3_xx;

                f5[iz][iy][ix] += M2[iz][iy][ix]*dv1d1    + M7[iz][iy][ix]*dv2d2    + M8[iz][iy][ix]*dv3d3
                  + M11[iz][iy][ix]*dv1d2_xx + M10[iz][iy][ix]*dv1d3_xx + M9[iz][iy][ix]*dv2d3_xx;

                f6[iz][iy][ix] += M3[iz][iy][ix]*dv1d1    + M8[iz][iy][ix]*dv2d2    + M12[iz][iy][ix]*dv3d3
                  + M15[iz][iy][ix]*dv1d2_xx + M14[iz][iy][ix]*dv1d3_xx + M13[iz][iy][ix]*dv2d3_xx;

                dv1d1_xy = 0.5f*(
                    INT_S_O16_1*(d4[iz][iy-1][ix-1]+d4[iz][iy  ][ix  ]+d4[iz][iy-1][ix  ]+d4[iz][iy  ][ix-1]) +
                    INT_S_O16_2*(d4[iz][iy-2][ix-2]+d4[iz][iy+1][ix+1]+d4[iz][iy-2][ix+1]+d4[iz][iy+1][ix-2]) +
                    INT_S_O16_3*(d4[iz][iy-3][ix-3]+d4[iz][iy+2][ix+2]+d4[iz][iy-3][ix+2]+d4[iz][iy+2][ix-3]) +
                    INT_S_O16_4*(d4[iz][iy-4][ix-4]+d4[iz][iy+3][ix+3]+d4[iz][iy-4][ix+3]+d4[iz][iy+3][ix-4]) +
                    INT_S_O16_5*(d4[iz][iy-5][ix-5]+d4[iz][iy+4][ix+4]+d4[iz][iy-5][ix+4]+d4[iz][iy+4][ix-5]) +
                    INT_S_O16_6*(d4[iz][iy-6][ix-6]+d4[iz][iy+5][ix+5]+d4[iz][iy-6][ix+5]+d4[iz][iy+5][ix-6]) +
                    INT_S_O16_7*(d4[iz][iy-7][ix-7]+d4[iz][iy+6][ix+6]+d4[iz][iy-7][ix+6]+d4[iz][iy+6][ix-7]) +
                    INT_S_O16_8*(d4[iz][iy-8][ix-8]+d4[iz][iy+7][ix+7]+d4[iz][iy-8][ix+7]+d4[iz][iy+7][ix-8]));

                dv2d2_xy = 0.5f*(
                    INT_S_O16_1*(d7[iz][iy-1][ix-1]+d7[iz][iy  ][ix  ]+d7[iz][iy-1][ix  ]+d7[iz][iy  ][ix-1]) +
                    INT_S_O16_2*(d7[iz][iy-2][ix-2]+d7[iz][iy+1][ix+1]+d7[iz][iy-2][ix+1]+d7[iz][iy+1][ix-2]) +
                    INT_S_O16_3*(d7[iz][iy-3][ix-3]+d7[iz][iy+2][ix+2]+d7[iz][iy-3][ix+2]+d7[iz][iy+2][ix-3]) +
                    INT_S_O16_4*(d7[iz][iy-4][ix-4]+d7[iz][iy+3][ix+3]+d7[iz][iy-4][ix+3]+d7[iz][iy+3][ix-4]) +
                    INT_S_O16_5*(d7[iz][iy-5][ix-5]+d7[iz][iy+4][ix+4]+d7[iz][iy-5][ix+4]+d7[iz][iy+4][ix-5]) +
                    INT_S_O16_6*(d7[iz][iy-6][ix-6]+d7[iz][iy+5][ix+5]+d7[iz][iy-6][ix+5]+d7[iz][iy+5][ix-6]) +
                    INT_S_O16_7*(d7[iz][iy-7][ix-7]+d7[iz][iy+6][ix+6]+d7[iz][iy-7][ix+6]+d7[iz][iy+6][ix-7]) +
                    INT_S_O16_8*(d7[iz][iy-8][ix-8]+d7[iz][iy+7][ix+7]+d7[iz][iy-8][ix+7]+d7[iz][iy+7][ix-8]));

                dv3d3_xy = 0.5f*(
                    INT_S_O16_1*(d9[iz][iy-1][ix-1]+d9[iz][iy  ][ix  ]+d9[iz][iy-1][ix  ]+d9[iz][iy  ][ix-1]) +
                    INT_S_O16_2*(d9[iz][iy-2][ix-2]+d9[iz][iy+1][ix+1]+d9[iz][iy-2][ix+1]+d9[iz][iy+1][ix-2]) +
                    INT_S_O16_3*(d9[iz][iy-3][ix-3]+d9[iz][iy+2][ix+2]+d9[iz][iy-3][ix+2]+d9[iz][iy+2][ix-3]) +
                    INT_S_O16_4*(d9[iz][iy-4][ix-4]+d9[iz][iy+3][ix+3]+d9[iz][iy-4][ix+3]+d9[iz][iy+3][ix-4]) +
                    INT_S_O16_5*(d9[iz][iy-5][ix-5]+d9[iz][iy+4][ix+4]+d9[iz][iy-5][ix+4]+d9[iz][iy+4][ix-5]) +
                    INT_S_O16_6*(d9[iz][iy-6][ix-6]+d9[iz][iy+5][ix+5]+d9[iz][iy-6][ix+5]+d9[iz][iy+5][ix-6]) +
                    INT_S_O16_7*(d9[iz][iy-7][ix-7]+d9[iz][iy+6][ix+6]+d9[iz][iy-7][ix+6]+d9[iz][iy+6][ix-7]) +
                    INT_S_O16_8*(d9[iz][iy-8][ix-8]+d9[iz][iy+7][ix+7]+d9[iz][iy-8][ix+7]+d9[iz][iy+7][ix-8]));

                dv1d3_xy = 0.5f*(
                    INT_S_O16_1*(d6[iz+1][iy-1][ix]+d6[iz  ][iy  ][ix]+d6[iz  ][iy-1][ix]+d6[iz+1][iy  ][ix]) +
                    INT_S_O16_2*(d6[iz+2][iy-2][ix]+d6[iz-1][iy+1][ix]+d6[iz-1][iy-2][ix]+d6[iz+2][iy+1][ix]) +
                    INT_S_O16_3*(d6[iz+3][iy-3][ix]+d6[iz-2][iy+2][ix]+d6[iz-2][iy-3][ix]+d6[iz+3][iy+2][ix]) +
                    INT_S_O16_4*(d6[iz+4][iy-4][ix]+d6[iz-3][iy+3][ix]+d6[iz-3][iy-4][ix]+d6[iz+4][iy+3][ix]) +
                    INT_S_O16_5*(d6[iz+5][iy-5][ix]+d6[iz-4][iy+4][ix]+d6[iz-4][iy-5][ix]+d6[iz+5][iy+4][ix]) +
                    INT_S_O16_6*(d6[iz+6][iy-6][ix]+d6[iz-5][iy+5][ix]+d6[iz-5][iy-6][ix]+d6[iz+6][iy+5][ix]) +
                    INT_S_O16_7*(d6[iz+7][iy-7][ix]+d6[iz-6][iy+6][ix]+d6[iz-6][iy-7][ix]+d6[iz+7][iy+6][ix]) +
                    INT_S_O16_8*(d6[iz+8][iy-8][ix]+d6[iz-7][iy+7][ix]+d6[iz-7][iy-8][ix]+d6[iz+8][iy+7][ix]));

                dv2d3_xy = 0.5f*(
                    INT_S_O16_1*(d8[iz+1][iy][ix-1]+d8[iz  ][iy][ix  ]+d8[iz  ][iy][ix-1]+d8[iz+1][iy][ix  ]) +
                    INT_S_O16_2*(d8[iz+2][iy][ix-2]+d8[iz-1][iy][ix+1]+d8[iz-1][iy][ix-2]+d8[iz+2][iy][ix+1]) +
                    INT_S_O16_3*(d8[iz+3][iy][ix-3]+d8[iz-2][iy][ix+2]+d8[iz-2][iy][ix-3]+d8[iz+3][iy][ix+2]) +
                    INT_S_O16_4*(d8[iz+4][iy][ix-4]+d8[iz-3][iy][ix+3]+d8[iz-3][iy][ix-4]+d8[iz+4][iy][ix+3]) +
                    INT_S_O16_5*(d8[iz+5][iy][ix-5]+d8[iz-4][iy][ix+4]+d8[iz-4][iy][ix-5]+d8[iz+5][iy][ix+4]) +
                    INT_S_O16_6*(d8[iz+6][iy][ix-6]+d8[iz-5][iy][ix+5]+d8[iz-5][iy][ix-6]+d8[iz+6][iy][ix+5]) +
                    INT_S_O16_7*(d8[iz+7][iy][ix-7]+d8[iz-6][iy][ix+6]+d8[iz-6][iy][ix-7]+d8[iz+7][iy][ix+6]) +
                    INT_S_O16_8*(d8[iz+8][iy][ix-8]+d8[iz-7][iy][ix+7]+d8[iz-7][iy][ix-8]+d8[iz+8][iy][ix+7]));

                f7[iz][iy][ix] += M6[iz][iy][ix]*dv1d1_xy + M11[iz][iy][ix]*dv2d2_xy + M15[iz][iy][ix]*dv3d3_xy
                  + M20[iz][iy][ix]*dv1d3_xy + M18[iz][iy][ix]*dv2d3_xy
                  + M21[iz][iy][ix]*dv1d2;

                dv1d1_xz = 0.5f*(
                    INT_S_O16_1*(d4[iz-1][iy][ix-1]+d4[iz  ][iy][ix  ]+d4[iz-1][iy][ix  ]+d4[iz  ][iy][ix-1]) +
                    INT_S_O16_2*(d4[iz-2][iy][ix-2]+d4[iz+1][iy][ix+1]+d4[iz-2][iy][ix+1]+d4[iz+1][iy][ix-2]) +
                    INT_S_O16_3*(d4[iz-3][iy][ix-3]+d4[iz+2][iy][ix+2]+d4[iz-3][iy][ix+2]+d4[iz+2][iy][ix-3]) +
                    INT_S_O16_4*(d4[iz-4][iy][ix-4]+d4[iz+3][iy][ix+3]+d4[iz-4][iy][ix+3]+d4[iz+3][iy][ix-4]) +
                    INT_S_O16_5*(d4[iz-5][iy][ix-5]+d4[iz+4][iy][ix+4]+d4[iz-5][iy][ix+4]+d4[iz+4][iy][ix-5]) +
                    INT_S_O16_6*(d4[iz-6][iy][ix-6]+d4[iz+5][iy][ix+5]+d4[iz-6][iy][ix+5]+d4[iz+5][iy][ix-6]) +
                    INT_S_O16_7*(d4[iz-7][iy][ix-7]+d4[iz+6][iy][ix+6]+d4[iz-7][iy][ix+6]+d4[iz+6][iy][ix-7]) +
                    INT_S_O16_8*(d4[iz-8][iy][ix-8]+d4[iz+7][iy][ix+7]+d4[iz-8][iy][ix+7]+d4[iz+7][iy][ix-8]));

                dv2d2_xz = 0.5f*(
                    INT_S_O16_1*(d7[iz-1][iy][ix-1]+d7[iz  ][iy][ix  ]+d7[iz-1][iy][ix  ]+d7[iz  ][iy][ix-1]) +
                    INT_S_O16_2*(d7[iz-2][iy][ix-2]+d7[iz+1][iy][ix+1]+d7[iz-2][iy][ix+1]+d7[iz+1][iy][ix-2]) +
                    INT_S_O16_3*(d7[iz-3][iy][ix-3]+d7[iz+2][iy][ix+2]+d7[iz-3][iy][ix+2]+d7[iz+2][iy][ix-3]) +
                    INT_S_O16_4*(d7[iz-4][iy][ix-4]+d7[iz+3][iy][ix+3]+d7[iz-4][iy][ix+3]+d7[iz+3][iy][ix-4]) +
                    INT_S_O16_5*(d7[iz-5][iy][ix-5]+d7[iz+4][iy][ix+4]+d7[iz-5][iy][ix+4]+d7[iz+4][iy][ix-5]) +
                    INT_S_O16_6*(d7[iz-6][iy][ix-6]+d7[iz+5][iy][ix+5]+d7[iz-6][iy][ix+5]+d7[iz+5][iy][ix-6]) +
                    INT_S_O16_7*(d7[iz-7][iy][ix-7]+d7[iz+6][iy][ix+6]+d7[iz-7][iy][ix+6]+d7[iz+6][iy][ix-7]) +
                    INT_S_O16_8*(d7[iz-8][iy][ix-8]+d7[iz+7][iy][ix+7]+d7[iz-8][iy][ix+7]+d7[iz+7][iy][ix-8]));

                dv3d3_xz = 0.5f*(
                    INT_S_O16_1*(d9[iz-1][iy][ix-1]+d9[iz  ][iy][ix  ]+d9[iz-1][iy][ix  ]+d9[iz  ][iy][ix-1]) +
                    INT_S_O16_2*(d9[iz-2][iy][ix-2]+d9[iz+1][iy][ix+1]+d9[iz-2][iy][ix+1]+d9[iz+1][iy][ix-2]) +
                    INT_S_O16_3*(d9[iz-3][iy][ix-3]+d9[iz+2][iy][ix+2]+d9[iz-3][iy][ix+2]+d9[iz+2][iy][ix-3]) +
                    INT_S_O16_4*(d9[iz-4][iy][ix-4]+d9[iz+3][iy][ix+3]+d9[iz-4][iy][ix+3]+d9[iz+3][iy][ix-4]) +
                    INT_S_O16_5*(d9[iz-5][iy][ix-5]+d9[iz+4][iy][ix+4]+d9[iz-5][iy][ix+4]+d9[iz+4][iy][ix-5]) +
                    INT_S_O16_6*(d9[iz-6][iy][ix-6]+d9[iz+5][iy][ix+5]+d9[iz-6][iy][ix+5]+d9[iz+5][iy][ix-6]) +
                    INT_S_O16_7*(d9[iz-7][iy][ix-7]+d9[iz+6][iy][ix+6]+d9[iz-7][iy][ix+6]+d9[iz+6][iy][ix-7]) +
                    INT_S_O16_8*(d9[iz-8][iy][ix-8]+d9[iz+7][iy][ix+7]+d9[iz-8][iy][ix+7]+d9[iz+7][iy][ix-8]));

                dv1d2_xz = 0.5f*(
                    INT_S_O16_1*(d5[iz-1][iy+1][ix]+d5[iz  ][iy  ][ix]+d5[iz-1][iy  ][ix]+d5[iz  ][iy+1][ix]) +
                    INT_S_O16_2*(d5[iz-2][iy+2][ix]+d5[iz+1][iy-1][ix]+d5[iz-2][iy-1][ix]+d5[iz+1][iy+2][ix]) +
                    INT_S_O16_3*(d5[iz-3][iy+3][ix]+d5[iz+2][iy-2][ix]+d5[iz-3][iy-2][ix]+d5[iz+2][iy+3][ix]) +
                    INT_S_O16_4*(d5[iz-4][iy+4][ix]+d5[iz+3][iy-3][ix]+d5[iz-4][iy-3][ix]+d5[iz+3][iy+4][ix]) +
                    INT_S_O16_5*(d5[iz-5][iy+5][ix]+d5[iz+4][iy-4][ix]+d5[iz-5][iy-4][ix]+d5[iz+4][iy+5][ix]) +
                    INT_S_O16_6*(d5[iz-6][iy+6][ix]+d5[iz+5][iy-5][ix]+d5[iz-6][iy-5][ix]+d5[iz+5][iy+6][ix]) +
                    INT_S_O16_7*(d5[iz-7][iy+7][ix]+d5[iz+6][iy-6][ix]+d5[iz-7][iy-6][ix]+d5[iz+6][iy+7][ix]) +
                    INT_S_O16_8*(d5[iz-8][iy+8][ix]+d5[iz+7][iy-7][ix]+d5[iz-8][iy-7][ix]+d5[iz+7][iy+8][ix]));
                dv2d3_xz = 0.5f*(
                    INT_S_O16_1*(d8[iz][iy+1][ix  ]+d8[iz][iy  ][ix-1]+d8[iz][iy+1][ix-1]+d8[iz][iy  ][ix  ]) +
                    INT_S_O16_2*(d8[iz][iy+2][ix+1]+d8[iz][iy-1][ix-2]+d8[iz][iy+2][ix-2]+d8[iz][iy-1][ix+1]) +
                    INT_S_O16_3*(d8[iz][iy+3][ix+2]+d8[iz][iy-2][ix-3]+d8[iz][iy+3][ix-3]+d8[iz][iy-2][ix+2]) +
                    INT_S_O16_4*(d8[iz][iy+4][ix+3]+d8[iz][iy-3][ix-4]+d8[iz][iy+4][ix-4]+d8[iz][iy-3][ix+3]) +
                    INT_S_O16_5*(d8[iz][iy+5][ix+4]+d8[iz][iy-4][ix-5]+d8[iz][iy+5][ix-5]+d8[iz][iy-4][ix+4]) +
                    INT_S_O16_6*(d8[iz][iy+6][ix+5]+d8[iz][iy-5][ix-6]+d8[iz][iy+6][ix-6]+d8[iz][iy-5][ix+5]) +
                    INT_S_O16_7*(d8[iz][iy+7][ix+6]+d8[iz][iy-6][ix-7]+d8[iz][iy+7][ix-7]+d8[iz][iy-6][ix+6]) +
                    INT_S_O16_8*(d8[iz][iy+8][ix+7]+d8[iz][iy-7][ix-8]+d8[iz][iy+8][ix-8]+d8[iz][iy-7][ix+7]));

                f8[iz][iy][ix] += M5[iz][iy][ix]*dv1d1_xz + M10[iz][iy][ix]*dv2d2_xz + M14[iz][iy][ix]*dv3d3_xz
                  + M20[iz][iy][ix]*dv1d2_xz + M17[iz][iy][ix]*dv2d3_xz
                  + M19[iz][iy][ix]*dv1d3;

                dv1d1_yz = 0.5f*(
                    INT_S_O16_1*(d4[iz-1][iy-1][ix]+d4[iz  ][iy  ][ix]+d4[iz-1][iy  ][ix]+d4[iz  ][iy-1][ix]) +
                    INT_S_O16_2*(d4[iz-2][iy-2][ix]+d4[iz+1][iy+1][ix]+d4[iz-2][iy+1][ix]+d4[iz+1][iy-2][ix]) +
                    INT_S_O16_3*(d4[iz-3][iy-3][ix]+d4[iz+2][iy+2][ix]+d4[iz-3][iy+2][ix]+d4[iz+2][iy-3][ix]) +
                    INT_S_O16_4*(d4[iz-4][iy-4][ix]+d4[iz+3][iy+3][ix]+d4[iz-4][iy+3][ix]+d4[iz+3][iy-4][ix]) +
                    INT_S_O16_5*(d4[iz-5][iy-5][ix]+d4[iz+4][iy+4][ix]+d4[iz-5][iy+4][ix]+d4[iz+4][iy-5][ix]) +
                    INT_S_O16_6*(d4[iz-6][iy-6][ix]+d4[iz+5][iy+5][ix]+d4[iz-6][iy+5][ix]+d4[iz+5][iy-6][ix]) +
                    INT_S_O16_7*(d4[iz-7][iy-7][ix]+d4[iz+6][iy+6][ix]+d4[iz-7][iy+6][ix]+d4[iz+6][iy-7][ix]) +
                    INT_S_O16_8*(d4[iz-8][iy-8][ix]+d4[iz+7][iy+7][ix]+d4[iz-8][iy+7][ix]+d4[iz+7][iy-8][ix]));

                dv2d2_yz = 0.5f*(
                    INT_S_O16_1*(d7[iz-1][iy-1][ix]+d7[iz  ][iy  ][ix]+d7[iz-1][iy  ][ix]+d7[iz  ][iy-1][ix]) +
                    INT_S_O16_2*(d7[iz-2][iy-2][ix]+d7[iz+1][iy+1][ix]+d7[iz-2][iy+1][ix]+d7[iz+1][iy-2][ix]) +
                    INT_S_O16_3*(d7[iz-3][iy-3][ix]+d7[iz+2][iy+2][ix]+d7[iz-3][iy+2][ix]+d7[iz+2][iy-3][ix]) +
                    INT_S_O16_4*(d7[iz-4][iy-4][ix]+d7[iz+3][iy+3][ix]+d7[iz-4][iy+3][ix]+d7[iz+3][iy-4][ix]) +
                    INT_S_O16_5*(d7[iz-5][iy-5][ix]+d7[iz+4][iy+4][ix]+d7[iz-5][iy+4][ix]+d7[iz+4][iy-5][ix]) +
                    INT_S_O16_6*(d7[iz-6][iy-6][ix]+d7[iz+5][iy+5][ix]+d7[iz-6][iy+5][ix]+d7[iz+5][iy-6][ix]) +
                    INT_S_O16_7*(d7[iz-7][iy-7][ix]+d7[iz+6][iy+6][ix]+d7[iz-7][iy+6][ix]+d7[iz+6][iy-7][ix]) +
                    INT_S_O16_8*(d7[iz-8][iy-8][ix]+d7[iz+7][iy+7][ix]+d7[iz-8][iy+7][ix]+d7[iz+7][iy-8][ix]));

                dv3d3_yz = 0.5f*(
                    INT_S_O16_1*(d9[iz-1][iy-1][ix]+d9[iz  ][iy  ][ix]+d9[iz-1][iy  ][ix]+d9[iz  ][iy-1][ix]) +
                    INT_S_O16_2*(d9[iz-2][iy-2][ix]+d9[iz+1][iy+1][ix]+d9[iz-2][iy+1][ix]+d9[iz+1][iy-2][ix]) +
                    INT_S_O16_3*(d9[iz-3][iy-3][ix]+d9[iz+2][iy+2][ix]+d9[iz-3][iy+2][ix]+d9[iz+2][iy-3][ix]) +
                    INT_S_O16_4*(d9[iz-4][iy-4][ix]+d9[iz+3][iy+3][ix]+d9[iz-4][iy+3][ix]+d9[iz+3][iy-4][ix]) +
                    INT_S_O16_5*(d9[iz-5][iy-5][ix]+d9[iz+4][iy+4][ix]+d9[iz-5][iy+4][ix]+d9[iz+4][iy-5][ix]) +
                    INT_S_O16_6*(d9[iz-6][iy-6][ix]+d9[iz+5][iy+5][ix]+d9[iz-6][iy+5][ix]+d9[iz+5][iy-6][ix]) +
                    INT_S_O16_7*(d9[iz-7][iy-7][ix]+d9[iz+6][iy+6][ix]+d9[iz-7][iy+6][ix]+d9[iz+6][iy-7][ix]) +
                    INT_S_O16_8*(d9[iz-8][iy-8][ix]+d9[iz+7][iy+7][ix]+d9[iz-8][iy+7][ix]+d9[iz+7][iy-8][ix]));

                dv1d2_yz = 0.5f*(
                    INT_S_O16_1*(d5[iz-1][iy][ix+1]+d5[iz  ][iy][ix  ]+d5[iz-1][iy][ix  ]+d5[iz  ][iy][ix+1]) +
                    INT_S_O16_2*(d5[iz-2][iy][ix+2]+d5[iz+1][iy][ix-1]+d5[iz-2][iy][ix-1]+d5[iz+1][iy][ix+2]) +
                    INT_S_O16_3*(d5[iz-3][iy][ix+3]+d5[iz+2][iy][ix-2]+d5[iz-3][iy][ix-2]+d5[iz+2][iy][ix+3]) +
                    INT_S_O16_4*(d5[iz-4][iy][ix+4]+d5[iz+3][iy][ix-3]+d5[iz-4][iy][ix-3]+d5[iz+3][iy][ix+4]) +
                    INT_S_O16_5*(d5[iz-5][iy][ix+5]+d5[iz+4][iy][ix-4]+d5[iz-5][iy][ix-4]+d5[iz+4][iy][ix+5]) +
                    INT_S_O16_6*(d5[iz-6][iy][ix+6]+d5[iz+5][iy][ix-5]+d5[iz-6][iy][ix-5]+d5[iz+5][iy][ix+6]) +
                    INT_S_O16_7*(d5[iz-7][iy][ix+7]+d5[iz+6][iy][ix-6]+d5[iz-7][iy][ix-6]+d5[iz+6][iy][ix+7]) +
                    INT_S_O16_8*(d5[iz-8][iy][ix+8]+d5[iz+7][iy][ix-7]+d5[iz-8][iy][ix-7]+d5[iz+7][iy][ix+8]));

                dv1d3_yz = 0.5f*(
                    INT_S_O16_1*(d6[iz][iy  ][ix+1]+d6[iz][iy-1][ix  ]+d6[iz][iy-1][ix+1]+d6[iz][iy  ][ix  ]) +
                    INT_S_O16_2*(d6[iz][iy+1][ix+2]+d6[iz][iy-2][ix-1]+d6[iz][iy-2][ix+2]+d6[iz][iy+1][ix-1]) +
                    INT_S_O16_3*(d6[iz][iy+2][ix+3]+d6[iz][iy-3][ix-2]+d6[iz][iy-3][ix+3]+d6[iz][iy+2][ix-2]) +
                    INT_S_O16_4*(d6[iz][iy+3][ix+4]+d6[iz][iy-4][ix-3]+d6[iz][iy-4][ix+4]+d6[iz][iy+3][ix-3]) +
                    INT_S_O16_5*(d6[iz][iy+4][ix+5]+d6[iz][iy-5][ix-4]+d6[iz][iy-5][ix+1]+d6[iz][iy+4][ix-4]) +
                    INT_S_O16_6*(d6[iz][iy+5][ix+6]+d6[iz][iy-6][ix-5]+d6[iz][iy-6][ix+2]+d6[iz][iy+5][ix-5]) +
                    INT_S_O16_7*(d6[iz][iy+6][ix+7]+d6[iz][iy-7][ix-6]+d6[iz][iy-7][ix+3]+d6[iz][iy+6][ix-6]) +
                    INT_S_O16_8*(d6[iz][iy+7][ix+8]+d6[iz][iy-8][ix-7]+d6[iz][iy-8][ix+4]+d6[iz][iy+7][ix-7]));

                f9[iz][iy][ix] += M4[iz][iy][ix]*dv1d1_yz + M9[iz][iy][ix]*dv2d2_yz + M13[iz][iy][ix]*dv3d3_yz
                  + M18[iz][iy][ix]*dv1d2_yz + M17[iz][iy][ix]*dv1d3_yz
                  + M16[iz][iy][ix]*dv2d3;
            } // end ix
        } // end iy
    } // end iz
}//end sPlainLoop

void
update_g_v(cart_volume<realtype>* snap_f1_vol, cart_volume<realtype>* snap_f3_vol, cart_volume<realtype>* g1_vol, 
           cart_volume<realtype>* f1_vol, cart_volume<realtype>* f3_vol, int Nxtot, int Nytot, int Nztot) 
{

    int ixbeg = 8; int iybeg = 8; int izbeg = 8;
    int ixend = Nxtot - 8 - 1; int iyend = Nytot - 8 - 1; int izend = Nztot - 8 - 1;
    auto snap_f1 = snap_f1_vol->as<cart_volume_regular_cpu>()->data();
    auto snap_f3 = snap_f3_vol->as<cart_volume_regular_cpu>()->data();
    auto g1 = g1_vol->as<cart_volume_regular_cpu>()->data();
    auto f1 = f1_vol->as<cart_volume_regular_cpu>()->data();
    auto f3 = f3_vol->as<cart_volume_regular_cpu>()->data();
    for (int iz = izbeg; iz <= izend; ++iz) {
        for (int iy = iybeg; iy <= iyend; ++iy) {
            for (int ix = ixbeg; ix <= ixend; ++ix) {
                realtype vx0 = snap_f1[iz - izbeg][iy - iybeg][ix - ixbeg];
                realtype vz0 = snap_f3[iz - izbeg][iy - iybeg][ix - ixbeg];
                g1[iz - izbeg][iy - iybeg][ix - ixbeg] += f1[iz][iy][ix] * vx0 + f3[iz][iy][ix] * vz0;
            } // ix
        }     // iy
    }         // iz
}

void simulator4SetUp::execute(bool has_src_p, bool has_qp_)
{
    TIMED_BLOCK("Total") {
        float max_pressure = 500.0f;
        TIMED_BLOCK("Forward") {
            if (has_src_p) { // source group in lib/grid/src_group.cpp
                initializeSource(max_pressure);
            }

            for (int iter = 0; iter < _niter; ++iter) {
                halomgr_s->start_update();
                halomgr_s->finish_update();

                for (int isub = 0; isub < nsubs; ++isub) {
                    float*** f1Data = f1[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f2Data = f2[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f3Data = f3[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f4Data = f4[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f5Data = f5[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f6Data = f6[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f7Data = f7[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f8Data = f8[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f9Data = f9[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M22Data = M22[isub]->as<cart_volume_regular_cpu>()->data();

                    int subid[3];
                    decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                    axis* ax1 = local_X_axes[subid[0]];
                    axis* ax2 = local_Y_axes[subid[1]];
                    axis* ax3 = local_Z_axes[subid[2]];

                    vPlainLoop(f1Data, f2Data, f3Data, f4Data, f5Data, f6Data, f7Data, f8Data, f9Data, 
                                    M22Data, zprime[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                }

                // halo exchange
                halomgr_v->start_update();            
                halomgr_v->finish_update();               
            
                for (int isub = 0; isub < nsubs; ++isub) {
                    float*** f1Data = f1[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f2Data = f2[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f3Data = f3[isub]->as<cart_volume_regular_cpu>()->data();

                    float*** d4Data = d4[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d5Data = d5[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d6Data = d6[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d7Data = d7[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d8Data = d8[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d9Data = d9[isub]->as<cart_volume_regular_cpu>()->data();

                    int subid[3];
                    decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                    axis* ax1 = local_X_axes[subid[0]];
                    axis* ax2 = local_Y_axes[subid[1]];
                    axis* ax3 = local_Z_axes[subid[2]];

                    vgPlainLoop(f1Data, f2Data, f3Data, d4Data, d5Data, d6Data, d7Data, d8Data, d9Data, 
                                            zprime[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                }

                // halo exchange

                halomgr_vd->start_update();
                halomgr_vd->finish_update();

                for (int isub = 0; isub < nsubs; ++isub) {
                    float*** f4Data = f4[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f5Data = f5[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f6Data = f6[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f7Data = f7[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f8Data = f8[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f9Data = f9[isub]->as<cart_volume_regular_cpu>()->data();

                    float*** d4Data = d4[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d5Data = d5[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d6Data = d6[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d7Data = d7[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d8Data = d8[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** d9Data = d9[isub]->as<cart_volume_regular_cpu>()->data();

                    float*** M1Data = M1[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M2Data = M2[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M3Data = M3[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M4Data = M4[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M5Data = M5[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M6Data = M6[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M7Data = M7[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M8Data = M8[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M9Data = M9[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M10Data = M10[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M11Data = M11[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M12Data = M12[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M13Data = M13[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M14Data = M14[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M15Data = M15[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M16Data = M16[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M17Data = M17[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M18Data = M18[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M19Data = M19[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M20Data = M20[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** M21Data = M21[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f10Data = f10[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f11Data = f11[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f12Data = f12[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f13Data = f13[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f14Data = f14[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f15Data = f15[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f16Data = f16[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f17Data = f17[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f18Data = f18[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f19Data = f19[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f20Data = f20[isub]->as<cart_volume_regular_cpu>()->data();
                    float*** f21Data = f21[isub]->as<cart_volume_regular_cpu>()->data();

                    int subid[3];
                    decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                    axis* ax1 = local_X_axes[subid[0]];
                    axis* ax2 = local_Y_axes[subid[1]];
                    axis* ax3 = local_Z_axes[subid[2]];

                    sPlainLoop(
                            f4Data, f5Data, f6Data, f7Data, f8Data, f9Data,
                            M1Data, M2Data, M3Data, M4Data, M5Data, M6Data,
                            M7Data, M8Data, M9Data, M10Data, M11Data, M12Data,
                            M13Data, M14Data, M15Data, M16Data, M17Data, M18Data,
                            M19Data, M20Data, M21Data,
                            d4Data, d5Data, d6Data, d7Data, d8Data, d9Data,
                            zprime[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                }

                for (int isub = 0; isub < nsubs; ++isub) {
                    computeP(isub);
                }
                
                if (!_fwd_only) {
                    if (iter == next_snap) {
                        bool skip_halo = true;
                        bool no_skip_halo = false;
                        for (int isub = 0; isub < nsubs; ++isub) {
                            // THIS IS NOT COMPUTATIONALLY CORRECT. We need the correct zone id. Taking this approach as we are not worried about correctness.
                            snap_f1[isub]->copyData(f1[isub], skip_halo);
                            snap_f2[isub]->copyData(f2[isub], skip_halo);
                            snap_f3[isub]->copyData(f3[isub], skip_halo);
                        }
                        // halo exchange
                        halomgr_s->start_update();            
                        halomgr_s->finish_update();
                        for (int isub = 0; isub < nsubs; ++isub) {
                            snap_f4[isub]->copyData(f4[isub], no_skip_halo);
                            snap_f5[isub]->copyData(f5[isub], no_skip_halo);
                            snap_f6[isub]->copyData(f6[isub], no_skip_halo);
                            snap_f7[isub]->copyData(f7[isub], no_skip_halo);
                            snap_f8[isub]->copyData(f8[isub], no_skip_halo);
                            snap_f9[isub]->copyData(f9[isub], no_skip_halo);
                        }

                        snapReaderWriter->start_write_uncompressed_fwi_snapshot(corrBuffList, corrBuff_size, file_snap_p);                   
                        next_snap += _xcorr_step;
                    }
                } // !_fwd_only
            } // end iter
        } // End TIMED_BLOCK ("Forward")

        if (!_fwd_only) {
            TIMED_BLOCK("Adjoint") {
                snapReaderWriter->start_read_uncompressed_fwi_snapshot(corrBuffList, corrBuff_size, file_snap_p);                
                next_snap -= _xcorr_step;
                for (int iter = _niter - 1; iter >= 0; --iter) {   
                    halomgr_v->start_update();            
                    halomgr_v->finish_update();

                    for (int isub = 0; isub < nsubs; ++isub) {
                        float*** f4Data = f4[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f5Data = f5[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f6Data = f6[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f7Data = f7[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f8Data = f8[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f9Data = f9[isub]->as<cart_volume_regular_cpu>()->data();

                        float*** d4Data = d4[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d5Data = d5[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d6Data = d6[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d7Data = d7[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d8Data = d8[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d9Data = d9[isub]->as<cart_volume_regular_cpu>()->data();

                        float*** M1Data = M1[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M2Data = M2[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M3Data = M3[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M4Data = M4[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M5Data = M5[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M6Data = M6[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M7Data = M7[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M8Data = M8[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M9Data = M9[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M10Data = M10[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M11Data = M11[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M12Data = M12[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M13Data = M13[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M14Data = M14[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M15Data = M15[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M16Data = M16[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M17Data = M17[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M18Data = M18[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M19Data = M19[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M20Data = M20[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M21Data = M21[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f10Data = f10[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f11Data = f11[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f12Data = f12[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f13Data = f13[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f14Data = f14[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f15Data = f15[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f16Data = f16[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f17Data = f17[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f18Data = f18[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f19Data = f19[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f20Data = f20[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f21Data = f21[isub]->as<cart_volume_regular_cpu>()->data();

                        int subid[3];
                        decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                        axis* ax1 = local_X_axes[subid[0]];
                        axis* ax2 = local_Y_axes[subid[1]];
                        axis* ax3 = local_Z_axes[subid[2]];

                        sPlainLoop(
                                f4Data, f5Data, f6Data, f7Data, f8Data, f9Data,
                                M1Data, M2Data, M3Data, M4Data, M5Data, M6Data,
                                M7Data, M8Data, M9Data, M10Data, M11Data, M12Data,
                                M13Data, M14Data, M15Data, M16Data, M17Data, M18Data,
                                M19Data, M20Data, M21Data,
                                d4Data, d5Data, d6Data, d7Data, d8Data, d9Data,
                                zprime[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                    }

                    halomgr_s->start_update();
                    halomgr_s->finish_update();

                    for (int isub = 0; isub < nsubs; ++isub) {
                        float*** f1Data = f1[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f2Data = f2[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f3Data = f3[isub]->as<cart_volume_regular_cpu>()->data();

                        float*** d4Data = d4[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d5Data = d5[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d6Data = d6[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d7Data = d7[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d8Data = d8[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** d9Data = d9[isub]->as<cart_volume_regular_cpu>()->data();

                        int subid[3];
                        decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                        axis* ax1 = local_X_axes[subid[0]];
                        axis* ax2 = local_Y_axes[subid[1]];
                        axis* ax3 = local_Z_axes[subid[2]];

                        vgPlainLoop(f1Data, f2Data, f3Data, d4Data, d5Data, d6Data, d7Data, d8Data, d9Data, 
                                                zprime[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                    }

                    // halo exchange
                    halomgr_vd->start_update();
                    halomgr_vd->finish_update();
                
                    for (int isub = 0; isub < nsubs; ++isub) {
                        float*** f1Data = f1[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f2Data = f2[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f3Data = f3[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f4Data = f4[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f5Data = f5[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f6Data = f6[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f7Data = f7[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f8Data = f8[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** f9Data = f9[isub]->as<cart_volume_regular_cpu>()->data();
                        float*** M22Data = M22[isub]->as<cart_volume_regular_cpu>()->data();

                        int subid[3];
                        decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                        axis* ax1 = local_X_axes[subid[0]];
                        axis* ax2 = local_Y_axes[subid[1]];
                        axis* ax3 = local_Z_axes[subid[2]];

                        vPlainLoop(f1Data, f2Data, f3Data, f4Data, f5Data, f6Data, f7Data, f8Data, f9Data, 
                                        M22Data, zprime[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                    }

                    if (iter == next_snap) {
                        for (int isub = 0; isub < nsubs; ++isub) {
                            int subid[3];
                            decompmgr->getSplitLocalSubDomID(isub, subid); // Change 0 to isub
                            axis* ax1 = local_X_axes[subid[0]];
                            axis* ax2 = local_Y_axes[subid[1]];
                            axis* ax3 = local_Z_axes[subid[2]];                            
                            update_g_v(snap_f1[isub], snap_f3[isub], g1[isub], f1[isub], f3[isub], ax1->ntot, ax2->ntot, ax3->ntot);
                        } //isub
                        halomgr_v->start_update();
                        halomgr_v->finish_update();    
                        next_snap -= _xcorr_step;
                        if (next_snap >= 0) {
                            snapReaderWriter->start_read_uncompressed_fwi_snapshot(corrBuffList, corrBuff_size, file_snap_p);
                        }
                    }          
                } // end iter
            } //end TIMED_BLOCK ("Adjoint")
        }
    } // End TIMED_BLOCK ("Total")

    timer locTotal = timer::get_timer("Total");
    timer locForward = timer::get_timer("Forward");
    double locTotalTime = locTotal.get_elapsed();
    double locForwardTime = locForward.get_elapsed();

    double maxTotalTime, maxForwardTime, maxAdjointTime;
    float max_milliseconds_g, max_milliseconds_s, max_milliseconds_v, max_milliseconds_h;
    MPI_Reduce(&locTotalTime, &maxTotalTime, 1, MPI_DOUBLE, MPI_MAX, 0, _comm);
    MPI_Reduce(&locForwardTime, &maxForwardTime, 1, MPI_DOUBLE, MPI_MAX, 0, _comm);

    if (!_fwd_only) {
        timer locAdjoint = timer::get_timer("Adjoint");    
        double locAdjointTime = locAdjoint.get_elapsed();
        MPI_Reduce(&locAdjointTime, &maxAdjointTime, 1, MPI_DOUBLE, MPI_MAX, 0, _comm);
    }

    if(_rank == 0) {
        std::cout<<"Total Time: "<<maxTotalTime<<std::endl;
        std::cout<<"Max time for Forward: "<<maxForwardTime<<std::endl;
        if (!_fwd_only)
            std::cout<<"Max time for Adjoint: "<<maxAdjointTime<<std::endl;
    }
}

void simulator4SetUp::initializeSource(float p)
{
    //find the cart_vol that has the point position _npoints/2 + 4;
    for (int i = 0; i < nsubs; i++) {
        int splitId[3];
        decompmgr->getSplitLocalSubDomID(i, splitId);
        int stOff[3];
        int endOff[3];
        for (int d = 0; d < 3; ++d) {
            stOff[d] = decompmgr->getOffset(splitId[d], d);
            endOff[d] = stOff[d] + decompmgr->getNumPtsSplit(splitId[d], d) - 1;
        } //end d
        if (stOff[0] <= n_total[0] / 2 && endOff[0] >= n_total[0] / 2 && stOff[1] <= n_total[1] / 2 &&
            endOff[1] >= n_total[1] / 2 && stOff[2] <= n_total[2] / 2 &&
            endOff[2] >= n_total[2] / 2) { // found that point
            int x = n_total[0] / 2 - stOff[0] + radius;
            int y = n_total[1] / 2 - stOff[1] + radius;
            int z = n_total[2] / 2 - stOff[2] + radius;
            init_src_kernel(f4[i]->as<cart_volume_regular_cpu>()->data(),
                            f5[i]->as<cart_volume_regular_cpu>()->data(),
                            f6[i]->as<cart_volume_regular_cpu>()->data(),
                            f7[i]->as<cart_volume_regular_cpu>()->data(),
                            f8[i]->as<cart_volume_regular_cpu>()->data(),
                            f9[i]->as<cart_volume_regular_cpu>()->data(),
                            x, y, z, p);
        }
    }
}

void simulator4SetUp::computeP(int isub)
{
    axis* ax1 = p_cpu[isub]->as<cart_volume_regular_cpu>()->ax1();
    axis* ax2 = p_cpu[isub]->as<cart_volume_regular_cpu>()->ax2();
    axis* ax3 = p_cpu[isub]->as<cart_volume_regular_cpu>()->ax3();

    compute_p_kernel(
        p_cpu[isub]->as<cart_volume_regular_cpu>()->data(),
        f4[isub]->as<cart_volume_regular_cpu>()->data(),
        f5[isub]->as<cart_volume_regular_cpu>()->data(),
        f6[isub]->as<cart_volume_regular_cpu>()->data(),
        f7[isub]->as<cart_volume_regular_cpu>()->data(),
        f8[isub]->as<cart_volume_regular_cpu>()->data(),
        f9[isub]->as<cart_volume_regular_cpu>()->data(),
        ax1->ibeg, ax1->iend, ax2->ibeg, ax2->iend, ax3->ibeg, ax3->iend);
}
