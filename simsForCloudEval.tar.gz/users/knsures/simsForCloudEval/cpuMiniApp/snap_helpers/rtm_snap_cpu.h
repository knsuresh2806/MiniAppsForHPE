#ifndef RTM_SNAP_CPU
#define RTM_SNAP_CPU

#include <rtm_snap.h>

class file_snap;
class rtm_snap_cpu : public rtm_snap
{
public:
    rtm_snap_cpu() : rtm_snap() {}

    void start_read_uncompressed_fwi_snapshot(std::vector<cart_volume<realtype>*>& corrBuffList,
                                              std::vector<int>& corr_buff_size, file_snap* fd_snap_p) override;

    void start_write_uncompressed_fwi_snapshot(std::vector<cart_volume<realtype>*>& corrBuffList,
                                               std::vector<int>& corr_buff_size, file_snap* fd_snap_p) override;

};

#endif // RTM_SNAP_CPU
